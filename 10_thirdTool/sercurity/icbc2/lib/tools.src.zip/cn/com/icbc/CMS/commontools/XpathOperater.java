package cn.com.icbc.CMS.commontools;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jdom.Attribute;
import org.jdom.Content;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Text;
import org.jdom.filter.ContentFilter;
import org.jdom.xpath.XPath;

public class XpathOperater
{
  private String pathexp;
  private Document xmldoc;
  private XPath xp;
  private List contentlist;
  private ContentFilter cf = new ContentFilter();
  private boolean isElement = false;

  public XpathOperater()
  {
    this.pathexp = null;
    this.xmldoc = null;
    this.xp = null;
    this.contentlist = null;
  }

  public XpathOperater(String exp, Document doc)
    throws JDOMException
  {
    this.pathexp = exp;
    this.xmldoc = doc;
    try
    {
      this.xp = XPath.newInstance(this.pathexp);
    }
    catch (JDOMException e)
    {
      throw new JDOMException("表达式不合法");
    }
    getNodes();
  }

  public void Destory()
  {
    this.pathexp = null;
    this.xmldoc = null;
    this.xp = null;
    this.contentlist = null;
    this.cf = null;
  }

  public void setXpath(String exp)
    throws JDOMException
  {
    this.pathexp = exp;
    try
    {
      this.xp = XPath.newInstance(this.pathexp);
    }
    catch (JDOMException e)
    {
      throw new JDOMException("表达式不合法");
    }
    getNodes();
  }

  public void setDom(Document doc)
    throws JDOMException
  {
    this.xmldoc = doc;
    getNodes();
  }

  public String getXpath()
  {
    return this.pathexp;
  }

  public Document getCurrentDoc()
  {
    return this.xmldoc;
  }

  private void getNodes()
    throws JDOMException
  {
    if ((this.xmldoc != null) && (this.xp != null))
    {
      this.contentlist = this.xp.selectNodes(this.xmldoc);
      if (this.contentlist.size() < 1) {
        throw new JDOMException("路径指向节点不存在");
      }

      this.cf.setFilterMask(1);
      this.isElement = this.cf.matches(this.contentlist.get(0));
    }
  }

  public List getList()
  {
    return this.contentlist;
  }

  public int getNodeCount()
  {
    return this.contentlist.size();
  }

  public boolean isElement()
  {
    return this.isElement;
  }

  public String getNodeValue()
    throws JDOMException
  {
    Content first_node;
    try
    {
      first_node = (Content)this.contentlist.get(0);
      return first_node.getValue();
    }
    catch (Exception e) {
    }
    return this.xp.valueOf(this.xmldoc);
  }

  public String getElementValue(int index)
    throws JDOMException
  {
    if (!(this.isElement))
    {
      throw new JDOMException("xpath指向不是元素");
    }
    if ((index > this.contentlist.size()) || (index < 1))
    {
      throw new ArrayIndexOutOfBoundsException("数组越界");
    }

    --index;
    Element select_element = (Element)this.contentlist.get(index);
    return select_element.getText();
  }

  public void setNodeValue(String newvalue)
    throws JDOMException
  {
    if (this.isElement) {
      setElementValue(newvalue, 1);
    } else if (this.contentlist.get(0).getClass().getName().equals("org.jdom.Attribute"))
    {
      Attribute att = (Attribute)this.contentlist.get(0);
      att.setValue(newvalue);
    }
    else
    {
      throw new JDOMException("不支持修改xpath指向的值");
    }
  }

  public void setElementValue(String newvalue, int index)
  {
    if ((index > this.contentlist.size()) || (index < 1))
    {
      throw new ArrayIndexOutOfBoundsException("数组越界");
    }

    --index;
    Element select_element = (Element)this.contentlist.get(index);
    select_element.setText(newvalue);
  }

  public void addContent(Content newcontent)
    throws JDOMException
  {
    if (this.isElement)
    {
      Element first_element = (Element)this.contentlist.get(0);
      first_element.addContent(newcontent);
    }
    else {
      throw new JDOMException("xpath指向不是元素");
    }
  }

  public void deleteElement()
    throws JDOMException
  {
    Element first_element = (Element)this.contentlist.get(0);
    if (!(first_element.isRootElement()))
    {
      first_element.detach();
    }
    else
    {
      throw new JDOMException("不允许删除根节点");
    }
  }

  public Element getElement()
  {
    if (this.isElement)
    {
      return ((Element)this.contentlist.get(0));
    }

    return null;
  }

  public Element getElement(int index) throws JDOMException
  {
    if (!(this.isElement))
    {
      throw new JDOMException("xpath指向不是元素");
    }
    if ((index > this.contentlist.size()) || (index < 1))
    {
      throw new ArrayIndexOutOfBoundsException("数组越界");
    }

    --index;
    Element select_element = (Element)this.contentlist.get(index);
    return ((Element)this.contentlist.get(index));
  }

  public void setElementValue(String strict_xpath, String newvalue)
    throws JDOMException
  {
    ArrayList strlist = new ArrayList();
    try
    {
      setXpath(strict_xpath);
      setElementValue(newvalue, 1);
    }
    catch (JDOMException e)
    {
      if (e.getMessage().equals("路径指向节点不存在"))
      {
        ArrayList al;
        String cur_root;
        int k;
        List x;
        if (!(strict_xpath.startsWith("/")))
        {
          throw new JDOMException("不符合函数的表达式要求");
        }

        String original = this.xp.getXPath();
        Pattern mypt = Pattern.compile("::");
        Matcher mymc = mypt.matcher(original);
        String changed = mymc.replaceAll("/");
        StringTokenizer stringbreak = new StringTokenizer(changed, "/");
        while (stringbreak.hasMoreTokens())
        {
          strlist.add(stringbreak.nextToken());
        }
        for (int i = 0; i < strlist.size(); i += 2)
        {
          if (!(strlist.get(i).equals("child")))
            throw new JDOMException("不符合函数的表达式要求");
        }

        if (this.xmldoc.getRootElement().getNamespacePrefix().equals(""))
          cur_root = this.xmldoc.getRootElement().getName();
        else
          cur_root = 
            this.xmldoc.getRootElement().getNamespacePrefix() + 
            ":" + 
            this.xmldoc.getRootElement().getName();
        if (!(cur_root.equals(strlist.get(1)))) {
          throw new JDOMException("不符合函数的表达式要求");
        }

        int i = 0;
        StringBuffer subpath = new StringBuffer();

        Element current = this.xmldoc.getRootElement();
        Element temp = current;

        for (i = 2; i < strlist.size() / 2 + 1; ++i)
        {
          al = procesMultiSubElement((String)strlist.get(i * 2 - 1));
          if (al.get(1).equals("0"))
          {
            temp = current.getChild((String)al.get(0));
          }
          else
          {
            k = Integer.parseInt((String)al.get(1));
            x = current.getChildren((String)al.get(0));
            if (x == null) break; if (x.size() < k)
              break;

            temp = (Element)x.get(k - 1);
          }
          if (temp == null)
          {
            break;
          }
          current = temp;
        }

        while (i < strlist.size() / 2 + 1)
        {
          al = procesMultiSubElement((String)strlist.get(i * 2 - 1));
          if (al.get(1).equals("0"))
          {
            temp = new Element((String)al.get(0));
            current.addContent(temp);
          }
          else
          {
            k = Integer.parseInt((String)al.get(1));
            x = current.getChildren((String)al.get(0));
            int n = 0;
            if (x != null)
              n = x.size();
            for (int j = n; j < k; ++j)
            {
              temp = new Element((String)al.get(0));
              current.addContent(temp);
            }
          }
          current = temp;
          ++i;
        }

        Text value = new Text(newvalue);
        current.addContent(value);
      }
      else {
        throw e;
      }
    }
  }

  private ArrayList procesMultiSubElement(String element_name)
  {
    int start = element_name.indexOf("[");
    int end = 0;
    ArrayList name_and_number = new ArrayList(2);
    String number = null;

    if (start != -1)
    {
      end = element_name.indexOf("]");
      String just_name = element_name.substring(0, start);
      number = element_name.substring(start + 1, end - 2);
      name_and_number.add(just_name);
      name_and_number.add(number);
    }
    else
    {
      name_and_number.add(element_name);
      name_and_number.add("0");
    }
    return name_and_number;
  }
}