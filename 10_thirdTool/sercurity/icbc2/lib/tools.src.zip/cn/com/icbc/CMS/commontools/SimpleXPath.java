package cn.com.icbc.CMS.commontools;

import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;
import org.jdom.Content;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.Namespace;
import org.jdom.input.SAXBuilder;
import org.jdom.xpath.XPath;

public class SimpleXPath extends XPath
{
  private String standard_path;
  private List path_breaks;

  public static void main(String[] args)
  {
    String filename;
    try
    {
      filename = "C:\\Documents and Settings\\dujh\\桌面\\birds.xml";
      SAXBuilder builder = new SAXBuilder("org.apache.xerces.parsers.SAXParser", false);
      Document doc = builder.build(new File(filename));
      XPath.setXPathClass(Class.forName("cn.com.icbc.CMS.commontools.SimpleXPath"));
      XPath myxp = XPath.newInstance("/Class/Order[1]/Family/Species[2]");

      System.out.print(myxp.valueOf(doc));
    }
    catch (JDOMException e)
    {
      e.printStackTrace();
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    catch (ClassNotFoundException e)
    {
      e.printStackTrace();
    }
  }

  public SimpleXPath(String path)
  {
    this.path_breaks = new ArrayList();
    transletepath(path);
  }

  private void transletepath(String path)
  {
    StringTokenizer stringbreak = new StringTokenizer(path, "/");
    StringBuffer sb = new StringBuffer();
    while (stringbreak.hasMoreTokens())
    {
      String temp = stringbreak.nextToken();
      if (temp.startsWith("@"))
      {
        sb.append("/attribute::" + temp.substring(1));
      }
      else
      {
        sb.append("/child::" + temp);
      }
      this.path_breaks.add(temp);
    }
    this.standard_path = sb.toString();
  }

  public List element_number(String element_path)
    throws JDOMException
  {
    List re = new ArrayList();
    int start = element_path.indexOf(91);
    int end = element_path.indexOf(93);
    if ((start == -1) && (end == -1))
    {
      re.add("1");
      re.add(element_path);
      return re;
    }
    if ((start > 0) && (end > 2))
    {
      try
      {
        re.add(element_path.substring(start + 1, end));
        re.add(element_path.substring(0, start));
        return re;
      }
      catch (Exception e)
      {
        throw new JDOMException("表达式不合法");
      }

    }

    throw new JDOMException("表达式不合法");
  }

  public List selectNodes(Object arg0)
    throws JDOMException
  {
    int number = 0;
    List Children = null;
    List temp = new ArrayList();
    Element next = ((Document)arg0).getRootElement();
    if (!(((String)this.path_breaks.get(0)).equals(next.getName())))
      return null;
    Iterator i = this.path_breaks.iterator();
    i.next();
    label173: while (i.hasNext())
    {
      try
      {
        temp = element_number((String)i.next());
        String a = (String)temp.get(0);
        String b = (String)temp.get(1);
        number = Integer.parseInt(a);
        Children = next.getChildren(b);

        if (Children.size() == 0)
          return null;
        next = (Element)Children.get(number - 1);
        if (next != null) break label173;
        return null;
      }
      catch (Exception e)
      {
        throw new JDOMException("无法获取节点");
      }
    }
    temp.clear();
    temp.add(next);
    return temp;
  }

  public Object selectSingleNode(Object arg0)
    throws JDOMException
  {
    List temp = selectNodes(arg0);
    if (temp == null)
    {
      return null;
    }

    return temp.get(0);
  }

  public String valueOf(Object arg0)
    throws JDOMException
  {
    return ((Content)selectSingleNode(arg0)).getValue();
  }

  public Number numberValueOf(Object arg0)
    throws JDOMException
  {
    return null;
  }

  public void setVariable(String arg0, Object arg1)
  {
  }

  public void addNamespace(Namespace arg0)
  {
  }

  public String getXPath()
  {
    return this.standard_path;
  }
}