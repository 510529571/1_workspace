package cn.com.icbc.CMS.commontools;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.UnsupportedEncodingException;

public class TranslationTool
{
  public static byte[] shortToByte(short pShort)
  {
    byte[] bb = new byte[2];
    bb[0] = (byte)((pShort & 0xFF00) >>> 8);
    bb[1] = (byte)(pShort & 0xFF);
    return bb;
  }

  public static byte[] intToByte(int pInt)
  {
    byte[] bi = { 0, 0, 6, 5 };
    bi[0] = (byte)((pInt & 0xFF000000) >>> 24);
    bi[1] = (byte)((pInt & 0xFF0000) >>> 16);
    bi[2] = (byte)((pInt & 0xFF00) >>> 8);
    bi[3] = (byte)(pInt & 0xFF);
    return bi;
  }

  public static int byteToInt(byte[] pByte, int pbegin, int len)
  {
    int ret = 0;
    for (int i = pbegin; i < pbegin + len; ++i)
    {
      ret = ret << 8 & 0xFFFFFF00 | pByte[i] & 0xFF;
    }
    return ret;
  }

  public static short byteToShort(byte[] pByte, int pbegin, int len)
  {
    short ret = 0;
    for (int i = pbegin; i < pbegin + len; ++i)
      ret = (short)((short)(ret << 8) & 0xFF00 | (short)(pByte[i] & 0xFF));
    return ret;
  }

  public static String byteToString(byte[] pByte, int pbegin, int len)
    throws UnsupportedEncodingException
  {
    return new String(pByte, pbegin, len, "gb2312");
  }

  public static String HextoASCII(byte[] byteSrc, int start, int length)
  {
    if ((start < 0) || (length < 0))
      throw new ArrayIndexOutOfBoundsException();
    if (start + length > byteSrc.length)
      throw new ArrayIndexOutOfBoundsException();

    StringBuffer hexTableBuffer = new StringBuffer(2 * length);
    for (int i = start; i < start + length; ++i)
    {
      String num = Integer.toHexString(byteSrc[i] & 0xFF).toUpperCase();
      if (num.length() < 2)
      {
        hexTableBuffer.append('0');
      }
      hexTableBuffer.append(num);
    }
    return hexTableBuffer.toString();
  }

  public static String HextoASCII(byte[] byteSrc)
  {
    return HextoASCII(byteSrc, 0, byteSrc.length);
  }

  public static byte[] ASCIItoHex(String asciistring)
  {
    if (asciistring.length() % 2 != 0)
      throw new IllegalArgumentException("string length error");
    byte[] coverdata = new byte[asciistring.length() / 2];
    for (int i = 0; i < coverdata.length; ++i)
    {
      coverdata[i] = (byte)Integer.parseInt(asciistring.substring(i * 2, (i + 1) * 2), 16);
    }
    return coverdata;
  }

  public static byte[] readFile(String pathandname)
    throws IOException
  {
    FileInputStream fs = new FileInputStream(pathandname);
    byte[] temp = new byte[fs.available()];
    fs.read(temp);
    fs.close();
    return temp;
  }

  public static byte[] readFile(String pathandname, int start)
    throws IOException
  {
    FileInputStream fs = new FileInputStream(pathandname);
    if ((start < 0) || (start > fs.available()))
      throw new IOException();
    byte[] temp = new byte[fs.available() - start];
    fs.skip(start);
    fs.read(temp);
    fs.close();
    return temp;
  }

  public static void main(String[] args)
    throws UnsupportedEncodingException
  {
    String test = "C466E6F746";
    byte[] a = test.getBytes();

    a = ASCIItoHex(test);
    System.out.println(new String(a, "gb2312"));
  }
}