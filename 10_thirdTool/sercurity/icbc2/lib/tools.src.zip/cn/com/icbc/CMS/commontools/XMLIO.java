package cn.com.icbc.CMS.commontools;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import org.jdom.JDOMException;
import org.jdom.input.DOMBuilder;
import org.jdom.input.SAXBuilder;
import org.jdom.output.DOMOutputter;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;

public class XMLIO
{
  private SAXBuilder jdombuilder;
  private org.jdom.Document tempdocument;
  private DOMOutputter jdom_to_dom;
  private XMLOutputter savejdom;

  public XMLIO()
  {
    this.jdombuilder = new SAXBuilder(false);

    this.savejdom = new XMLOutputter();
    this.tempdocument = null;
  }

  private org.w3c.dom.Document transformDocument()
    throws JDOMException
  {
    this.jdom_to_dom = new DOMOutputter();
    return this.jdom_to_dom.output(this.tempdocument);
  }

  public void build(String xmlstring)
    throws JDOMException, IOException
  {
    build(xmlstring.getBytes());
  }

  public void build(byte[] xmlbytes)
    throws JDOMException, IOException
  {
    ByteArrayInputStream bytearray_to_stream = new ByteArrayInputStream(xmlbytes);
    this.tempdocument = this.jdombuilder.build(bytearray_to_stream);
  }

  public void build(File xmlfile)
    throws JDOMException, IOException
  {
    this.tempdocument = this.jdombuilder.build(xmlfile);
  }

  public void build(InputStream in)
    throws JDOMException, IOException
  {
    this.tempdocument = this.jdombuilder.build(in);
  }

  public void setJdom(org.jdom.Document jdom_document)
    throws JDOMException
  {
    this.tempdocument = jdom_document;
  }

  public void setDom(org.w3c.dom.Document doc)
  {
    DOMBuilder db = new DOMBuilder();
    this.tempdocument = db.build(doc);
  }

  public org.jdom.Document getJdom()
  {
    return this.tempdocument;
  }

  public org.w3c.dom.Document getDom()
    throws JDOMException
  {
    return transformDocument();
  }

  public void save(File outputfile, String enc)
    throws IOException
  {
    FileOutputStream fos = new FileOutputStream(outputfile);
    save(fos, enc, false);
  }

  public void save(String filename, String enc)
    throws IOException
  {
    FileOutputStream fos = new FileOutputStream(filename);
    save(fos, enc, false);
  }

  public void save(OutputStream out, String Encoding, boolean pretty)
    throws IOException
  {
    Format docf = null;
    if (pretty)
      docf = Format.getPrettyFormat();
    else
      docf = Format.getRawFormat();
    docf.setEncoding(Encoding);
    this.savejdom.setFormat(docf);
    if (this.tempdocument != null)
    {
      this.savejdom.output(this.tempdocument, out);
    }
  }
}