// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   LoopTagStatus.java

package javax.servlet.jsp.jstl.core;


public interface LoopTagStatus
{

	public abstract Object getCurrent();

	public abstract int getIndex();

	public abstract int getCount();

	public abstract boolean isFirst();

	public abstract boolean isLast();

	public abstract Integer getBegin();

	public abstract Integer getEnd();

	public abstract Integer getStep();
}
