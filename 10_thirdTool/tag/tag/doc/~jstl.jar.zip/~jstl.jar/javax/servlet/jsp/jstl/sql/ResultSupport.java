// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ResultSupport.java

package javax.servlet.jsp.jstl.sql;

import java.sql.ResultSet;
import java.sql.SQLException;

// Referenced classes of package javax.servlet.jsp.jstl.sql:
//			ResultImpl, Result

public class ResultSupport
{

	public ResultSupport()
	{
	}

	public static Result toResult(ResultSet rs)
	{
		return new ResultImpl(rs, -1, -1);
		SQLException ex;
		ex;
		return null;
	}

	public static Result toResult(ResultSet rs, int maxRows)
	{
		return new ResultImpl(rs, -1, maxRows);
		SQLException ex;
		ex;
		return null;
	}
}
