// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   LocalizationContext.java

package javax.servlet.jsp.jstl.fmt;

import java.util.Locale;
import java.util.ResourceBundle;

public class LocalizationContext
{

	private final ResourceBundle bundle;
	private final Locale locale;

	public LocalizationContext()
	{
		bundle = null;
		locale = null;
	}

	public LocalizationContext(ResourceBundle bundle, Locale locale)
	{
		this.bundle = bundle;
		this.locale = locale;
	}

	public LocalizationContext(ResourceBundle bundle)
	{
		this.bundle = bundle;
		locale = bundle.getLocale();
	}

	public ResourceBundle getResourceBundle()
	{
		return bundle;
	}

	public Locale getLocale()
	{
		return locale;
	}
}
