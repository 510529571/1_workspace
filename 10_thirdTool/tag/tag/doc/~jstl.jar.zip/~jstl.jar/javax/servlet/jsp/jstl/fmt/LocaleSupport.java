// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   LocaleSupport.java

package javax.servlet.jsp.jstl.fmt;

import java.text.MessageFormat;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import javax.servlet.jsp.PageContext;
import org.apache.taglibs.standard.tag.common.fmt.BundleSupport;

// Referenced classes of package javax.servlet.jsp.jstl.fmt:
//			LocalizationContext

public class LocaleSupport
{

	public LocaleSupport()
	{
	}

	public static String getLocalizedMessage(PageContext pageContext, String key)
	{
		return getLocalizedMessage(pageContext, key, null, null);
	}

	public static String getLocalizedMessage(PageContext pageContext, String key, String basename)
	{
		return getLocalizedMessage(pageContext, key, null, basename);
	}

	public static String getLocalizedMessage(PageContext pageContext, String key, Object args[])
	{
		return getLocalizedMessage(pageContext, key, args, null);
	}

	public static String getLocalizedMessage(PageContext pageContext, String key, Object args[], String basename)
	{
		LocalizationContext locCtxt = null;
		String message = "???" + key + "???";
		if (basename != null)
			locCtxt = BundleSupport.getLocalizationContext(pageContext, basename);
		else
			locCtxt = BundleSupport.getLocalizationContext(pageContext);
		if (locCtxt != null)
		{
			ResourceBundle bundle = locCtxt.getResourceBundle();
			if (bundle != null)
				try
				{
					message = bundle.getString(key);
					if (args != null)
					{
						MessageFormat formatter = new MessageFormat("");
						if (locCtxt.getLocale() != null)
							formatter.setLocale(locCtxt.getLocale());
						formatter.applyPattern(message);
						message = formatter.format(((Object) (args)));
					}
				}
				catch (MissingResourceException mre) { }
		}
		return message;
	}
}
