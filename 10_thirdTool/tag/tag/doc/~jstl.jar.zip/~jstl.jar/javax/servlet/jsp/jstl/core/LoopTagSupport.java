// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   LoopTagSupport.java

package javax.servlet.jsp.jstl.core;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;

// Referenced classes of package javax.servlet.jsp.jstl.core:
//			LoopTag, LoopTagStatus

public abstract class LoopTagSupport extends TagSupport
	implements LoopTag, IterationTag, TryCatchFinally
{

	protected int begin;
	protected int end;
	protected int step;
	protected boolean beginSpecified;
	protected boolean endSpecified;
	protected boolean stepSpecified;
	protected String itemId;
	protected String statusId;
	private LoopTagStatus status;
	private Object item;
	private int index;
	private int count;
	private boolean last;

	public LoopTagSupport()
	{
		init();
	}

	protected abstract Object next()
		throws JspTagException;

	protected abstract boolean hasNext()
		throws JspTagException;

	protected abstract void prepare()
		throws JspTagException;

	public void release()
	{
		super.release();
		init();
	}

	public int doStartTag()
		throws JspException
	{
		if (end != -1 && begin > end)
			return 0;
		index = 0;
		count = 1;
		last = false;
		prepare();
		discardIgnoreSubset(begin);
		if (hasNext())
			item = next();
		else
			return 0;
		discard(step - 1);
		exposeVariables();
		calibrateLast();
		return 1;
	}

	public int doAfterBody()
		throws JspException
	{
		index += step - 1;
		count++;
		if (hasNext() && !atEnd())
		{
			index++;
			item = next();
		} else
		{
			return 0;
		}
		discard(step - 1);
		exposeVariables();
		calibrateLast();
		return 2;
	}

	public void doFinally()
	{
		unExposeVariables();
	}

	public void doCatch(Throwable t)
		throws Throwable
	{
		throw t;
	}

	public Object getCurrent()
	{
		return item;
	}

	public LoopTagStatus getLoopStatus()
	{
		class 1Status
			implements LoopTagStatus
		{

			public Object getCurrent()
			{
				return LoopTagSupport.this.getCurrent();
			}

			public int getIndex()
			{
				return index + begin;
			}

			public int getCount()
			{
				return count;
			}

			public boolean isFirst()
			{
				return index == 0;
			}

			public boolean isLast()
			{
				return last;
			}

			public Integer getBegin()
			{
				if (beginSpecified)
					return new Integer(begin);
				else
					return null;
			}

			public Integer getEnd()
			{
				if (endSpecified)
					return new Integer(end);
				else
					return null;
			}

			public Integer getStep()
			{
				if (stepSpecified)
					return new Integer(step);
				else
					return null;
			}

			1Status()
			{
			}
		}

		if (status == null)
			status = new 1Status();
		return status;
	}

	public void setVar(String id)
	{
		itemId = id;
	}

	public void setVarStatus(String statusId)
	{
		this.statusId = statusId;
	}

	protected void validateBegin()
		throws JspTagException
	{
		if (begin < 0)
			throw new JspTagException("'begin' < 0");
		else
			return;
	}

	protected void validateEnd()
		throws JspTagException
	{
		if (end < 0)
			throw new JspTagException("'end' < 0");
		else
			return;
	}

	protected void validateStep()
		throws JspTagException
	{
		if (step < 1)
			throw new JspTagException("'step' <= 0");
		else
			return;
	}

	private void init()
	{
		index = 0;
		count = 1;
		status = null;
		item = null;
		last = false;
		beginSpecified = false;
		endSpecified = false;
		stepSpecified = false;
		begin = 0;
		end = -1;
		step = 1;
		itemId = null;
		statusId = null;
	}

	private void calibrateLast()
		throws JspTagException
	{
		last = !hasNext() || atEnd() || end != -1 && begin + index + step > end;
	}

	private void exposeVariables()
		throws JspTagException
	{
		if (itemId != null)
			if (getCurrent() == null)
				pageContext.removeAttribute(itemId, 1);
			else
				pageContext.setAttribute(itemId, getCurrent());
		if (statusId != null)
			if (getLoopStatus() == null)
				pageContext.removeAttribute(statusId, 1);
			else
				pageContext.setAttribute(statusId, getLoopStatus());
	}

	private void unExposeVariables()
	{
		if (itemId != null)
			pageContext.removeAttribute(itemId, 1);
		if (statusId != null)
			pageContext.removeAttribute(statusId, 1);
	}

	private void discard(int n)
		throws JspTagException
	{
		int oldIndex = index;
		for (; n-- > 0 && !atEnd() && hasNext(); next())
			index++;

		index = oldIndex;
	}

	private void discardIgnoreSubset(int n)
		throws JspTagException
	{
		for (; n-- > 0 && hasNext(); next());
	}

	private boolean atEnd()
	{
		return end != -1 && begin + index >= end;
	}



}
