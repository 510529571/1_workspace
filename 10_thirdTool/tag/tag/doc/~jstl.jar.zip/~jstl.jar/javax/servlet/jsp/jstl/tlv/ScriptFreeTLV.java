// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ScriptFreeTLV.java

package javax.servlet.jsp.jstl.tlv;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import javax.servlet.jsp.tagext.*;
import javax.xml.parsers.*;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class ScriptFreeTLV extends TagLibraryValidator
{
	private class MyContentHandler extends DefaultHandler
	{

		private int declarationCount;
		private int scriptletCount;
		private int expressionCount;
		private int rtExpressionCount;

		public void startElement(String namespaceUri, String localName, String qualifiedName, Attributes atts)
		{
			if (!allowDeclarations && qualifiedName.equals("jsp:declaration"))
				declarationCount++;
			else
			if (!allowScriptlets && qualifiedName.equals("jsp:scriptlet"))
				scriptletCount++;
			else
			if (!allowExpressions && qualifiedName.equals("jsp:expression"))
				expressionCount++;
			if (!allowRTExpressions)
				countRTExpressions(atts);
		}

		private void countRTExpressions(Attributes atts)
		{
			int stop = atts.getLength();
			for (int i = 0; i < stop; i++)
			{
				String attval = atts.getValue(i);
				if (attval.startsWith("%=") && attval.endsWith("%"))
					rtExpressionCount++;
			}

		}

		public ValidationMessage[] reportResults()
		{
			if (declarationCount + scriptletCount + expressionCount + rtExpressionCount > 0)
			{
				StringBuffer results = new StringBuffer("JSP page contains ");
				boolean first = true;
				if (declarationCount > 0)
				{
					results.append(Integer.toString(declarationCount));
					results.append(" declaration");
					if (declarationCount > 1)
						results.append('s');
					first = false;
				}
				if (scriptletCount > 0)
				{
					if (!first)
						results.append(", ");
					results.append(Integer.toString(scriptletCount));
					results.append(" scriptlet");
					if (scriptletCount > 1)
						results.append('s');
					first = false;
				}
				if (expressionCount > 0)
				{
					if (!first)
						results.append(", ");
					results.append(Integer.toString(expressionCount));
					results.append(" expression");
					if (expressionCount > 1)
						results.append('s');
					first = false;
				}
				if (rtExpressionCount > 0)
				{
					if (!first)
						results.append(", ");
					results.append(Integer.toString(rtExpressionCount));
					results.append(" request-time attribute value");
					if (rtExpressionCount > 1)
						results.append('s');
					first = false;
				}
				results.append(".");
				return ScriptFreeTLV.vmFromString(results.toString());
			} else
			{
				return null;
			}
		}

		private MyContentHandler()
		{
			declarationCount = 0;
			scriptletCount = 0;
			expressionCount = 0;
			rtExpressionCount = 0;
		}

	}


	private boolean allowDeclarations;
	private boolean allowScriptlets;
	private boolean allowExpressions;
	private boolean allowRTExpressions;
	private SAXParserFactory factory;

	public ScriptFreeTLV()
	{
		allowDeclarations = false;
		allowScriptlets = false;
		allowExpressions = false;
		allowRTExpressions = false;
		factory = SAXParserFactory.newInstance();
		factory.setValidating(false);
		factory.setNamespaceAware(true);
	}

	public void setInitParameters(Map initParms)
	{
		super.setInitParameters(initParms);
		String declarationsParm = (String)initParms.get("allowDeclarations");
		String scriptletsParm = (String)initParms.get("allowScriptlets");
		String expressionsParm = (String)initParms.get("allowExpressions");
		String rtExpressionsParm = (String)initParms.get("allowRTExpressions");
		allowDeclarations = "true".equalsIgnoreCase(declarationsParm);
		allowScriptlets = "true".equalsIgnoreCase(scriptletsParm);
		allowExpressions = "true".equalsIgnoreCase(expressionsParm);
		allowRTExpressions = "true".equalsIgnoreCase(rtExpressionsParm);
	}

	public ValidationMessage[] validate(String prefix, String uri, PageData page)
	{
		InputStream in;
		MyContentHandler handler;
		in = null;
		handler = new MyContentHandler();
		SAXParser parser;
		synchronized (factory)
		{
			parser = factory.newSAXParser();
		}
		in = page.getInputStream();
		parser.parse(in, handler);
		break MISSING_BLOCK_LABEL_147;
		ParserConfigurationException e;
		e;
		ValidationMessage avalidationmessage[] = vmFromString(e.toString());
		return avalidationmessage;
		e;
		avalidationmessage = vmFromString(e.toString());
		return avalidationmessage;
		e;
		avalidationmessage = vmFromString(e.toString());
		return avalidationmessage;
		local;
		if (in != null)
			try
			{
				in.close();
			}
			catch (IOException e) { }
		JVM INSTR ret 10;
		return handler.reportResults();
	}

	private static ValidationMessage[] vmFromString(String message)
	{
		return (new ValidationMessage[] {
			new ValidationMessage(null, message)
		});
	}





}
