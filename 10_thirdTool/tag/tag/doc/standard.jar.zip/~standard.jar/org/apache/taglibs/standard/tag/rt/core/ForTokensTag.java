// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ForTokensTag.java

package org.apache.taglibs.standard.tag.rt.core;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.jstl.core.LoopTag;
import javax.servlet.jsp.tagext.IterationTag;
import org.apache.taglibs.standard.tag.common.core.ForTokensSupport;

public class ForTokensTag extends ForTokensSupport
	implements LoopTag, IterationTag
{

	public ForTokensTag()
	{
	}

	public void setBegin(int begin)
		throws JspTagException
	{
		beginSpecified = true;
		this.begin = begin;
		validateBegin();
	}

	public void setEnd(int end)
		throws JspTagException
	{
		endSpecified = true;
		this.end = end;
		validateEnd();
	}

	public void setStep(int step)
		throws JspTagException
	{
		stepSpecified = true;
		this.step = step;
		validateStep();
	}

	public void setItems(String s)
		throws JspTagException
	{
		items = s;
		if (s == null)
			items = "";
	}

	public void setDelims(String s)
		throws JspTagException
	{
		delims = s;
		if (s == null)
			delims = "";
	}
}
