// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ArraySuffix.java

package org.apache.taglibs.standard.lang.jstl;

import java.lang.reflect.*;
import java.util.List;
import java.util.Map;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			ValueSuffix, ELException, Expression, Logger, 
//			Constants, Coercions, BeanInfoManager, BeanInfoProperty, 
//			VariableResolver

public class ArraySuffix extends ValueSuffix
{

	static Object sNoArgs[] = new Object[0];
	Expression mIndex;

	public Expression getIndex()
	{
		return mIndex;
	}

	public void setIndex(Expression pIndex)
	{
		mIndex = pIndex;
	}

	public ArraySuffix(Expression pIndex)
	{
		mIndex = pIndex;
	}

	Object evaluateIndex(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger)
		throws ELException
	{
		return mIndex.evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
	}

	String getOperatorSymbol()
	{
		return "[]";
	}

	public String getExpressionString()
	{
		return "[" + mIndex.getExpressionString() + "]";
	}

	public Object evaluate(Object pValue, Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger)
		throws ELException
	{
		Object indexVal;
		Integer indexObj;
		if (pValue == null)
		{
			if (pLogger.isLoggingWarning())
				pLogger.logWarning(Constants.CANT_GET_INDEXED_VALUE_OF_NULL, getOperatorSymbol());
			return null;
		}
		if ((indexVal = evaluateIndex(pContext, pResolver, functions, defaultPrefix, pLogger)) == null)
		{
			if (pLogger.isLoggingWarning())
				pLogger.logWarning(Constants.CANT_GET_NULL_INDEX, getOperatorSymbol());
			return null;
		}
		if (pValue instanceof Map)
		{
			Map val = (Map)pValue;
			return val.get(indexVal);
		}
		if (!(pValue instanceof List) && !pValue.getClass().isArray())
			break MISSING_BLOCK_LABEL_326;
		indexObj = Coercions.coerceToInteger(indexVal, pLogger);
		if (indexObj == null)
		{
			if (pLogger.isLoggingError())
				pLogger.logError(Constants.BAD_INDEX_VALUE, getOperatorSymbol(), indexVal.getClass().getName());
			return null;
		}
		if (!(pValue instanceof List))
			break MISSING_BLOCK_LABEL_244;
		return ((List)pValue).get(indexObj.intValue());
		ArrayIndexOutOfBoundsException exc;
		exc;
		if (pLogger.isLoggingWarning())
			pLogger.logWarning(Constants.EXCEPTION_ACCESSING_LIST, exc, indexObj);
		return null;
		exc;
		if (pLogger.isLoggingWarning())
			pLogger.logWarning(Constants.EXCEPTION_ACCESSING_LIST, exc, indexObj);
		return null;
		exc;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.EXCEPTION_ACCESSING_LIST, exc, indexObj);
		return null;
		return Array.get(pValue, indexObj.intValue());
		exc;
		if (pLogger.isLoggingWarning())
			pLogger.logWarning(Constants.EXCEPTION_ACCESSING_ARRAY, exc, indexObj);
		return null;
		exc;
		if (pLogger.isLoggingWarning())
			pLogger.logWarning(Constants.EXCEPTION_ACCESSING_ARRAY, exc, indexObj);
		return null;
		exc;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.EXCEPTION_ACCESSING_ARRAY, exc, indexObj);
		return null;
		String indexStr;
		BeanInfoProperty property;
		if ((indexStr = Coercions.coerceToString(indexVal, pLogger)) == null)
			return null;
		if ((property = BeanInfoManager.getBeanInfoProperty(pValue.getClass(), indexStr, pLogger)) == null || property.getReadMethod() == null)
			break MISSING_BLOCK_LABEL_444;
		return property.getReadMethod().invoke(pValue, sNoArgs);
		InvocationTargetException exc;
		exc;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.ERROR_GETTING_PROPERTY, exc.getTargetException(), indexStr, pValue.getClass().getName());
		return null;
		exc;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.ERROR_GETTING_PROPERTY, exc, indexStr, pValue.getClass().getName());
		return null;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.CANT_FIND_INDEX, indexVal, pValue.getClass().getName(), getOperatorSymbol());
		return null;
	}

}
