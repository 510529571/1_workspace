// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   BooleanLiteral.java

package org.apache.taglibs.standard.lang.jstl;


// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			Literal

public class BooleanLiteral extends Literal
{

	public static final BooleanLiteral TRUE = new BooleanLiteral("true");
	public static final BooleanLiteral FALSE = new BooleanLiteral("false");

	public BooleanLiteral(String pToken)
	{
		super(getValueFromToken(pToken));
	}

	static Object getValueFromToken(String pToken)
	{
		return "true".equals(pToken) ? Boolean.TRUE : Boolean.FALSE;
	}

	public String getExpressionString()
	{
		return getValue() != Boolean.TRUE ? "false" : "true";
	}

}
