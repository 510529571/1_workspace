// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DriverTag.java

package org.apache.taglibs.standard.tag.common.sql;

import javax.servlet.ServletContext;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.TagSupport;

// Referenced classes of package org.apache.taglibs.standard.tag.common.sql:
//			DataSourceWrapper

public class DriverTag extends TagSupport
{

	private static final String DRIVER_CLASS_NAME = "javax.servlet.jsp.jstl.sql.driver";
	private static final String JDBC_URL = "javax.servlet.jsp.jstl.sql.jdbcURL";
	private static final String USER_NAME = "javax.servlet.jsp.jstl.sql.userName";
	private static final String PASSWORD = "javax.servlet.jsp.jstl.sql.password";
	private String driverClassName;
	private String jdbcURL;
	private int scope;
	private String userName;
	private String var;

	public DriverTag()
	{
		scope = 1;
	}

	public void setDriver(String driverClassName)
	{
		this.driverClassName = driverClassName;
	}

	public void setJdbcURL(String jdbcURL)
	{
		this.jdbcURL = jdbcURL;
	}

	public void setScope(String scopeName)
	{
		if ("page".equals(scopeName))
			scope = 1;
		else
		if ("request".equals(scopeName))
			scope = 2;
		else
		if ("session".equals(scopeName))
			scope = 3;
		else
		if ("application".equals(scopeName))
			scope = 4;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public int doStartTag()
		throws JspException
	{
		DataSourceWrapper ds = new DataSourceWrapper();
		try
		{
			ds.setDriverClassName(getDriverClassName());
		}
		catch (Exception e)
		{
			throw new JspTagException("Invalid driver class name: " + e.toString(), e);
		}
		ds.setJdbcURL(getJdbcURL());
		ds.setUserName(getUserName());
		ds.setPassword(getPassword());
		pageContext.setAttribute(var, ds, scope);
		return 0;
	}

	private String getDriverClassName()
	{
		if (driverClassName != null)
		{
			return driverClassName;
		} else
		{
			ServletContext application = pageContext.getServletContext();
			return application.getInitParameter("javax.servlet.jsp.jstl.sql.driver");
		}
	}

	private String getJdbcURL()
	{
		if (jdbcURL != null)
		{
			return jdbcURL;
		} else
		{
			ServletContext application = pageContext.getServletContext();
			return application.getInitParameter("javax.servlet.jsp.jstl.sql.jdbcURL");
		}
	}

	private String getUserName()
	{
		if (userName != null)
		{
			return userName;
		} else
		{
			ServletContext application = pageContext.getServletContext();
			return application.getInitParameter("javax.servlet.jsp.jstl.sql.userName");
		}
	}

	private String getPassword()
	{
		ServletContext application = pageContext.getServletContext();
		return application.getInitParameter("javax.servlet.jsp.jstl.sql.password");
	}
}
