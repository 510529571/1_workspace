// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParseDateTag.java

package org.apache.taglibs.standard.tag.rt.fmt;

import java.util.Locale;
import javax.servlet.jsp.JspTagException;
import org.apache.taglibs.standard.tag.common.fmt.ParseDateSupport;
import org.apache.taglibs.standard.tag.common.fmt.SetLocaleSupport;

public class ParseDateTag extends ParseDateSupport
{

	public ParseDateTag()
	{
	}

	public void setValue(String value)
		throws JspTagException
	{
		this.value = value;
		valueSpecified = true;
	}

	public void setType(String type)
		throws JspTagException
	{
		this.type = type;
	}

	public void setDateStyle(String dateStyle)
		throws JspTagException
	{
		this.dateStyle = dateStyle;
	}

	public void setTimeStyle(String timeStyle)
		throws JspTagException
	{
		this.timeStyle = timeStyle;
	}

	public void setPattern(String pattern)
		throws JspTagException
	{
		this.pattern = pattern;
	}

	public void setTimeZone(Object timeZone)
		throws JspTagException
	{
		this.timeZone = timeZone;
	}

	public void setParseLocale(Object loc)
		throws JspTagException
	{
		if (loc != null)
			if (loc instanceof Locale)
				parseLocale = (Locale)loc;
			else
			if (!"".equals((String)loc))
				parseLocale = SetLocaleSupport.parseLocale((String)loc);
	}
}
