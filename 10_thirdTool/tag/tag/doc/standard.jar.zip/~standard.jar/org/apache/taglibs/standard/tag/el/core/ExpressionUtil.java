// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ExpressionUtil.java

package org.apache.taglibs.standard.tag.el.core;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.tag.common.core.NullAttributeException;

public class ExpressionUtil
{

	public ExpressionUtil()
	{
	}

	public static Object evalNotNull(String tagName, String attributeName, String expression, Class expectedType, Tag tag, PageContext pageContext)
		throws JspException
	{
		if (expression != null)
		{
			Object r = ExpressionEvaluatorManager.evaluate(attributeName, expression, expectedType, tag, pageContext);
			if (r == null)
				throw new NullAttributeException(tagName, attributeName);
			else
				return r;
		} else
		{
			return null;
		}
	}
}
