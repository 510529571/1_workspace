// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ComplexValue.java

package org.apache.taglibs.standard.lang.jstl;

import java.util.List;
import java.util.Map;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			Expression, ValueSuffix, ELException, VariableResolver, 
//			Logger

public class ComplexValue extends Expression
{

	Expression mPrefix;
	List mSuffixes;

	public Expression getPrefix()
	{
		return mPrefix;
	}

	public void setPrefix(Expression pPrefix)
	{
		mPrefix = pPrefix;
	}

	public List getSuffixes()
	{
		return mSuffixes;
	}

	public void setSuffixes(List pSuffixes)
	{
		mSuffixes = pSuffixes;
	}

	public ComplexValue(Expression pPrefix, List pSuffixes)
	{
		mPrefix = pPrefix;
		mSuffixes = pSuffixes;
	}

	public String getExpressionString()
	{
		StringBuffer buf = new StringBuffer();
		buf.append(mPrefix.getExpressionString());
		for (int i = 0; mSuffixes != null && i < mSuffixes.size(); i++)
		{
			ValueSuffix suffix = (ValueSuffix)mSuffixes.get(i);
			buf.append(suffix.getExpressionString());
		}

		return buf.toString();
	}

	public Object evaluate(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger)
		throws ELException
	{
		Object ret = mPrefix.evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
		for (int i = 0; mSuffixes != null && i < mSuffixes.size(); i++)
		{
			ValueSuffix suffix = (ValueSuffix)mSuffixes.get(i);
			ret = suffix.evaluate(ret, pContext, pResolver, functions, defaultPrefix, pLogger);
		}

		return ret;
	}
}
