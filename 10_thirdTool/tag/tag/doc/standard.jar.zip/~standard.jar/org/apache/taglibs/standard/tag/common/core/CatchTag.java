// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   CatchTag.java

package org.apache.taglibs.standard.tag.common.core;

import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.tagext.TryCatchFinally;

public class CatchTag extends TagSupport
	implements TryCatchFinally
{

	private String var;
	private boolean caught;

	public CatchTag()
	{
		init();
	}

	public void release()
	{
		super.release();
		init();
	}

	private void init()
	{
		var = null;
	}

	public int doStartTag()
	{
		caught = false;
		return 1;
	}

	public void doCatch(Throwable t)
	{
		if (var != null)
			pageContext.setAttribute(var, t, 1);
		caught = true;
	}

	public void doFinally()
	{
		if (var != null && !caught)
			pageContext.removeAttribute(var, 1);
	}

	public void setVar(String var)
	{
		this.var = var;
	}
}
