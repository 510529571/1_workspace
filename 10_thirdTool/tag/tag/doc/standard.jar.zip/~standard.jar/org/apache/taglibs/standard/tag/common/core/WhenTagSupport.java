// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   WhenTagSupport.java

package org.apache.taglibs.standard.tag.common.core;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.jstl.core.ConditionalTagSupport;
import org.apache.taglibs.standard.resources.Resources;

// Referenced classes of package org.apache.taglibs.standard.tag.common.core:
//			ChooseTag

public abstract class WhenTagSupport extends ConditionalTagSupport
{

	public WhenTagSupport()
	{
	}

	public int doStartTag()
		throws JspException
	{
		javax.servlet.jsp.tagext.Tag parent;
		if (!((parent = getParent()) instanceof ChooseTag))
			throw new JspTagException(Resources.getMessage("WHEN_OUTSIDE_CHOOSE"));
		if (!((ChooseTag)parent).gainPermission())
			return 0;
		if (condition())
		{
			((ChooseTag)parent).subtagSucceeded();
			return 1;
		} else
		{
			return 0;
		}
	}
}
