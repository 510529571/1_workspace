// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   EnumeratedMap.java

package org.apache.taglibs.standard.lang.jstl;

import java.util.*;

public abstract class EnumeratedMap
	implements Map
{

	Map mMap;

	public EnumeratedMap()
	{
	}

	public void clear()
	{
		throw new UnsupportedOperationException();
	}

	public boolean containsKey(Object pKey)
	{
		return getValue(pKey) != null;
	}

	public boolean containsValue(Object pValue)
	{
		return getAsMap().containsValue(pValue);
	}

	public Set entrySet()
	{
		return getAsMap().entrySet();
	}

	public Object get(Object pKey)
	{
		return getValue(pKey);
	}

	public boolean isEmpty()
	{
		return !enumerateKeys().hasMoreElements();
	}

	public Set keySet()
	{
		return getAsMap().keySet();
	}

	public Object put(Object pKey, Object pValue)
	{
		throw new UnsupportedOperationException();
	}

	public void putAll(Map pMap)
	{
		throw new UnsupportedOperationException();
	}

	public Object remove(Object pKey)
	{
		throw new UnsupportedOperationException();
	}

	public int size()
	{
		return getAsMap().size();
	}

	public Collection values()
	{
		return getAsMap().values();
	}

	public abstract Enumeration enumerateKeys();

	public abstract boolean isMutable();

	public abstract Object getValue(Object obj);

	public Map getAsMap()
	{
		if (mMap != null)
			return mMap;
		Map m = convertToMap();
		if (!isMutable())
			mMap = m;
		return m;
	}

	Map convertToMap()
	{
		Map ret = new HashMap();
		Object key;
		Object value;
		for (Enumeration e = enumerateKeys(); e.hasMoreElements(); ret.put(key, value))
		{
			key = e.nextElement();
			value = getValue(key);
		}

		return ret;
	}
}
