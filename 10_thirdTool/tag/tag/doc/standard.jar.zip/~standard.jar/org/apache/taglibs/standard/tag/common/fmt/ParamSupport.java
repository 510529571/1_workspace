// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParamSupport.java

package org.apache.taglibs.standard.tag.common.fmt;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import org.apache.taglibs.standard.resources.Resources;

// Referenced classes of package org.apache.taglibs.standard.tag.common.fmt:
//			MessageSupport

public abstract class ParamSupport extends BodyTagSupport
{

	protected Object value;
	protected boolean valueSpecified;

	public ParamSupport()
	{
		init();
	}

	private void init()
	{
		value = null;
		valueSpecified = false;
	}

	public int doEndTag()
		throws JspException
	{
		javax.servlet.jsp.tagext.Tag t = findAncestorWithClass(this, org.apache.taglibs.standard.tag.common.fmt.MessageSupport.class);
		if (t == null)
			throw new JspTagException(Resources.getMessage("PARAM_OUTSIDE_MESSAGE"));
		MessageSupport parent = (MessageSupport)t;
		Object input = null;
		if (valueSpecified)
			input = value;
		else
			input = bodyContent.getString().trim();
		parent.addParam(input);
		return 6;
	}

	public void release()
	{
		init();
	}
}
