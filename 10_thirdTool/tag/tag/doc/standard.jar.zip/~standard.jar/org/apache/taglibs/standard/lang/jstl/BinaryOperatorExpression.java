// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   BinaryOperatorExpression.java

package org.apache.taglibs.standard.lang.jstl;

import java.util.List;
import java.util.Map;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			Expression, BinaryOperator, ELException, Coercions, 
//			VariableResolver, Logger

public class BinaryOperatorExpression extends Expression
{

	Expression mExpression;
	List mOperators;
	List mExpressions;

	public Expression getExpression()
	{
		return mExpression;
	}

	public void setExpression(Expression pExpression)
	{
		mExpression = pExpression;
	}

	public List getOperators()
	{
		return mOperators;
	}

	public void setOperators(List pOperators)
	{
		mOperators = pOperators;
	}

	public List getExpressions()
	{
		return mExpressions;
	}

	public void setExpressions(List pExpressions)
	{
		mExpressions = pExpressions;
	}

	public BinaryOperatorExpression(Expression pExpression, List pOperators, List pExpressions)
	{
		mExpression = pExpression;
		mOperators = pOperators;
		mExpressions = pExpressions;
	}

	public String getExpressionString()
	{
		StringBuffer buf = new StringBuffer();
		buf.append("(");
		buf.append(mExpression.getExpressionString());
		for (int i = 0; i < mOperators.size(); i++)
		{
			BinaryOperator operator = (BinaryOperator)mOperators.get(i);
			Expression expression = (Expression)mExpressions.get(i);
			buf.append(" ");
			buf.append(operator.getOperatorSymbol());
			buf.append(" ");
			buf.append(expression.getExpressionString());
		}

		buf.append(")");
		return buf.toString();
	}

	public Object evaluate(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger)
		throws ELException
	{
		Object value = mExpression.evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
		for (int i = 0; i < mOperators.size(); i++)
		{
			BinaryOperator operator = (BinaryOperator)mOperators.get(i);
			if (operator.shouldCoerceToBoolean())
				value = Coercions.coerceToBoolean(value, pLogger);
			if (operator.shouldEvaluate(value))
			{
				Expression expression = (Expression)mExpressions.get(i);
				Object nextValue = expression.evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
				value = operator.apply(value, nextValue, pContext, pLogger);
			}
		}

		return value;
	}
}
