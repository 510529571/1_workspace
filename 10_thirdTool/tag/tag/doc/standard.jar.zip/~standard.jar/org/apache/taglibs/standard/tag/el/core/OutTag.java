// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   OutTag.java

package org.apache.taglibs.standard.tag.el.core;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.tag.common.core.NullAttributeException;
import org.apache.taglibs.standard.tag.common.core.OutSupport;

// Referenced classes of package org.apache.taglibs.standard.tag.el.core:
//			ExpressionUtil

public class OutTag extends OutSupport
{

	private String value_;
	private String default_;
	private String escapeXml_;

	public OutTag()
	{
		init();
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setValue(String value_)
	{
		this.value_ = value_;
	}

	public void setDefault(String default_)
	{
		this.default_ = default_;
	}

	public void setEscapeXml(String escapeXml_)
	{
		this.escapeXml_ = escapeXml_;
	}

	private void init()
	{
		value_ = default_ = escapeXml_ = null;
	}

	private void evaluateExpressions()
		throws JspException
	{
		try
		{
			value = ExpressionUtil.evalNotNull("out", "value", value_, java.lang.Object.class, this, pageContext);
		}
		catch (NullAttributeException ex)
		{
			value = null;
		}
		try
		{
			def = (String)ExpressionUtil.evalNotNull("out", "default", default_, java.lang.String.class, this, pageContext);
		}
		catch (NullAttributeException ex)
		{
			def = null;
		}
		escapeXml = true;
		Boolean escape = (Boolean)ExpressionUtil.evalNotNull("out", "escapeXml", escapeXml_, java.lang.Boolean.class, this, pageContext);
		if (escape != null)
			escapeXml = escape.booleanValue();
	}
}
