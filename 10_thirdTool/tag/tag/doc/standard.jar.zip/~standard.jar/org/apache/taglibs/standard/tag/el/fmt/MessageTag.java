// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MessageTag.java

package org.apache.taglibs.standard.tag.el.fmt;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.jstl.fmt.LocalizationContext;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.tag.common.fmt.MessageSupport;

public class MessageTag extends MessageSupport
{

	private String key_;
	private String bundle_;

	public MessageTag()
	{
		init();
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setKey(String key_)
	{
		this.key_ = key_;
		keySpecified = true;
	}

	public void setBundle(String bundle_)
	{
		this.bundle_ = bundle_;
		bundleSpecified = true;
	}

	private void init()
	{
		key_ = bundle_ = null;
	}

	private void evaluateExpressions()
		throws JspException
	{
		if (keySpecified)
			keyAttrValue = (String)ExpressionEvaluatorManager.evaluate("key", key_, java.lang.String.class, this, pageContext);
		if (bundleSpecified)
			bundleAttrValue = (LocalizationContext)ExpressionEvaluatorManager.evaluate("bundle", bundle_, javax.servlet.jsp.jstl.fmt.LocalizationContext.class, this, pageContext);
	}
}
