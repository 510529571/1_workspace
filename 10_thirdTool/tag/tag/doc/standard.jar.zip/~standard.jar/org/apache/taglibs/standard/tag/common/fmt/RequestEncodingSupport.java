// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   RequestEncodingSupport.java

package org.apache.taglibs.standard.tag.common.fmt;

import java.io.UnsupportedEncodingException;
import javax.servlet.ServletRequest;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.TagSupport;

public abstract class RequestEncodingSupport extends TagSupport
{

	static final String REQUEST_CHAR_SET = "javax.servlet.jsp.jstl.fmt.request.charset";
	private static final String DEFAULT_ENCODING = "ISO-8859-1";
	protected String value;
	protected String charEncoding;

	public RequestEncodingSupport()
	{
		init();
	}

	private void init()
	{
		value = null;
	}

	public int doEndTag()
		throws JspException
	{
		charEncoding = value;
		if (charEncoding == null && pageContext.getRequest().getCharacterEncoding() == null)
		{
			charEncoding = (String)pageContext.getAttribute("javax.servlet.jsp.jstl.fmt.request.charset", 3);
			if (charEncoding == null)
				charEncoding = "ISO-8859-1";
		}
		if (charEncoding != null)
			try
			{
				pageContext.getRequest().setCharacterEncoding(charEncoding);
			}
			catch (UnsupportedEncodingException uee)
			{
				throw new JspTagException(uee.toString(), uee);
			}
		return 6;
	}

	public void release()
	{
		init();
	}
}
