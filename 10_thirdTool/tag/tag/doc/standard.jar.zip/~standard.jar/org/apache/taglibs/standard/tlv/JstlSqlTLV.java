// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JstlSqlTLV.java

package org.apache.taglibs.standard.tlv;

import java.util.*;
import javax.servlet.jsp.tagext.PageData;
import javax.servlet.jsp.tagext.ValidationMessage;
import org.apache.taglibs.standard.resources.Resources;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

// Referenced classes of package org.apache.taglibs.standard.tlv:
//			JstlBaseTLV

public class JstlSqlTLV extends JstlBaseTLV
{
	private class Handler extends DefaultHandler
	{

		private int depth;
		private Stack queryDepths;
		private Stack updateDepths;
		private Stack transactionDepths;
		private String lastElementName;
		private boolean bodyNecessary;
		private boolean bodyIllegal;

		public void startElement(String ns, String ln, String qn, Attributes a)
		{
			if (ln == null)
				ln = getLocalPart(qn);
			if (qn.equals("jsp:text"))
				return;
			if (bodyIllegal)
				fail(Resources.getMessage("TLV_ILLEGAL_BODY", lastElementName));
			Set expAtts;
			if (qn.startsWith(prefix + ":") && (expAtts = (Set)config.get(ln)) != null)
			{
				for (int i = 0; i < a.getLength(); i++)
				{
					String attName = a.getLocalName(i);
					if (!expAtts.contains(attName))
						continue;
					String vMsg = validateExpression(ln, attName, a.getValue(i));
					if (vMsg != null)
						fail(vMsg);
				}

			}
			if (qn.startsWith(prefix + ":") && !hasNoInvalidScope(a))
				fail(Resources.getMessage("TLV_INVALID_ATTRIBUTE", "scope", qn, a.getValue("scope")));
			if (qn.startsWith(prefix + ":") && hasEmptyVar(a))
				fail(Resources.getMessage("TLV_EMPTY_VAR", qn));
			if (qn.startsWith(prefix + ":") && hasDanglingScope(a) && !qn.startsWith(prefix + ":" + "setDataSource"))
				fail(Resources.getMessage("TLV_DANGLING_SCOPE", qn));
			if ((isSqlTag(ns, ln, "param") || isSqlTag(ns, ln, "dateParam")) && queryDepths.empty() && updateDepths.empty())
				fail(Resources.getMessage("SQL_PARAM_OUTSIDE_PARENT"));
			if (isSqlTag(ns, ln, "query"))
				queryDepths.push(new Integer(depth));
			if (isSqlTag(ns, ln, "update"))
				updateDepths.push(new Integer(depth));
			if (isSqlTag(ns, ln, "transaction"))
				transactionDepths.push(new Integer(depth));
			bodyIllegal = false;
			bodyNecessary = false;
			if (isSqlTag(ns, ln, "query") || isSqlTag(ns, ln, "update"))
			{
				if (!hasAttribute(a, "sql"))
					bodyNecessary = true;
				if (hasAttribute(a, "dataSource") && !transactionDepths.empty())
					fail(Resources.getMessage("ERROR_NESTED_DATASOURCE"));
			}
			if (isSqlTag(ns, ln, "dateParam"))
				bodyIllegal = true;
			lastElementName = qn;
			lastElementId = a.getValue("http://java.sun.com/JSP/Page", "id");
			depth++;
		}

		public void characters(char ch[], int start, int length)
		{
			bodyNecessary = false;
			String s = (new String(ch, start, length)).trim();
			if (s.equals(""))
				return;
			if (bodyIllegal)
				fail(Resources.getMessage("TLV_ILLEGAL_BODY", lastElementName));
		}

		public void endElement(String ns, String ln, String qn)
		{
			if (qn.equals("jsp:text"))
				return;
			if (bodyNecessary)
				fail(Resources.getMessage("TLV_MISSING_BODY", lastElementName));
			bodyIllegal = false;
			if (isSqlTag(ns, ln, "query"))
				queryDepths.pop();
			if (isSqlTag(ns, ln, "update"))
				updateDepths.pop();
			if (isSqlTag(ns, ln, "transaction"))
				transactionDepths.pop();
			depth--;
		}

		private Handler()
		{
			depth = 0;
			queryDepths = new Stack();
			updateDepths = new Stack();
			transactionDepths = new Stack();
			lastElementName = null;
			bodyNecessary = false;
			bodyIllegal = false;
		}

	}


	private final String SETDATASOURCE = "setDataSource";
	private final String QUERY = "query";
	private final String UPDATE = "update";
	private final String TRANSACTION = "transaction";
	private final String PARAM = "param";
	private final String DATEPARAM = "dateParam";
	private final String JSP_TEXT = "jsp:text";
	private final String SQL = "sql";
	private final String DATASOURCE = "dataSource";

	public JstlSqlTLV()
	{
	}

	public ValidationMessage[] validate(String prefix, String uri, PageData page)
	{
		return super.validate(3, prefix, uri, page);
	}

	protected DefaultHandler getHandler()
	{
		return new Handler();
	}
}
