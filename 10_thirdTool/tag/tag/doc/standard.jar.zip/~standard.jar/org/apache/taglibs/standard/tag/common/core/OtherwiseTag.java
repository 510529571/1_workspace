// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   OtherwiseTag.java

package org.apache.taglibs.standard.tag.common.core;


// Referenced classes of package org.apache.taglibs.standard.tag.common.core:
//			WhenTagSupport

public class OtherwiseTag extends WhenTagSupport
{

	public OtherwiseTag()
	{
	}

	protected boolean condition()
	{
		return true;
	}
}
