// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ExprSupport.java

package org.apache.taglibs.standard.tag.common.xml;

import java.io.IOException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;
import org.apache.taglibs.standard.tag.common.core.OutSupport;

// Referenced classes of package org.apache.taglibs.standard.tag.common.xml:
//			XPathUtil

public abstract class ExprSupport extends TagSupport
{

	private String select;
	protected boolean escapeXml;

	public ExprSupport()
	{
		init();
	}

	private void init()
	{
		select = null;
		escapeXml = true;
	}

	public int doStartTag()
		throws JspException
	{
		XPathUtil xu = new XPathUtil(pageContext);
		String result = xu.valueOf(XPathUtil.getContext(this), select);
		OutSupport.out(pageContext, escapeXml, result);
		return 0;
		IOException ex;
		ex;
		throw new JspTagException(ex.toString(), ex);
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setSelect(String select)
	{
		this.select = select;
	}
}
