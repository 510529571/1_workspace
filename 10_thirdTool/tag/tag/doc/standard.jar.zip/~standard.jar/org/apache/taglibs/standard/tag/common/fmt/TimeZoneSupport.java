// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TimeZoneSupport.java

package org.apache.taglibs.standard.tag.common.fmt;

import java.io.IOException;
import java.util.TimeZone;
import javax.servlet.jsp.*;
import javax.servlet.jsp.jstl.core.Config;
import javax.servlet.jsp.tagext.*;

public abstract class TimeZoneSupport extends BodyTagSupport
{

	protected Object value;
	private TimeZone timeZone;

	public TimeZoneSupport()
	{
		init();
	}

	private void init()
	{
		value = null;
	}

	public TimeZone getTimeZone()
	{
		return timeZone;
	}

	public int doStartTag()
		throws JspException
	{
		if (value == null)
			timeZone = TimeZone.getTimeZone("GMT");
		else
		if (value instanceof String)
		{
			if (((String)value).trim().equals(""))
				timeZone = TimeZone.getTimeZone("GMT");
			else
				timeZone = TimeZone.getTimeZone((String)value);
		} else
		{
			timeZone = (TimeZone)value;
		}
		return 2;
	}

	public int doEndTag()
		throws JspException
	{
		try
		{
			pageContext.getOut().print(bodyContent.getString());
		}
		catch (IOException ioe)
		{
			throw new JspTagException(ioe.toString(), ioe);
		}
		return 6;
	}

	public void release()
	{
		init();
	}

	static TimeZone getTimeZone(PageContext pc, Tag fromTag)
	{
		TimeZone tz = null;
		Tag t = findAncestorWithClass(fromTag, org.apache.taglibs.standard.tag.common.fmt.TimeZoneSupport.class);
		if (t != null)
		{
			TimeZoneSupport parent = (TimeZoneSupport)t;
			tz = parent.getTimeZone();
		} else
		{
			Object obj = Config.find(pc, "javax.servlet.jsp.jstl.fmt.timeZone");
			if (obj != null)
				if (obj instanceof TimeZone)
					tz = (TimeZone)obj;
				else
					tz = TimeZone.getTimeZone((String)obj);
		}
		return tz;
	}
}
