// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParseDateSupport.java

package org.apache.taglibs.standard.tag.common.fmt;

import java.io.IOException;
import java.text.*;
import java.util.Locale;
import java.util.TimeZone;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import org.apache.taglibs.standard.resources.Resources;
import org.apache.taglibs.standard.tag.common.core.Util;

// Referenced classes of package org.apache.taglibs.standard.tag.common.fmt:
//			SetLocaleSupport, TimeZoneSupport

public abstract class ParseDateSupport extends BodyTagSupport
{

	private static final String DATE = "date";
	private static final String TIME = "time";
	private static final String DATETIME = "both";
	protected String value;
	protected boolean valueSpecified;
	protected String type;
	protected String pattern;
	protected Object timeZone;
	protected Locale parseLocale;
	protected String dateStyle;
	protected String timeStyle;
	private String var;
	private int scope;

	public ParseDateSupport()
	{
		init();
	}

	private void init()
	{
		type = dateStyle = timeStyle = null;
		value = pattern = var = null;
		valueSpecified = false;
		timeZone = null;
		scope = 1;
		parseLocale = null;
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
	}

	public int doEndTag()
		throws JspException
	{
		String input = null;
		if (valueSpecified)
			input = value;
		else
		if (bodyContent != null && bodyContent.getString() != null)
			input = bodyContent.getString().trim();
		if (input == null || input.equals(""))
		{
			if (var != null)
				pageContext.removeAttribute(var, scope);
			return 6;
		}
		Locale locale = parseLocale;
		if (locale == null)
			locale = SetLocaleSupport.getFormattingLocale(pageContext, this, false, DateFormat.getAvailableLocales());
		if (locale == null)
			throw new JspException(Resources.getMessage("PARSE_DATE_NO_PARSE_LOCALE"));
		DateFormat parser = createParser(locale);
		if (pattern != null)
			try
			{
				((SimpleDateFormat)parser).applyPattern(pattern);
			}
			catch (ClassCastException cce)
			{
				parser = new SimpleDateFormat(pattern, locale);
			}
		TimeZone tz = null;
		if ((timeZone instanceof String) && ((String)timeZone).equals(""))
			timeZone = null;
		if (timeZone != null)
		{
			if (timeZone instanceof String)
				tz = TimeZone.getTimeZone((String)timeZone);
			else
			if (timeZone instanceof TimeZone)
				tz = (TimeZone)timeZone;
			else
				throw new JspException(Resources.getMessage("PARSE_DATE_BAD_TIMEZONE"));
		} else
		{
			tz = TimeZoneSupport.getTimeZone(pageContext, this);
		}
		if (tz != null)
			parser.setTimeZone(tz);
		java.util.Date parsed = null;
		try
		{
			parsed = parser.parse(input);
		}
		catch (ParseException pe)
		{
			throw new JspException(Resources.getMessage("PARSE_DATE_PARSE_ERROR", input), pe);
		}
		if (var != null)
			pageContext.setAttribute(var, parsed, scope);
		else
			try
			{
				pageContext.getOut().print(parsed);
			}
			catch (IOException ioe)
			{
				throw new JspTagException(ioe.toString(), ioe);
			}
		return 6;
	}

	public void release()
	{
		init();
	}

	private DateFormat createParser(Locale loc)
		throws JspException
	{
		DateFormat parser = null;
		if (type == null || "date".equalsIgnoreCase(type))
			parser = DateFormat.getDateInstance(Util.getStyle(dateStyle, "PARSE_DATE_INVALID_DATE_STYLE"), loc);
		else
		if ("time".equalsIgnoreCase(type))
			parser = DateFormat.getTimeInstance(Util.getStyle(timeStyle, "PARSE_DATE_INVALID_TIME_STYLE"), loc);
		else
		if ("both".equalsIgnoreCase(type))
			parser = DateFormat.getDateTimeInstance(Util.getStyle(dateStyle, "PARSE_DATE_INVALID_DATE_STYLE"), Util.getStyle(timeStyle, "PARSE_DATE_INVALID_TIME_STYLE"), loc);
		else
			throw new JspException(Resources.getMessage("PARSE_DATE_INVALID_TYPE", type));
		parser.setLenient(false);
		return parser;
	}
}
