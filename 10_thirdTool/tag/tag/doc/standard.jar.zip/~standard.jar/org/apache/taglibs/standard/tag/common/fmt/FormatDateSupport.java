// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FormatDateSupport.java

package org.apache.taglibs.standard.tag.common.fmt;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.TagSupport;
import org.apache.taglibs.standard.resources.Resources;
import org.apache.taglibs.standard.tag.common.core.Util;

// Referenced classes of package org.apache.taglibs.standard.tag.common.fmt:
//			SetLocaleSupport, TimeZoneSupport

public abstract class FormatDateSupport extends TagSupport
{

	private static final String DATE = "date";
	private static final String TIME = "time";
	private static final String DATETIME = "both";
	protected Date value;
	protected String type;
	protected String pattern;
	protected Object timeZone;
	protected String dateStyle;
	protected String timeStyle;
	private String var;
	private int scope;

	public FormatDateSupport()
	{
		init();
	}

	private void init()
	{
		type = dateStyle = timeStyle = null;
		pattern = var = null;
		value = null;
		timeZone = null;
		scope = 1;
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
	}

	public int doEndTag()
		throws JspException
	{
		String formatted = null;
		if (value == null)
		{
			if (var != null)
				pageContext.removeAttribute(var, scope);
			return 6;
		}
		Locale locale = SetLocaleSupport.getFormattingLocale(pageContext, this, true, DateFormat.getAvailableLocales());
		if (locale != null)
		{
			DateFormat formatter = createFormatter(locale);
			if (pattern != null)
				try
				{
					((SimpleDateFormat)formatter).applyPattern(pattern);
				}
				catch (ClassCastException cce)
				{
					formatter = new SimpleDateFormat(pattern, locale);
				}
			TimeZone tz = null;
			if ((timeZone instanceof String) && ((String)timeZone).equals(""))
				timeZone = null;
			if (timeZone != null)
			{
				if (timeZone instanceof String)
					tz = TimeZone.getTimeZone((String)timeZone);
				else
				if (timeZone instanceof TimeZone)
					tz = (TimeZone)timeZone;
				else
					throw new JspTagException(Resources.getMessage("FORMAT_DATE_BAD_TIMEZONE"));
			} else
			{
				tz = TimeZoneSupport.getTimeZone(pageContext, this);
			}
			if (tz != null)
				formatter.setTimeZone(tz);
			formatted = formatter.format(value);
		} else
		{
			formatted = value.toString();
		}
		if (var != null)
			pageContext.setAttribute(var, formatted, scope);
		else
			try
			{
				pageContext.getOut().print(formatted);
			}
			catch (IOException ioe)
			{
				throw new JspTagException(ioe.toString(), ioe);
			}
		return 6;
	}

	public void release()
	{
		init();
	}

	private DateFormat createFormatter(Locale loc)
		throws JspException
	{
		DateFormat formatter = null;
		if (type == null || "date".equalsIgnoreCase(type))
			formatter = DateFormat.getDateInstance(Util.getStyle(dateStyle, "FORMAT_DATE_INVALID_DATE_STYLE"), loc);
		else
		if ("time".equalsIgnoreCase(type))
			formatter = DateFormat.getTimeInstance(Util.getStyle(timeStyle, "FORMAT_DATE_INVALID_TIME_STYLE"), loc);
		else
		if ("both".equalsIgnoreCase(type))
			formatter = DateFormat.getDateTimeInstance(Util.getStyle(dateStyle, "FORMAT_DATE_INVALID_DATE_STYLE"), Util.getStyle(timeStyle, "FORMAT_DATE_INVALID_TIME_STYLE"), loc);
		else
			throw new JspException(Resources.getMessage("FORMAT_DATE_INVALID_TYPE", type));
		return formatter;
	}
}
