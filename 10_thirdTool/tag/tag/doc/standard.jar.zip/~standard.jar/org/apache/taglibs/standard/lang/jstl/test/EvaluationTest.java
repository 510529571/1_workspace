// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   EvaluationTest.java

package org.apache.taglibs.standard.lang.jstl.test;

import java.io.*;
import java.util.*;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import org.apache.taglibs.standard.lang.jstl.Evaluator;
import org.apache.taglibs.standard.lang.jstl.test.beans.Factory;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl.test:
//			PageContextImpl, Bean1

public class EvaluationTest
{

	public EvaluationTest()
	{
	}

	public static void runTests(DataInput pIn, PrintStream pOut)
		throws IOException
	{
		PageContext context = createTestContext();
		do
		{
			String str = pIn.readLine();
			if (str != null)
			{
				if (str.startsWith("#") || "".equals(str.trim()))
				{
					pOut.println(str);
				} else
				{
					String typeStr = pIn.readLine();
					pOut.println("Expression: " + str);
					try
					{
						Class cl = parseClassName(typeStr);
						pOut.println("ExpectedType: " + cl);
						Evaluator e = new Evaluator();
						Object val = e.evaluate("test", str, cl, null, context);
						pOut.println("Evaluates to: " + val);
						if (val != null)
							pOut.println("With type: " + val.getClass().getName());
						pOut.println();
					}
					catch (JspException exc)
					{
						pOut.println("Causes an error: " + exc);
					}
					catch (ClassNotFoundException exc)
					{
						pOut.println("Causes an error: " + exc);
					}
				}
			} else
			{
				return;
			}
		} while (true);
	}

	static Class parseClassName(String pClassName)
		throws ClassNotFoundException
	{
		String c = pClassName.trim();
		if ("boolean".equals(c))
			return Boolean.TYPE;
		if ("byte".equals(c))
			return Byte.TYPE;
		if ("char".equals(c))
			return Character.TYPE;
		if ("short".equals(c))
			return Short.TYPE;
		if ("int".equals(c))
			return Integer.TYPE;
		if ("long".equals(c))
			return Long.TYPE;
		if ("float".equals(c))
			return Float.TYPE;
		if ("double".equals(c))
			return Double.TYPE;
		else
			return Class.forName(pClassName);
	}

	public static void runTests(File pInputFile, File pOutputFile)
		throws IOException
	{
		FileInputStream fin;
		FileOutputStream fout;
		fin = null;
		fout = null;
		DataInputStream din;
		fin = new FileInputStream(pInputFile);
		BufferedInputStream bin = new BufferedInputStream(fin);
		din = new DataInputStream(bin);
		fout = new FileOutputStream(pOutputFile);
		BufferedOutputStream bout = new BufferedOutputStream(fout);
		PrintStream pout = new PrintStream(bout);
		runTests(((DataInput) (din)), pout);
		pout.flush();
		if (fout != null)
			fout.close();
		break MISSING_BLOCK_LABEL_100;
		Exception exception;
		exception;
		if (fout != null)
			fout.close();
		throw exception;
		if (fin != null)
			fin.close();
		break MISSING_BLOCK_LABEL_124;
		Exception exception1;
		exception1;
		if (fin != null)
			fin.close();
		throw exception1;
	}

	public static boolean isDifferentFiles(DataInput pIn1, DataInput pIn2)
		throws IOException
	{
		String str1;
		String str2;
		do
		{
			str1 = pIn1.readLine();
			str2 = pIn2.readLine();
			if (str1 == null && str2 == null)
				return false;
			if (str1 == null || str2 == null)
				return true;
		} while (str1.equals(str2));
		return true;
	}

	public static boolean isDifferentFiles(File pFile1, File pFile2)
		throws IOException
	{
		FileInputStream fin1 = null;
		DataInputStream din1;
		FileInputStream fin2;
		fin1 = new FileInputStream(pFile1);
		BufferedInputStream bin1 = new BufferedInputStream(fin1);
		din1 = new DataInputStream(bin1);
		fin2 = null;
		boolean flag;
		fin2 = new FileInputStream(pFile2);
		BufferedInputStream bin2 = new BufferedInputStream(fin2);
		DataInputStream din2 = new DataInputStream(bin2);
		flag = isDifferentFiles(((DataInput) (din1)), ((DataInput) (din2)));
		if (fin2 != null)
			fin2.close();
		if (fin1 != null)
			fin1.close();
		return flag;
		Exception exception;
		exception;
		if (fin2 != null)
			fin2.close();
		throw exception;
		Exception exception1;
		exception1;
		if (fin1 != null)
			fin1.close();
		throw exception1;
	}

	static PageContext createTestContext()
	{
		PageContext ret = new PageContextImpl();
		ret.setAttribute("val1a", "page-scoped1", 1);
		ret.setAttribute("val1b", "request-scoped1", 2);
		ret.setAttribute("val1c", "session-scoped1", 3);
		ret.setAttribute("val1d", "app-scoped1", 4);
		Bean1 b1 = new Bean1();
		b1.setBoolean1(true);
		b1.setByte1((byte)12);
		b1.setShort1((short)-124);
		b1.setChar1('b');
		b1.setInt1(4);
		b1.setLong1(0x364d7L);
		b1.setFloat1(12.4F);
		b1.setDouble1(89.224000000000004D);
		b1.setString1("hello");
		b1.setStringArray1(new String[] {
			"string1", "string2", "string3", "string4"
		});
		List l = new ArrayList();
		l.add(new Integer(14));
		l.add("another value");
		l.add(b1.getStringArray1());
		b1.setList1(l);
		Map m = new HashMap();
		m.put("key1", "value1");
		m.put(new Integer(14), "value2");
		m.put(new Long(14L), "value3");
		m.put("recurse", b1);
		b1.setMap1(m);
		ret.setAttribute("bean1a", b1);
		Bean1 b2 = new Bean1();
		b2.setInt2(new Integer(-224));
		b2.setString2("bean2's string");
		b1.setBean1(b2);
		Bean1 b3 = new Bean1();
		b3.setDouble1(1422.3320000000001D);
		b3.setString2("bean3's string");
		b2.setBean2(b3);
		ret.setAttribute("pbean1", Factory.createBean1());
		ret.setAttribute("pbean2", Factory.createBean2());
		ret.setAttribute("pbean3", Factory.createBean3());
		ret.setAttribute("pbean4", Factory.createBean4());
		ret.setAttribute("pbean5", Factory.createBean5());
		ret.setAttribute("pbean6", Factory.createBean6());
		ret.setAttribute("pbean7", Factory.createBean7());
		Map m = new HashMap();
		m.put("emptyArray", ((Object) (new Object[0])));
		m.put("nonemptyArray", ((Object) (new Object[] {
			"abc"
		})));
		m.put("emptyList", new ArrayList());
		b2 = new ArrayList();
		b2.add("hello");
		m.put("nonemptyList", b2);
		m.put("emptyMap", new HashMap());
		Map m2 = new HashMap();
		m2.put("a", "a");
		m.put("nonemptyMap", m2);
		m.put("emptySet", new HashSet());
		Set s = new HashSet();
		s.add("hello");
		m.put("nonemptySet", s);
		ret.setAttribute("emptyTests", m);
		return ret;
	}

	public static void main(String pArgs[])
		throws IOException
	{
		if (pArgs.length != 2 && pArgs.length != 3)
		{
			usage();
			System.exit(1);
		}
		File in = new File(pArgs[0]);
		File out = new File(pArgs[1]);
		runTests(in, out);
		if (pArgs.length > 2)
		{
			File compare = new File(pArgs[2]);
			if (isDifferentFiles(out, compare))
				System.out.println("Test failure - output file " + out + " differs from expected output file " + compare);
			else
				System.out.println("tests passed");
		}
	}

	static void usage()
	{
		System.err.println("usage: java org.apache.taglibs.standard.lang.jstl.test.EvaluationTest {input file} {output file} [{compare file}]");
	}
}
