// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Evaluator.java

package org.apache.taglibs.standard.lang.jstl;

import java.text.MessageFormat;
import java.util.Map;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluator;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			ELException, ELEvaluator, JSTLVariableResolver, Constants

public class Evaluator
	implements ExpressionEvaluator
{

	static ELEvaluator sEvaluator = new ELEvaluator(new JSTLVariableResolver());

	public Evaluator()
	{
	}

	public String validate(String pAttributeName, String pAttributeValue)
	{
		sEvaluator.parseExpressionString(pAttributeValue);
		return null;
		ELException exc;
		exc;
		return MessageFormat.format(Constants.ATTRIBUTE_PARSE_EXCEPTION, new Object[] {
			"" + pAttributeName, "" + pAttributeValue, exc.getMessage()
		});
	}

	public Object evaluate(String pAttributeName, String pAttributeValue, Class pExpectedType, Tag pTag, PageContext pPageContext, Map functions, String defaultPrefix)
		throws JspException
	{
		return sEvaluator.evaluate(pAttributeValue, pPageContext, pExpectedType, functions, defaultPrefix);
		ELException exc;
		exc;
		throw new JspException(MessageFormat.format(Constants.ATTRIBUTE_EVALUATION_EXCEPTION, new Object[] {
			"" + pAttributeName, "" + pAttributeValue, exc.getMessage(), exc.getRootCause()
		}), exc.getRootCause());
	}

	public Object evaluate(String pAttributeName, String pAttributeValue, Class pExpectedType, Tag pTag, PageContext pPageContext)
		throws JspException
	{
		return evaluate(pAttributeName, pAttributeValue, pExpectedType, pTag, pPageContext, null, null);
	}

	public static String parseAndRender(String pAttributeValue)
		throws JspException
	{
		return sEvaluator.parseAndRender(pAttributeValue);
		ELException exc;
		exc;
		throw new JspException(MessageFormat.format(Constants.ATTRIBUTE_PARSE_EXCEPTION, new Object[] {
			"test", "" + pAttributeValue, exc.getMessage()
		}));
	}

}
