// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Step.java

package org.apache.taglibs.standard.extra.spath;

import java.util.List;

public class Step
{

	private boolean depthUnlimited;
	private String name;
	private List predicates;
	private String uri;
	private String localPart;

	public Step(boolean depthUnlimited, String name, List predicates)
	{
		if (name == null)
		{
			throw new IllegalArgumentException("non-null name required");
		} else
		{
			this.depthUnlimited = depthUnlimited;
			this.name = name;
			this.predicates = predicates;
			return;
		}
	}

	public boolean isMatchingName(String uri, String localPart)
	{
		if (localPart == null)
			throw new IllegalArgumentException("need non-null localPart");
		if (uri != null && uri.equals(""))
			uri = null;
		if (this.localPart == null && this.uri == null)
			parseStepName();
		if (this.uri == null && this.localPart.equals("*"))
			return true;
		if (uri == null && this.uri == null && localPart.equals(this.localPart))
			return true;
		if (uri != null && this.uri != null && uri.equals(this.uri))
		{
			if (localPart.equals(this.localPart))
				return true;
			if (this.localPart.equals("*"))
				return true;
		}
		return false;
	}

	public boolean isDepthUnlimited()
	{
		return depthUnlimited;
	}

	public String getName()
	{
		return name;
	}

	public List getPredicates()
	{
		return predicates;
	}

	private void parseStepName()
	{
		int colonIndex = name.indexOf(":");
		String prefix;
		if (colonIndex == -1)
		{
			prefix = null;
			localPart = name;
		} else
		{
			prefix = name.substring(0, colonIndex);
			localPart = name.substring(colonIndex + 1);
		}
		uri = mapPrefix(prefix);
	}

	private String mapPrefix(String prefix)
	{
		if (prefix == null)
			return null;
		else
			throw new IllegalArgumentException("unknown prefix '" + prefix + "'");
	}
}
