// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ChooseTag.java

package org.apache.taglibs.standard.tag.common.core;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;
import org.apache.taglibs.standard.resources.Resources;

public class ChooseTag extends TagSupport
{

	private boolean subtagGateClosed;

	public ChooseTag()
	{
		init();
	}

	public void release()
	{
		super.release();
		init();
	}

	public synchronized boolean gainPermission()
	{
		return !subtagGateClosed;
	}

	public synchronized void subtagSucceeded()
	{
		if (subtagGateClosed)
		{
			throw new IllegalStateException(Resources.getMessage("CHOOSE_EXCLUSIVITY"));
		} else
		{
			subtagGateClosed = true;
			return;
		}
	}

	public int doStartTag()
		throws JspException
	{
		subtagGateClosed = false;
		return 1;
	}

	private void init()
	{
		subtagGateClosed = false;
	}
}
