// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UnresolvableException.java

package org.apache.taglibs.standard.tag.common.xml;

import org.apache.xpath.XPathException;

public class UnresolvableException extends XPathException
{

	public UnresolvableException(String message)
	{
		super(message);
	}

	public UnresolvableException(String message, Exception e)
	{
		super(message, e);
	}
}
