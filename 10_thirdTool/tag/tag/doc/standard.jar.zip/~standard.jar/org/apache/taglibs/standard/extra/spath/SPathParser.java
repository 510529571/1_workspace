// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SPathParser.java

package org.apache.taglibs.standard.extra.spath;

import java.io.*;
import java.util.*;

// Referenced classes of package org.apache.taglibs.standard.extra.spath:
//			AbsolutePath, Step, ParseException, RelativePath, 
//			AttributePredicate, ASCII_UCodeESC_CharStream, SPathParserTokenManager, Token, 
//			SPathParserConstants, Path, Predicate

public class SPathParser
	implements SPathParserConstants
{
	static final class JJCalls
	{

		int gen;
		Token first;
		int arg;
		JJCalls next;

		JJCalls()
		{
		}
	}


	public SPathParserTokenManager token_source;
	ASCII_UCodeESC_CharStream jj_input_stream;
	public Token token;
	public Token jj_nt;
	private int jj_ntk;
	private Token jj_scanpos;
	private Token jj_lastpos;
	private int jj_la;
	public boolean lookingAhead;
	private boolean jj_semLA;
	private int jj_gen;
	private final int jj_la1[];
	private final int jj_la1_0[] = {
		24596, 8192, 8192, 0x10000, 16404
	};
	private final JJCalls jj_2_rtns[];
	private boolean jj_rescan;
	private int jj_gc;
	private Vector jj_expentries;
	private int jj_expentry[];
	private int jj_kind;
	private int jj_lasttokens[];
	private int jj_endpos;

	public static void main(String args[])
		throws ParseException
	{
		SPathParser parser = new SPathParser(System.in);
		Path p = parser.expression();
		List l = p.getSteps();
		System.out.println();
		if (p instanceof AbsolutePath)
			System.out.println("Root: /");
		for (int i = 0; i < l.size(); i++)
		{
			Step s = (Step)l.get(i);
			System.out.print("Step: " + s.getName());
			if (s.isDepthUnlimited())
				System.out.print("(*)");
			System.out.println();
		}

	}

	public SPathParser(String x)
	{
		this(((Reader) (new StringReader(x))));
	}

	public final Path expression()
		throws ParseException
	{
		Path expr;
		if (jj_2_1(0x7fffffff))
		{
			expr = absolutePath();
			jj_consume_token(0);
		} else
		{
			switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
			{
			case 2: // '\002'
			case 4: // '\004'
			case 13: // '\r'
			case 14: // '\016'
				expr = relativePath();
				jj_consume_token(0);
				break;

			default:
				jj_la1[0] = jj_gen;
				jj_consume_token(-1);
				throw new ParseException();
			}
		}
		return expr;
	}

	public final AbsolutePath absolutePath()
		throws ParseException
	{
		jj_consume_token(13);
		RelativePath relPath = relativePath();
		return new AbsolutePath(relPath);
	}

	public final RelativePath relativePath()
		throws ParseException
	{
		RelativePath relPath = null;
		Step step = step();
		switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
		{
		case 13: // '\r'
			jj_consume_token(13);
			relPath = relativePath();
			break;

		default:
			jj_la1[1] = jj_gen;
			break;
		}
		return new RelativePath(step, relPath);
	}

	public final Step step()
		throws ParseException
	{
		Token slash = null;
		Vector pl = null;
		switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
		{
		case 13: // '\r'
			slash = jj_consume_token(13);
			break;

		default:
			jj_la1[2] = jj_gen;
			break;
		}
		String nt = nameTest();
label0:
		do
			switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
			{
			default:
				jj_la1[3] = jj_gen;
				break label0;

			case 16: // '\020'
				Predicate p = predicate();
				if (pl == null)
					pl = new Vector();
				pl.add(p);
				break;
			}
		while (true);
		return new Step(slash != null, nt, pl);
	}

	public final String nameTest()
		throws ParseException
	{
		Token name;
		switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
		{
		case 14: // '\016'
			name = jj_consume_token(14);
			break;

		case 4: // '\004'
			name = jj_consume_token(4);
			break;

		case 2: // '\002'
			name = jj_consume_token(2);
			break;

		default:
			jj_la1[4] = jj_gen;
			jj_consume_token(-1);
			throw new ParseException();
		}
		return name.toString();
	}

	public final Predicate predicate()
		throws ParseException
	{
		jj_consume_token(16);
		Predicate p = attributePredicate();
		jj_consume_token(17);
		return p;
	}

	public final Predicate attributePredicate()
		throws ParseException
	{
		jj_consume_token(18);
		Token attname = jj_consume_token(2);
		jj_consume_token(19);
		Token target = jj_consume_token(1);
		return new AttributePredicate(attname.toString(), target.toString());
	}

	private final boolean jj_2_1(int xla)
	{
		jj_la = xla;
		jj_lastpos = jj_scanpos = token;
		boolean retval = !jj_3_1();
		jj_save(0, xla);
		return retval;
	}

	private final boolean jj_3R_13()
	{
		if (jj_scan_token(18))
			return true;
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		if (jj_scan_token(2))
			return true;
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		if (jj_scan_token(19))
			return true;
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		if (jj_scan_token(1))
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3_1()
	{
		if (jj_3R_2())
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3R_10()
	{
		if (jj_scan_token(4))
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3R_11()
	{
		if (jj_scan_token(2))
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3R_2()
	{
		if (jj_scan_token(13))
			return true;
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		if (jj_3R_3())
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3R_12()
	{
		if (jj_scan_token(16))
			return true;
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		if (jj_3R_13())
			return true;
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		if (jj_scan_token(17))
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3R_8()
	{
		if (jj_3R_12())
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3R_5()
	{
		if (jj_scan_token(13))
			return true;
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		if (jj_3R_3())
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3R_6()
	{
		if (jj_scan_token(13))
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3R_3()
	{
		if (jj_3R_4())
			return true;
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		Token xsp = jj_scanpos;
		if (jj_3R_5())
			jj_scanpos = xsp;
		else
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		return false;
	}

	private final boolean jj_3R_4()
	{
		Token xsp = jj_scanpos;
		if (jj_3R_6())
			jj_scanpos = xsp;
		else
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		if (jj_3R_7())
			return true;
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		do
		{
			xsp = jj_scanpos;
			if (jj_3R_8())
			{
				jj_scanpos = xsp;
				break;
			}
			if (jj_la == 0 && jj_scanpos == jj_lastpos)
				return false;
		} while (true);
		return false;
	}

	private final boolean jj_3R_9()
	{
		if (jj_scan_token(14))
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3R_7()
	{
		Token xsp = jj_scanpos;
		if (jj_3R_9())
		{
			jj_scanpos = xsp;
			if (jj_3R_10())
			{
				jj_scanpos = xsp;
				if (jj_3R_11())
					return true;
				if (jj_la == 0 && jj_scanpos == jj_lastpos)
					return false;
			} else
			if (jj_la == 0 && jj_scanpos == jj_lastpos)
				return false;
		} else
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		return false;
	}

	public SPathParser(InputStream stream)
	{
		lookingAhead = false;
		jj_la1 = new int[5];
		jj_2_rtns = new JJCalls[1];
		jj_rescan = false;
		jj_gc = 0;
		jj_expentries = new Vector();
		jj_kind = -1;
		jj_lasttokens = new int[100];
		jj_input_stream = new ASCII_UCodeESC_CharStream(stream, 1, 1);
		token_source = new SPathParserTokenManager(jj_input_stream);
		token = new Token();
		jj_ntk = -1;
		jj_gen = 0;
		for (int i = 0; i < 5; i++)
			jj_la1[i] = -1;

		for (int i = 0; i < jj_2_rtns.length; i++)
			jj_2_rtns[i] = new JJCalls();

	}

	public void ReInit(InputStream stream)
	{
		jj_input_stream.ReInit(stream, 1, 1);
		token_source.ReInit(jj_input_stream);
		token = new Token();
		jj_ntk = -1;
		jj_gen = 0;
		for (int i = 0; i < 5; i++)
			jj_la1[i] = -1;

		for (int i = 0; i < jj_2_rtns.length; i++)
			jj_2_rtns[i] = new JJCalls();

	}

	public SPathParser(Reader stream)
	{
		lookingAhead = false;
		jj_la1 = new int[5];
		jj_2_rtns = new JJCalls[1];
		jj_rescan = false;
		jj_gc = 0;
		jj_expentries = new Vector();
		jj_kind = -1;
		jj_lasttokens = new int[100];
		jj_input_stream = new ASCII_UCodeESC_CharStream(stream, 1, 1);
		token_source = new SPathParserTokenManager(jj_input_stream);
		token = new Token();
		jj_ntk = -1;
		jj_gen = 0;
		for (int i = 0; i < 5; i++)
			jj_la1[i] = -1;

		for (int i = 0; i < jj_2_rtns.length; i++)
			jj_2_rtns[i] = new JJCalls();

	}

	public void ReInit(Reader stream)
	{
		jj_input_stream.ReInit(stream, 1, 1);
		token_source.ReInit(jj_input_stream);
		token = new Token();
		jj_ntk = -1;
		jj_gen = 0;
		for (int i = 0; i < 5; i++)
			jj_la1[i] = -1;

		for (int i = 0; i < jj_2_rtns.length; i++)
			jj_2_rtns[i] = new JJCalls();

	}

	public SPathParser(SPathParserTokenManager tm)
	{
		lookingAhead = false;
		jj_la1 = new int[5];
		jj_2_rtns = new JJCalls[1];
		jj_rescan = false;
		jj_gc = 0;
		jj_expentries = new Vector();
		jj_kind = -1;
		jj_lasttokens = new int[100];
		token_source = tm;
		token = new Token();
		jj_ntk = -1;
		jj_gen = 0;
		for (int i = 0; i < 5; i++)
			jj_la1[i] = -1;

		for (int i = 0; i < jj_2_rtns.length; i++)
			jj_2_rtns[i] = new JJCalls();

	}

	public void ReInit(SPathParserTokenManager tm)
	{
		token_source = tm;
		token = new Token();
		jj_ntk = -1;
		jj_gen = 0;
		for (int i = 0; i < 5; i++)
			jj_la1[i] = -1;

		for (int i = 0; i < jj_2_rtns.length; i++)
			jj_2_rtns[i] = new JJCalls();

	}

	private final Token jj_consume_token(int kind)
		throws ParseException
	{
		Token oldToken;
		if ((oldToken = token).next != null)
			token = token.next;
		else
			token = token.next = token_source.getNextToken();
		jj_ntk = -1;
		if (token.kind == kind)
		{
			jj_gen++;
			if (++jj_gc > 100)
			{
				jj_gc = 0;
				for (int i = 0; i < jj_2_rtns.length; i++)
				{
					for (JJCalls c = jj_2_rtns[i]; c != null; c = c.next)
						if (c.gen < jj_gen)
							c.first = null;

				}

			}
			return token;
		} else
		{
			token = oldToken;
			jj_kind = kind;
			throw generateParseException();
		}
	}

	private final boolean jj_scan_token(int kind)
	{
		if (jj_scanpos == jj_lastpos)
		{
			jj_la--;
			if (jj_scanpos.next == null)
				jj_lastpos = jj_scanpos = jj_scanpos.next = token_source.getNextToken();
			else
				jj_lastpos = jj_scanpos = jj_scanpos.next;
		} else
		{
			jj_scanpos = jj_scanpos.next;
		}
		if (jj_rescan)
		{
			int i = 0;
			Token tok;
			for (tok = token; tok != null && tok != jj_scanpos; tok = tok.next)
				i++;

			if (tok != null)
				jj_add_error_token(kind, i);
		}
		return jj_scanpos.kind != kind;
	}

	public final Token getNextToken()
	{
		if (token.next != null)
			token = token.next;
		else
			token = token.next = token_source.getNextToken();
		jj_ntk = -1;
		jj_gen++;
		return token;
	}

	public final Token getToken(int index)
	{
		Token t = lookingAhead ? jj_scanpos : token;
		for (int i = 0; i < index; i++)
			if (t.next != null)
				t = t.next;
			else
				t = t.next = token_source.getNextToken();

		return t;
	}

	private final int jj_ntk()
	{
		if ((jj_nt = token.next) == null)
			return jj_ntk = (token.next = token_source.getNextToken()).kind;
		else
			return jj_ntk = jj_nt.kind;
	}

	private void jj_add_error_token(int kind, int pos)
	{
		if (pos >= 100)
			return;
		if (pos == jj_endpos + 1)
			jj_lasttokens[jj_endpos++] = kind;
		else
		if (jj_endpos != 0)
		{
			jj_expentry = new int[jj_endpos];
			for (int i = 0; i < jj_endpos; i++)
				jj_expentry[i] = jj_lasttokens[i];

			boolean exists = false;
			Enumeration enum_ = jj_expentries.elements();
label0:
			do
			{
				int oldentry[];
				do
				{
					if (!enum_.hasMoreElements())
						break label0;
					oldentry = (int[])enum_.nextElement();
				} while (oldentry.length != jj_expentry.length);
				exists = true;
				int i = 0;
				do
				{
					if (i >= jj_expentry.length)
						break;
					if (oldentry[i] != jj_expentry[i])
					{
						exists = false;
						break;
					}
					i++;
				} while (true);
			} while (!exists);
			if (!exists)
				jj_expentries.addElement(jj_expentry);
			if (pos != 0)
				jj_lasttokens[(jj_endpos = pos) - 1] = kind;
		}
	}

	public final ParseException generateParseException()
	{
		jj_expentries.removeAllElements();
		boolean la1tokens[] = new boolean[20];
		for (int i = 0; i < 20; i++)
			la1tokens[i] = false;

		if (jj_kind >= 0)
		{
			la1tokens[jj_kind] = true;
			jj_kind = -1;
		}
		for (int i = 0; i < 5; i++)
		{
			if (jj_la1[i] != jj_gen)
				continue;
			for (int j = 0; j < 32; j++)
				if ((jj_la1_0[i] & 1 << j) != 0)
					la1tokens[j] = true;

		}

		for (int i = 0; i < 20; i++)
			if (la1tokens[i])
			{
				jj_expentry = new int[1];
				jj_expentry[0] = i;
				jj_expentries.addElement(jj_expentry);
			}

		jj_endpos = 0;
		jj_rescan_token();
		jj_add_error_token(0, 0);
		int exptokseq[][] = new int[jj_expentries.size()][];
		for (int i = 0; i < jj_expentries.size(); i++)
			exptokseq[i] = (int[])jj_expentries.elementAt(i);

		return new ParseException(token, exptokseq, SPathParserConstants.tokenImage);
	}

	public final void enable_tracing()
	{
	}

	public final void disable_tracing()
	{
	}

	private final void jj_rescan_token()
	{
		jj_rescan = true;
		for (int i = 0; i < 1; i++)
		{
			JJCalls p = jj_2_rtns[i];
			do
			{
				if (p.gen > jj_gen)
				{
					jj_la = p.arg;
					jj_lastpos = jj_scanpos = p.first;
					switch (i)
					{
					case 0: // '\0'
						jj_3_1();
						break;
					}
				}
				p = p.next;
			} while (p != null);
		}

		jj_rescan = false;
	}

	private final void jj_save(int index, int xla)
	{
		JJCalls p = jj_2_rtns[index];
		do
		{
			if (p.gen <= jj_gen)
				break;
			if (p.next == null)
			{
				p = p.next = new JJCalls();
				break;
			}
			p = p.next;
		} while (true);
		p.gen = (jj_gen + xla) - jj_la;
		p.first = token;
		p.arg = xla;
	}
}
