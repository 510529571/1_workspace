// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JstlFmtTLV.java

package org.apache.taglibs.standard.tlv;

import java.util.*;
import javax.servlet.jsp.tagext.PageData;
import javax.servlet.jsp.tagext.ValidationMessage;
import org.apache.taglibs.standard.resources.Resources;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

// Referenced classes of package org.apache.taglibs.standard.tlv:
//			JstlBaseTLV

public class JstlFmtTLV extends JstlBaseTLV
{
	private class Handler extends DefaultHandler
	{

		private int depth;
		private Stack messageDepths;
		private String lastElementName;
		private boolean bodyNecessary;
		private boolean bodyIllegal;

		public void startElement(String ns, String ln, String qn, Attributes a)
		{
			if (ln == null)
				ln = getLocalPart(qn);
			if (qn.equals("jsp:text"))
				return;
			if (bodyIllegal)
				fail(Resources.getMessage("TLV_ILLEGAL_BODY", lastElementName));
			Set expAtts;
			if (qn.startsWith(prefix + ":") && (expAtts = (Set)config.get(ln)) != null)
			{
				for (int i = 0; i < a.getLength(); i++)
				{
					String attName = a.getLocalName(i);
					if (!expAtts.contains(attName))
						continue;
					String vMsg = validateExpression(ln, attName, a.getValue(i));
					if (vMsg != null)
						fail(vMsg);
				}

			}
			if (qn.startsWith(prefix + ":") && !hasNoInvalidScope(a))
				fail(Resources.getMessage("TLV_INVALID_ATTRIBUTE", "scope", qn, a.getValue("scope")));
			if (qn.startsWith(prefix + ":") && hasEmptyVar(a))
				fail(Resources.getMessage("TLV_EMPTY_VAR", qn));
			if (qn.startsWith(prefix + ":") && !isFmtTag(ns, ln, "setLocale") && !isFmtTag(ns, ln, "setBundle") && !isFmtTag(ns, ln, "setTimeZone") && hasDanglingScope(a))
				fail(Resources.getMessage("TLV_DANGLING_SCOPE", qn));
			if (isFmtTag(ns, ln, "param") && messageDepths.empty())
				fail(Resources.getMessage("PARAM_OUTSIDE_MESSAGE"));
			if (isFmtTag(ns, ln, "message"))
				messageDepths.push(new Integer(depth));
			bodyIllegal = false;
			bodyNecessary = false;
			if (isFmtTag(ns, ln, "param") || isFmtTag(ns, ln, "formatNumber") || isFmtTag(ns, ln, "parseNumber") || isFmtTag(ns, ln, "parseDate"))
			{
				if (hasAttribute(a, "value"))
					bodyIllegal = true;
				else
					bodyNecessary = true;
			} else
			if (isFmtTag(ns, ln, "message") && !hasAttribute(a, "key"))
				bodyNecessary = true;
			else
			if (isFmtTag(ns, ln, "bundle") && hasAttribute(a, "prefix"))
				bodyNecessary = true;
			lastElementName = qn;
			lastElementId = a.getValue("http://java.sun.com/JSP/Page", "id");
			depth++;
		}

		public void characters(char ch[], int start, int length)
		{
			bodyNecessary = false;
			String s = (new String(ch, start, length)).trim();
			if (s.equals(""))
				return;
			if (bodyIllegal)
				fail(Resources.getMessage("TLV_ILLEGAL_BODY", lastElementName));
		}

		public void endElement(String ns, String ln, String qn)
		{
			if (qn.equals("jsp:text"))
				return;
			if (bodyNecessary)
				fail(Resources.getMessage("TLV_MISSING_BODY", lastElementName));
			bodyIllegal = false;
			if (isFmtTag(ns, ln, "message"))
				messageDepths.pop();
			depth--;
		}

		private Handler()
		{
			depth = 0;
			messageDepths = new Stack();
			lastElementName = null;
			bodyNecessary = false;
			bodyIllegal = false;
		}

	}


	private final String SETLOCALE = "setLocale";
	private final String SETBUNDLE = "setBundle";
	private final String SETTIMEZONE = "setTimeZone";
	private final String BUNDLE = "bundle";
	private final String MESSAGE = "message";
	private final String MESSAGE_PARAM = "param";
	private final String FORMAT_NUMBER = "formatNumber";
	private final String PARSE_NUMBER = "parseNumber";
	private final String PARSE_DATE = "parseDate";
	private final String JSP_TEXT = "jsp:text";
	private final String EVAL = "evaluator";
	private final String MESSAGE_KEY = "key";
	private final String BUNDLE_PREFIX = "prefix";
	private final String VALUE = "value";

	public JstlFmtTLV()
	{
	}

	public ValidationMessage[] validate(String prefix, String uri, PageData page)
	{
		return super.validate(2, prefix, uri, page);
	}

	protected DefaultHandler getHandler()
	{
		return new Handler();
	}
}
