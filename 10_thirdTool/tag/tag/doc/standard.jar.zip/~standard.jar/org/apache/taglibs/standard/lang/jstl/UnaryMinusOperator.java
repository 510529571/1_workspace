// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UnaryMinusOperator.java

package org.apache.taglibs.standard.lang.jstl;


// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			UnaryOperator, ELException, PrimitiveObjects, Coercions, 
//			Logger, Constants

public class UnaryMinusOperator extends UnaryOperator
{

	public static final UnaryMinusOperator SINGLETON = new UnaryMinusOperator();

	public UnaryMinusOperator()
	{
	}

	public String getOperatorSymbol()
	{
		return "-";
	}

	public Object apply(Object pValue, Object pContext, Logger pLogger)
		throws ELException
	{
		if (pValue == null)
			return PrimitiveObjects.getInteger(0);
		if (pValue instanceof String)
			if (Coercions.isFloatingPointString(pValue))
			{
				double dval = Coercions.coerceToPrimitiveNumber(pValue, java.lang.Double.class, pLogger).doubleValue();
				return PrimitiveObjects.getDouble(-dval);
			} else
			{
				long lval = Coercions.coerceToPrimitiveNumber(pValue, java.lang.Long.class, pLogger).longValue();
				return PrimitiveObjects.getLong(-lval);
			}
		if (pValue instanceof Byte)
			return PrimitiveObjects.getByte((byte)(-((Byte)pValue).byteValue()));
		if (pValue instanceof Short)
			return PrimitiveObjects.getShort((short)(-((Short)pValue).shortValue()));
		if (pValue instanceof Integer)
			return PrimitiveObjects.getInteger(-((Integer)pValue).intValue());
		if (pValue instanceof Long)
			return PrimitiveObjects.getLong(-((Long)pValue).longValue());
		if (pValue instanceof Float)
			return PrimitiveObjects.getFloat(-((Float)pValue).floatValue());
		if (pValue instanceof Double)
			return PrimitiveObjects.getDouble(-((Double)pValue).doubleValue());
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.UNARY_OP_BAD_TYPE, getOperatorSymbol(), pValue.getClass().getName());
		return PrimitiveObjects.getInteger(0);
	}

}
