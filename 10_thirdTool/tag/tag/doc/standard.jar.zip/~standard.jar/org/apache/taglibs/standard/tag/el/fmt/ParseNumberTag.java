// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParseNumberTag.java

package org.apache.taglibs.standard.tag.el.fmt;

import java.util.Locale;
import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.tag.common.fmt.ParseNumberSupport;
import org.apache.taglibs.standard.tag.common.fmt.SetLocaleSupport;

public class ParseNumberTag extends ParseNumberSupport
{

	private String value_;
	private String type_;
	private String pattern_;
	private String parseLocale_;
	private String integerOnly_;

	public ParseNumberTag()
	{
		init();
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setValue(String value_)
	{
		this.value_ = value_;
		valueSpecified = true;
	}

	public void setType(String type_)
	{
		this.type_ = type_;
	}

	public void setPattern(String pattern_)
	{
		this.pattern_ = pattern_;
	}

	public void setParseLocale(String parseLocale_)
	{
		this.parseLocale_ = parseLocale_;
	}

	public void setIntegerOnly(String integerOnly_)
	{
		this.integerOnly_ = integerOnly_;
		integerOnlySpecified = true;
	}

	private void init()
	{
		value_ = type_ = pattern_ = parseLocale_ = integerOnly_ = null;
	}

	private void evaluateExpressions()
		throws JspException
	{
		Object obj = null;
		if (value_ != null)
			value = (String)ExpressionEvaluatorManager.evaluate("value", value_, java.lang.String.class, this, pageContext);
		if (type_ != null)
			type = (String)ExpressionEvaluatorManager.evaluate("type", type_, java.lang.String.class, this, pageContext);
		if (pattern_ != null)
			pattern = (String)ExpressionEvaluatorManager.evaluate("pattern", pattern_, java.lang.String.class, this, pageContext);
		if (parseLocale_ != null)
		{
			obj = ExpressionEvaluatorManager.evaluate("parseLocale", parseLocale_, java.lang.Object.class, this, pageContext);
			if (obj != null)
				if (obj instanceof Locale)
				{
					parseLocale = (Locale)obj;
				} else
				{
					String localeStr = (String)obj;
					if (!"".equals(localeStr))
						parseLocale = SetLocaleSupport.parseLocale(localeStr);
				}
		}
		if (integerOnly_ != null)
		{
			obj = ExpressionEvaluatorManager.evaluate("integerOnly", integerOnly_, java.lang.Boolean.class, this, pageContext);
			if (obj != null)
				isIntegerOnly = ((Boolean)obj).booleanValue();
		}
	}
}
