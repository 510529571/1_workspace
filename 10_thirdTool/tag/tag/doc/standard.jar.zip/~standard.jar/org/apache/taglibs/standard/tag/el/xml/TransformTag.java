// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TransformTag.java

package org.apache.taglibs.standard.tag.el.xml;

import javax.servlet.jsp.JspException;
import javax.xml.transform.Result;
import org.apache.taglibs.standard.tag.common.xml.TransformSupport;
import org.apache.taglibs.standard.tag.el.core.ExpressionUtil;

public class TransformTag extends TransformSupport
{

	private String xml_;
	private String xmlSystemId_;
	private String xslt_;
	private String xsltSystemId_;
	private String result_;

	public TransformTag()
	{
		init();
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setXml(String xml_)
	{
		this.xml_ = xml_;
	}

	public void setXmlSystemId(String xmlSystemId_)
	{
		this.xmlSystemId_ = xmlSystemId_;
	}

	public void setXslt(String xslt_)
	{
		this.xslt_ = xslt_;
	}

	public void setXsltSystemId(String xsltSystemId_)
	{
		this.xsltSystemId_ = xsltSystemId_;
	}

	public void setResult(String result_)
	{
		this.result_ = result_;
	}

	private void init()
	{
		xml_ = xmlSystemId = xslt_ = xsltSystemId_ = result_ = null;
	}

	private void evaluateExpressions()
		throws JspException
	{
		xml = ExpressionUtil.evalNotNull("transform", "xml", xml_, java.lang.Object.class, this, pageContext);
		xmlSystemId = (String)ExpressionUtil.evalNotNull("transform", "xmlSystemId", xmlSystemId_, java.lang.String.class, this, pageContext);
		xslt = ExpressionUtil.evalNotNull("transform", "xslt", xslt_, java.lang.Object.class, this, pageContext);
		xsltSystemId = (String)ExpressionUtil.evalNotNull("transform", "xsltSystemId", xsltSystemId_, java.lang.String.class, this, pageContext);
		result = (Result)ExpressionUtil.evalNotNull("transform", "result", result_, javax.xml.transform.Result.class, this, pageContext);
	}
}
