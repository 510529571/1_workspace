// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DateParamTagSupport.java

package org.apache.taglibs.standard.tag.common.sql;

import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.jstl.sql.SQLExecutionTag;
import javax.servlet.jsp.tagext.TagSupport;
import org.apache.taglibs.standard.resources.Resources;

public abstract class DateParamTagSupport extends TagSupport
{

	private static final String TIMESTAMP_TYPE = "timestamp";
	private static final String TIME_TYPE = "time";
	private static final String DATE_TYPE = "date";
	protected String type;
	protected java.util.Date value;

	public DateParamTagSupport()
	{
		init();
	}

	private void init()
	{
		value = null;
		type = null;
	}

	public int doEndTag()
		throws JspException
	{
		SQLExecutionTag parent = (SQLExecutionTag)findAncestorWithClass(this, javax.servlet.jsp.jstl.sql.SQLExecutionTag.class);
		if (parent == null)
			throw new JspTagException(Resources.getMessage("SQL_PARAM_OUTSIDE_PARENT"));
		if (value != null)
			convertValue();
		parent.addSQLParameter(value);
		return 6;
	}

	private void convertValue()
		throws JspException
	{
		if (type == null || type.equalsIgnoreCase("timestamp"))
		{
			if (!(value instanceof Timestamp))
				value = new Timestamp(value.getTime());
		} else
		if (type.equalsIgnoreCase("time"))
		{
			if (!(value instanceof Time))
				value = new Time(value.getTime());
		} else
		if (type.equalsIgnoreCase("date"))
		{
			if (!(value instanceof Date))
				value = new Date(value.getTime());
		} else
		{
			throw new JspException(Resources.getMessage("SQL_DATE_PARAM_INVALID_TYPE", type));
		}
	}
}
