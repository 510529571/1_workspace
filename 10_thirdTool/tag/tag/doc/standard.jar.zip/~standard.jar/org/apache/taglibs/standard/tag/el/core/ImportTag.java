// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ImportTag.java

package org.apache.taglibs.standard.tag.el.core;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.tag.common.core.ImportSupport;
import org.apache.taglibs.standard.tag.common.core.NullAttributeException;

// Referenced classes of package org.apache.taglibs.standard.tag.el.core:
//			ExpressionUtil

public class ImportTag extends ImportSupport
{

	private String context_;
	private String charEncoding_;
	private String url_;

	public ImportTag()
	{
		init();
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setUrl(String url_)
	{
		this.url_ = url_;
	}

	public void setContext(String context_)
	{
		this.context_ = context_;
	}

	public void setCharEncoding(String charEncoding_)
	{
		this.charEncoding_ = charEncoding_;
	}

	private void init()
	{
		url_ = context_ = charEncoding_ = null;
	}

	private void evaluateExpressions()
		throws JspException
	{
		url = (String)ExpressionUtil.evalNotNull("import", "url", url_, java.lang.String.class, this, pageContext);
		if (url == null || url.equals(""))
		{
			throw new NullAttributeException("import", "url");
		} else
		{
			context = (String)ExpressionUtil.evalNotNull("import", "context", context_, java.lang.String.class, this, pageContext);
			charEncoding = (String)ExpressionUtil.evalNotNull("import", "charEncoding", charEncoding_, java.lang.String.class, this, pageContext);
			return;
		}
	}
}
