// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParserTest.java

package org.apache.taglibs.standard.lang.jstl.test;

import java.io.*;
import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.lang.jstl.Evaluator;

public class ParserTest
{

	public ParserTest()
	{
	}

	public static void runTests(DataInput pIn, PrintStream pOut)
		throws IOException
	{
		do
		{
			String str = pIn.readLine();
			if (str != null)
			{
				if (str.startsWith("#") || "".equals(str.trim()))
				{
					pOut.println(str);
				} else
				{
					if ("@@non-ascii".equals(str))
						str = "?";
					pOut.println("Attribute value: " + str);
					try
					{
						String result = Evaluator.parseAndRender(str);
						pOut.println("Parses to: " + result);
					}
					catch (JspException exc)
					{
						pOut.println("Causes an error: " + exc.getMessage());
					}
				}
			} else
			{
				return;
			}
		} while (true);
	}

	public static void runTests(File pInputFile, File pOutputFile)
		throws IOException
	{
		FileInputStream fin;
		FileOutputStream fout;
		fin = null;
		fout = null;
		DataInputStream din;
		fin = new FileInputStream(pInputFile);
		BufferedInputStream bin = new BufferedInputStream(fin);
		din = new DataInputStream(bin);
		fout = new FileOutputStream(pOutputFile);
		BufferedOutputStream bout = new BufferedOutputStream(fout);
		PrintStream pout = new PrintStream(bout);
		runTests(((DataInput) (din)), pout);
		pout.flush();
		if (fout != null)
			fout.close();
		break MISSING_BLOCK_LABEL_100;
		Exception exception;
		exception;
		if (fout != null)
			fout.close();
		throw exception;
		if (fin != null)
			fin.close();
		break MISSING_BLOCK_LABEL_124;
		Exception exception1;
		exception1;
		if (fin != null)
			fin.close();
		throw exception1;
	}

	public static boolean isDifferentFiles(DataInput pIn1, DataInput pIn2)
		throws IOException
	{
		String str1;
		String str2;
		do
		{
			str1 = pIn1.readLine();
			str2 = pIn2.readLine();
			if (str1 == null && str2 == null)
				return false;
			if (str1 == null || str2 == null)
				return true;
		} while (str1.equals(str2));
		return true;
	}

	public static boolean isDifferentFiles(File pFile1, File pFile2)
		throws IOException
	{
		FileInputStream fin1 = null;
		DataInputStream din1;
		FileInputStream fin2;
		fin1 = new FileInputStream(pFile1);
		BufferedInputStream bin1 = new BufferedInputStream(fin1);
		din1 = new DataInputStream(bin1);
		fin2 = null;
		boolean flag;
		fin2 = new FileInputStream(pFile2);
		BufferedInputStream bin2 = new BufferedInputStream(fin2);
		DataInputStream din2 = new DataInputStream(bin2);
		flag = isDifferentFiles(((DataInput) (din1)), ((DataInput) (din2)));
		if (fin2 != null)
			fin2.close();
		if (fin1 != null)
			fin1.close();
		return flag;
		Exception exception;
		exception;
		if (fin2 != null)
			fin2.close();
		throw exception;
		Exception exception1;
		exception1;
		if (fin1 != null)
			fin1.close();
		throw exception1;
	}

	public static void main(String pArgs[])
		throws IOException
	{
		if (pArgs.length != 2 && pArgs.length != 3)
		{
			usage();
			System.exit(1);
		}
		File in = new File(pArgs[0]);
		File out = new File(pArgs[1]);
		runTests(in, out);
		if (pArgs.length > 2)
		{
			File compare = new File(pArgs[2]);
			if (isDifferentFiles(out, compare))
				System.out.println("Test failure - output file " + out + " differs from expected output file " + compare);
			else
				System.out.println("tests passed");
		}
	}

	static void usage()
	{
		System.err.println("usage: java org.apache.taglibs.standard.lang.jstl.test.ParserTest {input file} {output file} [{compare file}]");
	}
}
