// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TransactionTagSupport.java

package org.apache.taglibs.standard.tag.common.sql;

import java.sql.Connection;
import java.sql.SQLException;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.jsp.tagext.TryCatchFinally;
import javax.sql.DataSource;
import org.apache.taglibs.standard.resources.Resources;

// Referenced classes of package org.apache.taglibs.standard.tag.common.sql:
//			DataSourceUtil

public abstract class TransactionTagSupport extends TagSupport
	implements TryCatchFinally
{

	private static final String TRANSACTION_READ_COMMITTED = "read_committed";
	private static final String TRANSACTION_READ_UNCOMMITTED = "read_uncommitted";
	private static final String TRANSACTION_REPEATABLE_READ = "repeatable_read";
	private static final String TRANSACTION_SERIALIZABLE = "serializable";
	protected Object rawDataSource;
	protected boolean dataSourceSpecified;
	private Connection conn;
	private int isolation;
	private int origIsolation;

	public TransactionTagSupport()
	{
		init();
	}

	private void init()
	{
		conn = null;
		dataSourceSpecified = false;
		rawDataSource = null;
		isolation = 0;
	}

	public int doStartTag()
		throws JspException
	{
		if (rawDataSource == null && dataSourceSpecified)
			throw new JspException(Resources.getMessage("SQL_DATASOURCE_NULL"));
		DataSource dataSource = DataSourceUtil.getDataSource(rawDataSource, pageContext);
		try
		{
			conn = dataSource.getConnection();
			origIsolation = conn.getTransactionIsolation();
			if (origIsolation == 0)
				throw new JspTagException(Resources.getMessage("TRANSACTION_NO_SUPPORT"));
			if (isolation != 0 && isolation != origIsolation)
				conn.setTransactionIsolation(isolation);
			conn.setAutoCommit(false);
		}
		catch (SQLException e)
		{
			throw new JspTagException(Resources.getMessage("ERROR_GET_CONNECTION", e.toString()), e);
		}
		return 1;
	}

	public int doEndTag()
		throws JspException
	{
		try
		{
			conn.commit();
		}
		catch (SQLException e)
		{
			throw new JspTagException(Resources.getMessage("TRANSACTION_COMMIT_ERROR", e.toString()), e);
		}
		return 6;
	}

	public void doCatch(Throwable t)
		throws Throwable
	{
		if (conn != null)
			try
			{
				conn.rollback();
			}
			catch (SQLException e) { }
		throw t;
	}

	public void doFinally()
	{
		if (conn != null)
			try
			{
				if (isolation != 0 && isolation != origIsolation)
					conn.setTransactionIsolation(origIsolation);
				conn.setAutoCommit(true);
				conn.close();
			}
			catch (SQLException e) { }
		conn = null;
	}

	public void release()
	{
		init();
	}

	public void setIsolation(String iso)
		throws JspTagException
	{
		if ("read_committed".equals(iso))
			isolation = 2;
		else
		if ("read_uncommitted".equals(iso))
			isolation = 1;
		else
		if ("repeatable_read".equals(iso))
			isolation = 4;
		else
		if ("serializable".equals(iso))
			isolation = 8;
		else
			throw new JspTagException(Resources.getMessage("TRANSACTION_INVALID_ISOLATION"));
	}

	public Connection getSharedConnection()
	{
		return conn;
	}
}
