// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   XPathUtil.java

package org.apache.taglibs.standard.tag.common.xml;

import java.io.PrintStream;
import java.util.*;
import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.TransformerException;
import org.apache.taglibs.standard.resources.Resources;
import org.apache.xml.utils.QName;
import org.apache.xpath.VariableStack;
import org.apache.xpath.XPathContext;
import org.apache.xpath.objects.*;
import org.w3c.dom.*;

// Referenced classes of package org.apache.taglibs.standard.tag.common.xml:
//			JSTLPrefixResolver, JSTLNodeList, UnresolvableException, ForEachTag, 
//			JSTLXPathAPI

public class XPathUtil
{
	protected class JstlVariableContext extends VariableStack
	{

		public XObject getVariableOrParam(XPathContext xctxt, QName qname)
			throws TransformerException, UnresolvableException
		{
			String namespace;
			String prefix;
			String localName;
			namespace = qname.getNamespaceURI();
			prefix = qname.getPrefix();
			localName = qname.getLocalName();
			Object varObject;
			XObject newXObject;
			varObject = getVariableValue(namespace, prefix, localName);
			newXObject = new XObject(varObject);
			if (!Class.forName("org.w3c.dom.Document").isInstance(varObject))
				break MISSING_BLOCK_LABEL_149;
			NodeList nl = ((Document)varObject).getChildNodes();
			Vector nodeVector = new Vector();
			for (int i = 0; i < nl.getLength(); i++)
			{
				Node currNode = nl.item(i);
				if (currNode.getNodeType() == 1)
					nodeVector.addElement(currNode);
			}

			JSTLNodeList jstlNodeList = new JSTLNodeList(nodeVector);
			newXObject = new XNodeSetForDOM(jstlNodeList, xctxt);
			return newXObject;
			JSTLNodeList jstlNodeList;
			if (!Class.forName("org.apache.taglibs.standard.tag.common.xml.JSTLNodeList").isInstance(varObject))
				break MISSING_BLOCK_LABEL_217;
			jstlNodeList = (JSTLNodeList)varObject;
			if (jstlNodeList.getLength() == 1 && !Class.forName("org.w3c.dom.Node").isInstance(jstlNodeList.elementAt(0)))
			{
				varObject = jstlNodeList.elementAt(0);
				break MISSING_BLOCK_LABEL_217;
			}
			return new XNodeSetForDOM(jstlNodeList, xctxt);
			if (Class.forName("org.w3c.dom.Node").isInstance(varObject))
				newXObject = new XNodeSetForDOM(new JSTLNodeList((Node)varObject), xctxt);
			else
			if (Class.forName("java.lang.String").isInstance(varObject))
				newXObject = new XString((String)varObject);
			else
			if (Class.forName("java.lang.Boolean").isInstance(varObject))
				newXObject = new XBoolean((Boolean)varObject);
			else
			if (Class.forName("java.lang.Number").isInstance(varObject))
				newXObject = new XNumber((Number)varObject);
			return newXObject;
			ClassNotFoundException cnfe;
			cnfe;
			System.out.println("CLASS NOT FOUND EXCEPTION :" + cnfe);
			return null;
		}

		public Object getVariableValue(String namespace, String prefix, String localName)
			throws UnresolvableException
		{
			if (prefix == null || prefix.equals(""))
				return notNull(pageContext.findAttribute(localName), prefix, localName);
			if (prefix.equals("pageScope"))
				return notNull(pageContext.getAttribute(localName, 1), prefix, localName);
			if (prefix.equals("requestScope"))
				return notNull(pageContext.getAttribute(localName, 2), prefix, localName);
			if (prefix.equals("sessionScope"))
				return notNull(pageContext.getAttribute(localName, 3), prefix, localName);
			if (prefix.equals("applicationScope"))
				return notNull(pageContext.getAttribute(localName, 4), prefix, localName);
			if (prefix.equals("param"))
				return notNull(pageContext.getRequest().getParameter(localName), prefix, localName);
			if (prefix.equals("initParam"))
				return notNull(pageContext.getServletContext().getInitParameter(localName), prefix, localName);
			if (prefix.equals("header"))
			{
				HttpServletRequest hsr = (HttpServletRequest)pageContext.getRequest();
				return notNull(hsr.getHeader(localName), prefix, localName);
			}
			if (prefix.equals("cookie"))
			{
				HttpServletRequest hsr = (HttpServletRequest)pageContext.getRequest();
				Cookie c[] = hsr.getCookies();
				for (int i = 0; i < c.length; i++)
					if (c[i].getName().equals(localName))
						return c[i].getValue();

				throw new UnresolvableException("$" + prefix + ":" + localName);
			} else
			{
				throw new UnresolvableException("$" + prefix + ":" + localName);
			}
		}

		private Object notNull(Object o, String prefix, String localName)
			throws UnresolvableException
		{
			if (o == null)
				throw new UnresolvableException("$" + (prefix != null ? prefix + ":" : "") + localName);
			else
				return o;
		}

		public JstlVariableContext()
		{
		}
	}


	int globalVarSize;
	private static final String PAGE_NS_URL = "http://java.sun.com/jstl/xpath/page";
	private static final String REQUEST_NS_URL = "http://java.sun.com/jstl/xpath/request";
	private static final String SESSION_NS_URL = "http://java.sun.com/jstl/xpath/session";
	private static final String APP_NS_URL = "http://java.sun.com/jstl/xpath/app";
	private static final String PARAM_NS_URL = "http://java.sun.com/jstl/xpath/param";
	private static final String INITPARAM_NS_URL = "http://java.sun.com/jstl/xpath/initParam";
	private static final String COOKIE_NS_URL = "http://java.sun.com/jstl/xpath/cookie";
	private static final String HEADER_NS_URL = "http://java.sun.com/jstl/xpath/header";
	private static final String PAGE_P = "pageScope";
	private static final String REQUEST_P = "requestScope";
	private static final String SESSION_P = "sessionScope";
	private static final String APP_P = "applicationScope";
	private static final String PARAM_P = "param";
	private static final String INITPARAM_P = "initParam";
	private static final String COOKIE_P = "cookie";
	private static final String HEADER_P = "header";
	private PageContext pageContext;
	private static HashMap exprCache;
	private static JSTLPrefixResolver jstlPrefixResolver = null;
	static DocumentBuilderFactory dbf = null;
	static DocumentBuilder db = null;
	static Document d = null;
	String modifiedXPath;

	public XPathUtil(PageContext pc)
	{
		globalVarSize = 0;
		modifiedXPath = null;
		pageContext = pc;
	}

	public Vector getVariableQNames()
	{
		globalVarSize = 0;
		Vector variableVector = new Vector();
		for (Enumeration enum_ = pageContext.getAttributeNamesInScope(1); enum_.hasMoreElements();)
		{
			String varName = (String)enum_.nextElement();
			QName varQName = new QName("http://java.sun.com/jstl/xpath/page", "pageScope", varName);
			variableVector.addElement(varQName);
			globalVarSize++;
			variableVector.addElement(new QName(null, varName));
			globalVarSize++;
		}

		for (Enumeration enum_ = pageContext.getAttributeNamesInScope(2); enum_.hasMoreElements();)
		{
			String varName = (String)enum_.nextElement();
			QName varQName = new QName("http://java.sun.com/jstl/xpath/request", "requestScope", varName);
			variableVector.addElement(varQName);
			globalVarSize++;
			variableVector.addElement(new QName(null, varName));
			globalVarSize++;
		}

		for (Enumeration enum_ = pageContext.getAttributeNamesInScope(3); enum_.hasMoreElements();)
		{
			String varName = (String)enum_.nextElement();
			QName varQName = new QName("http://java.sun.com/jstl/xpath/session", "sessionScope", varName);
			variableVector.addElement(varQName);
			globalVarSize++;
			variableVector.addElement(new QName(null, varName));
			globalVarSize++;
		}

		for (Enumeration enum_ = pageContext.getAttributeNamesInScope(4); enum_.hasMoreElements();)
		{
			String varName = (String)enum_.nextElement();
			QName varQName = new QName("http://java.sun.com/jstl/xpath/app", "applicationScope", varName);
			variableVector.addElement(varQName);
			globalVarSize++;
			variableVector.addElement(new QName(null, varName));
			globalVarSize++;
		}

		for (Enumeration enum_ = pageContext.getRequest().getParameterNames(); enum_.hasMoreElements();)
		{
			String varName = (String)enum_.nextElement();
			QName varQName = new QName("http://java.sun.com/jstl/xpath/param", "param", varName);
			variableVector.addElement(varQName);
			globalVarSize++;
		}

		for (Enumeration enum_ = pageContext.getServletContext().getInitParameterNames(); enum_.hasMoreElements();)
		{
			String varName = (String)enum_.nextElement();
			QName varQName = new QName("http://java.sun.com/jstl/xpath/initParam", "initParam", varName);
			variableVector.addElement(varQName);
			globalVarSize++;
		}

		for (Enumeration enum_ = ((HttpServletRequest)pageContext.getRequest()).getHeaderNames(); enum_.hasMoreElements();)
		{
			String varName = (String)enum_.nextElement();
			QName varQName = new QName("http://java.sun.com/jstl/xpath/header", "header", varName);
			variableVector.addElement(varQName);
			globalVarSize++;
		}

		Cookie c[] = ((HttpServletRequest)pageContext.getRequest()).getCookies();
		if (c != null)
		{
			for (int i = 0; i < c.length; i++)
			{
				String varName = c[i].getName();
				QName varQName = new QName("http://java.sun.com/jstl/xpath/cookie", "cookie", varName);
				variableVector.addElement(varQName);
				globalVarSize++;
			}

		}
		return variableVector;
	}

	private static synchronized void staticInit()
	{
		if (jstlPrefixResolver == null)
		{
			jstlPrefixResolver = new JSTLPrefixResolver();
			jstlPrefixResolver.addNamespace("pageScope", "http://java.sun.com/jstl/xpath/page");
			jstlPrefixResolver.addNamespace("requestScope", "http://java.sun.com/jstl/xpath/request");
			jstlPrefixResolver.addNamespace("sessionScope", "http://java.sun.com/jstl/xpath/session");
			jstlPrefixResolver.addNamespace("applicationScope", "http://java.sun.com/jstl/xpath/app");
			jstlPrefixResolver.addNamespace("param", "http://java.sun.com/jstl/xpath/param");
			jstlPrefixResolver.addNamespace("initParam", "http://java.sun.com/jstl/xpath/initParam");
			jstlPrefixResolver.addNamespace("header", "http://java.sun.com/jstl/xpath/header");
			jstlPrefixResolver.addNamespace("cookie", "http://java.sun.com/jstl/xpath/cookie");
			exprCache = new HashMap();
		}
	}

	static Document getDummyDocument()
	{
		if (dbf == null)
		{
			dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			dbf.setValidating(false);
		}
		db = dbf.newDocumentBuilder();
		DOMImplementation dim = db.getDOMImplementation();
		d = dim.createDocument("http://java.sun.com/jstl", "dummyroot", null);
		return d;
		Exception e;
		e;
		e.printStackTrace();
		return null;
	}

	static Document getDummyDocumentWithoutRoot()
	{
		if (dbf == null)
		{
			dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			dbf.setValidating(false);
		}
		db = dbf.newDocumentBuilder();
		d = db.newDocument();
		return d;
		Exception e;
		e;
		e.printStackTrace();
		return null;
	}

	private static Document getDocumentForNode(Node node)
	{
		Document doc = getDummyDocumentWithoutRoot();
		Node importedNode = doc.importNode(node, true);
		doc.appendChild(importedNode);
		return doc;
	}

	public String valueOf(Node n, String xpath)
		throws JspTagException
	{
		staticInit();
		JstlVariableContext vs = new JstlVariableContext();
		XPathContext xpathSupport = new XPathContext();
		xpathSupport.setVarStack(vs);
		Vector varVector = fillVarStack(vs, xpathSupport);
		Node contextNode = adaptParamsForXalan(vs, n, xpath.trim());
		xpath = modifiedXPath;
		XObject result = JSTLXPathAPI.eval(contextNode, xpath, jstlPrefixResolver, xpathSupport, varVector);
		String resultString = result.str();
		return resultString;
	}

	public boolean booleanValueOf(Node n, String xpath)
		throws JspTagException
	{
		XObject result;
		staticInit();
		JstlVariableContext vs = new JstlVariableContext();
		XPathContext xpathSupport = new XPathContext();
		xpathSupport.setVarStack(vs);
		Vector varVector = fillVarStack(vs, xpathSupport);
		Node contextNode = adaptParamsForXalan(vs, n, xpath.trim());
		xpath = modifiedXPath;
		result = JSTLXPathAPI.eval(contextNode, xpath, jstlPrefixResolver, xpathSupport, varVector);
		return result.bool();
		TransformerException ex;
		ex;
		throw new JspTagException(Resources.getMessage("XPATH_ERROR_XOBJECT", ex.toString()), ex);
	}

	public List selectNodes(Node n, String xpath)
		throws JspTagException
	{
		XObject result;
		staticInit();
		JstlVariableContext vs = new JstlVariableContext();
		XPathContext xpathSupport = new XPathContext();
		xpathSupport.setVarStack(vs);
		Vector varVector = fillVarStack(vs, xpathSupport);
		Node contextNode = adaptParamsForXalan(vs, n, xpath.trim());
		xpath = modifiedXPath;
		result = JSTLXPathAPI.eval(contextNode, xpath, jstlPrefixResolver, xpathSupport, varVector);
		NodeList nl = JSTLXPathAPI.getNodeList(result);
		return new JSTLNodeList(nl);
		JspTagException e;
		e;
		Vector vector;
		vector = new Vector();
		Object resultObject = null;
		if (result.getType() == 1)
			resultObject = new Boolean(result.bool());
		else
		if (result.getType() == 2)
			resultObject = new Double(result.num());
		else
		if (result.getType() == 3)
			resultObject = result.str();
		vector.add(resultObject);
		return new JSTLNodeList(vector);
		TransformerException te;
		te;
		throw new JspTagException(te.toString(), te);
	}

	public Node selectSingleNode(Node n, String xpath)
		throws JspTagException
	{
		staticInit();
		JstlVariableContext vs = new JstlVariableContext();
		XPathContext xpathSupport = new XPathContext();
		xpathSupport.setVarStack(vs);
		Vector varVector = fillVarStack(vs, xpathSupport);
		Node contextNode = adaptParamsForXalan(vs, n, xpath.trim());
		xpath = modifiedXPath;
		return JSTLXPathAPI.selectSingleNode(contextNode, xpath, jstlPrefixResolver, xpathSupport);
	}

	private VariableStack getLocalContext()
	{
		VariableStack vc = new JstlVariableContext();
		return vc;
	}

	protected Node adaptParamsForXalan(JstlVariableContext jvc, Node n, String xpath)
	{
		Node boundDocument = null;
		modifiedXPath = xpath;
		String origXPath = xpath;
		boolean whetherOrigXPath = true;
		if (n != null)
			return n;
		if (xpath.startsWith("$"))
		{
			String varQName = xpath.substring(xpath.indexOf("$") + 1);
			if (varQName.indexOf("/") > 0)
				varQName = varQName.substring(0, varQName.indexOf("/"));
			String varPrefix = null;
			String varLocalName = varQName;
			if (varQName.indexOf(":") >= 0)
			{
				varPrefix = varQName.substring(0, varQName.indexOf(":"));
				varLocalName = varQName.substring(varQName.indexOf(":") + 1);
			}
			if (xpath.indexOf("/") > 0)
			{
				xpath = xpath.substring(xpath.indexOf("/"));
			} else
			{
				xpath = "/*";
				whetherOrigXPath = false;
			}
			try
			{
				Object varObject = jvc.getVariableValue(null, varPrefix, varLocalName);
				if (Class.forName("org.w3c.dom.Document").isInstance(varObject))
					boundDocument = (Document)varObject;
				else
				if (Class.forName("org.apache.taglibs.standard.tag.common.xml.JSTLNodeList").isInstance(varObject))
				{
					Document newDocument = getDummyDocument();
					JSTLNodeList jstlNodeList = (JSTLNodeList)varObject;
					if (jstlNodeList.getLength() == 1)
					{
						if (Class.forName("org.w3c.dom.Node").isInstance(jstlNodeList.elementAt(0)))
						{
							Node node = (Node)jstlNodeList.elementAt(0);
							boundDocument = getDocumentForNode(node);
							if (whetherOrigXPath)
								xpath = "/*" + xpath;
						} else
						{
							Object myObject = jstlNodeList.elementAt(0);
							xpath = myObject.toString();
							boundDocument = newDocument;
						}
					} else
					{
						Element dummyroot = newDocument.getDocumentElement();
						for (int i = 0; i < jstlNodeList.getLength(); i++)
						{
							Node currNode = jstlNodeList.item(i);
							Node importedNode = newDocument.importNode(currNode, true);
							dummyroot.appendChild(importedNode);
						}

						boundDocument = newDocument;
						xpath = "/*" + xpath;
					}
				} else
				if (Class.forName("org.w3c.dom.Node").isInstance(varObject))
				{
					boundDocument = getDocumentForNode((Node)varObject);
					if (whetherOrigXPath)
						xpath = "/*" + xpath;
				} else
				{
					boundDocument = getDummyDocument();
					xpath = origXPath;
				}
			}
			catch (UnresolvableException ue)
			{
				System.out.println("Variable Unresolvable :" + ue.getMessage());
				ue.printStackTrace();
			}
			catch (ClassNotFoundException cnf) { }
		} else
		{
			boundDocument = getDummyDocument();
		}
		modifiedXPath = xpath;
		return boundDocument;
	}

	private Vector fillVarStack(JstlVariableContext vs, XPathContext xpathSupport)
		throws JspTagException
	{
		VariableStack myvs = xpathSupport.getVarStack();
		Vector varVector = getVariableQNames();
		for (int i = 0; i < varVector.size(); i++)
		{
			QName varQName = (QName)varVector.elementAt(i);
			try
			{
				XObject variableValue = vs.getVariableOrParam(xpathSupport, varQName);
				myvs.setGlobalVariable(i, variableValue);
			}
			catch (TransformerException te)
			{
				throw new JspTagException(te.toString(), te);
			}
		}

		return varVector;
	}

	public static Node getContext(Tag t)
		throws JspTagException
	{
		ForEachTag xt = (ForEachTag)TagSupport.findAncestorWithClass(t, org.apache.taglibs.standard.tag.common.xml.ForEachTag.class);
		if (xt == null)
			return null;
		else
			return xt.getContext();
	}

	private static void p(String s)
	{
		System.out.println("[XPathUtil] " + s);
	}

	public static void printDetails(Node n)
	{
		System.out.println("\n\nDetails of Node = > " + n);
		System.out.println("Name:Type:Node Value = > " + n.getNodeName() + ":" + n.getNodeType() + ":" + n.getNodeValue());
		System.out.println("Namespace URI : Prefix : localName = > " + n.getNamespaceURI() + ":" + n.getPrefix() + ":" + n.getLocalName());
		System.out.println("\n Node has children => " + n.hasChildNodes());
		if (n.hasChildNodes())
		{
			NodeList nl = n.getChildNodes();
			System.out.println("Number of Children => " + nl.getLength());
			for (int i = 0; i < nl.getLength(); i++)
			{
				Node childNode = nl.item(i);
				printDetails(childNode);
			}

		}
	}


}
