// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Version.java

package org.apache.taglibs.standard;

import java.io.PrintStream;

public class Version
{

	public Version()
	{
	}

	public static String getVersion()
	{
		return getProduct() + " " + getMajorVersionNum() + "." + getReleaseVersionNum() + "." + getMaintenanceVersionNum() + (getDevelopmentVersionNum() <= 0 ? "" : "_D" + getDevelopmentVersionNum());
	}

	public static void main(String argv[])
	{
		System.out.println(getVersion());
	}

	public static String getProduct()
	{
		return "standard-taglib";
	}

	public static int getMajorVersionNum()
	{
		return 1;
	}

	public static int getReleaseVersionNum()
	{
		return 1;
	}

	public static int getMaintenanceVersionNum()
	{
		return 2;
	}

	public static int getDevelopmentVersionNum()
	{
		return 0;
	}
}
