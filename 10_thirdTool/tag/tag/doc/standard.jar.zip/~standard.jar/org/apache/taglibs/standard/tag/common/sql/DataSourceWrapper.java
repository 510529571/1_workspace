// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DataSourceWrapper.java

package org.apache.taglibs.standard.tag.common.sql;

import java.io.PrintWriter;
import java.sql.*;
import javax.sql.DataSource;
import org.apache.taglibs.standard.resources.Resources;

public class DataSourceWrapper
	implements DataSource
{

	private String driverClassName;
	private String jdbcURL;
	private String userName;
	private String password;

	public DataSourceWrapper()
	{
	}

	public void setDriverClassName(String driverClassName)
		throws ClassNotFoundException, InstantiationException, IllegalAccessException
	{
		this.driverClassName = driverClassName;
		Class.forName(driverClassName, true, Thread.currentThread().getContextClassLoader()).newInstance();
	}

	public void setJdbcURL(String jdbcURL)
	{
		this.jdbcURL = jdbcURL;
	}

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public void setPassword(String password)
	{
		this.password = password;
	}

	public Connection getConnection()
		throws SQLException
	{
		Connection conn = null;
		if (userName != null)
			conn = DriverManager.getConnection(jdbcURL, userName, password);
		else
			conn = DriverManager.getConnection(jdbcURL);
		return conn;
	}

	public Connection getConnection(String username, String password)
		throws SQLException
	{
		throw new SQLException(Resources.getMessage("NOT_SUPPORTED"));
	}

	public int getLoginTimeout()
		throws SQLException
	{
		throw new SQLException(Resources.getMessage("NOT_SUPPORTED"));
	}

	public PrintWriter getLogWriter()
		throws SQLException
	{
		throw new SQLException(Resources.getMessage("NOT_SUPPORTED"));
	}

	public void setLoginTimeout(int seconds)
		throws SQLException
	{
		throw new SQLException(Resources.getMessage("NOT_SUPPORTED"));
	}

	public synchronized void setLogWriter(PrintWriter out)
		throws SQLException
	{
		throw new SQLException(Resources.getMessage("NOT_SUPPORTED"));
	}
}
