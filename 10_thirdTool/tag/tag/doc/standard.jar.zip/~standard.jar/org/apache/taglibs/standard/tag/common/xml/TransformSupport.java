// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TransformSupport.java

package org.apache.taglibs.standard.tag.common.xml;

import java.io.*;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.sax.SAXSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import org.apache.taglibs.standard.resources.Resources;
import org.apache.taglibs.standard.tag.common.core.ImportSupport;
import org.apache.taglibs.standard.tag.common.core.Util;
import org.w3c.dom.Node;
import org.xml.sax.*;
import org.xml.sax.helpers.XMLReaderFactory;

// Referenced classes of package org.apache.taglibs.standard.tag.common.xml:
//			ParseSupport

public abstract class TransformSupport extends BodyTagSupport
{
	private static class JstlUriResolver
		implements URIResolver
	{

		private final PageContext ctx;

		public Source resolve(String href, String base)
			throws TransformerException
		{
			if (href == null)
				return null;
			int index;
			if (base != null && (index = base.indexOf("jstl:")) != -1)
				base = base.substring(index + 5);
			if (ImportSupport.isAbsoluteUrl(href) || base != null && ImportSupport.isAbsoluteUrl(base))
				return null;
			if (base == null || base.lastIndexOf("/") == -1)
				base = "";
			else
				base = base.substring(0, base.lastIndexOf("/") + 1);
			String target = base + href;
			java.io.InputStream s;
			if (target.startsWith("/"))
			{
				s = ctx.getServletContext().getResourceAsStream(target);
				if (s == null)
					throw new TransformerException(Resources.getMessage("UNABLE_TO_RESOLVE_ENTITY", href));
			} else
			{
				String pagePath = ((HttpServletRequest)ctx.getRequest()).getServletPath();
				String basePath = pagePath.substring(0, pagePath.lastIndexOf("/"));
				s = ctx.getServletContext().getResourceAsStream(basePath + "/" + target);
				if (s == null)
					throw new TransformerException(Resources.getMessage("UNABLE_TO_RESOLVE_ENTITY", href));
			}
			return new StreamSource(s);
		}

		public JstlUriResolver(PageContext ctx)
		{
			this.ctx = ctx;
		}
	}

	private static class SafeWriter extends Writer
	{

		private Writer w;

		public void close()
		{
		}

		public void flush()
		{
		}

		public void write(char cbuf[], int off, int len)
			throws IOException
		{
			w.write(cbuf, off, len);
		}

		public SafeWriter(Writer w)
		{
			this.w = w;
		}
	}


	protected Object xml;
	protected String xmlSystemId;
	protected Object xslt;
	protected String xsltSystemId;
	protected Result result;
	private String var;
	private int scope;
	private Transformer t;
	private TransformerFactory tf;
	private DocumentBuilder db;
	private DocumentBuilderFactory dbf;

	public TransformSupport()
	{
		init();
	}

	private void init()
	{
		xml = xslt = null;
		xmlSystemId = xsltSystemId = null;
		var = null;
		result = null;
		tf = null;
		scope = 1;
	}

	public int doStartTag()
		throws JspException
	{
		if (dbf == null)
		{
			dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			dbf.setValidating(false);
		}
		if (db == null)
			db = dbf.newDocumentBuilder();
		if (tf == null)
			tf = TransformerFactory.newInstance();
		Source s;
		if (xslt != null)
		{
			if (!(xslt instanceof String) && !(xslt instanceof Reader) && !(xslt instanceof Source))
				throw new JspTagException(Resources.getMessage("TRANSFORM_XSLT_UNRECOGNIZED"));
			s = getSource(xslt, xsltSystemId);
		} else
		{
			throw new JspTagException(Resources.getMessage("TRANSFORM_NO_TRANSFORMER"));
		}
		tf.setURIResolver(new JstlUriResolver(pageContext));
		t = tf.newTransformer(s);
		return 2;
		SAXException ex;
		ex;
		throw new JspException(ex);
		ex;
		throw new JspException(ex);
		ex;
		throw new JspException(ex);
		ex;
		throw new JspException(ex);
	}

	public int doEndTag()
		throws JspException
	{
		Object xml = this.xml;
		if (xml == null)
			if (bodyContent != null && bodyContent.getString() != null)
				xml = bodyContent.getString().trim();
			else
				xml = "";
		Source source = getSource(xml, xmlSystemId);
		if (result != null)
			t.transform(source, result);
		else
		if (var != null)
		{
			org.w3c.dom.Document d = db.newDocument();
			Result doc = new DOMResult(d);
			t.transform(source, doc);
			pageContext.setAttribute(var, d, scope);
		} else
		{
			Result page = new StreamResult(new SafeWriter(pageContext.getOut()));
			t.transform(source, page);
		}
		return 6;
		SAXException ex;
		ex;
		throw new JspException(ex);
		ex;
		throw new JspException(ex);
		ex;
		throw new JspException(ex);
		ex;
		throw new JspException(ex);
	}

	public void release()
	{
		init();
	}

	public void addParameter(String name, Object value)
	{
		t.setParameter(name, value);
	}

	private static String wrapSystemId(String systemId)
	{
		if (systemId == null)
			return "jstl:";
		if (ImportSupport.isAbsoluteUrl(systemId))
			return systemId;
		else
			return "jstl:" + systemId;
	}

	private Source getSource(Object o, String systemId)
		throws SAXException, ParserConfigurationException, IOException
	{
		if (o == null)
			return null;
		if (o instanceof Source)
			return (Source)o;
		if (o instanceof String)
			return getSource(new StringReader((String)o), systemId);
		if (o instanceof Reader)
		{
			XMLReader xr = XMLReaderFactory.createXMLReader();
			xr.setEntityResolver(new ParseSupport.JstlEntityResolver(pageContext));
			InputSource s = new InputSource((Reader)o);
			s.setSystemId(wrapSystemId(systemId));
			Source result = new SAXSource(xr, s);
			result.setSystemId(wrapSystemId(systemId));
			return result;
		}
		if (o instanceof Node)
			return new DOMSource((Node)o);
		if (o instanceof List)
		{
			List l = (List)o;
			if (l.size() == 1)
				return getSource(l.get(0), systemId);
			else
				throw new IllegalArgumentException(Resources.getMessage("TRANSFORM_SOURCE_INVALID_LIST"));
		} else
		{
			throw new IllegalArgumentException(Resources.getMessage("TRANSFORM_SOURCE_UNRECOGNIZED") + o.getClass());
		}
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
	}
}
