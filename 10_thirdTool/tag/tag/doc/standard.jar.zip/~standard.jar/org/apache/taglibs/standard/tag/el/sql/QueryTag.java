// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   QueryTag.java

package org.apache.taglibs.standard.tag.el.sql;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.tag.common.sql.QueryTagSupport;

public class QueryTag extends QueryTagSupport
{

	private String dataSourceEL;
	private String sqlEL;
	private String startRowEL;
	private String maxRowsEL;

	public QueryTag()
	{
	}

	public void setDataSource(String dataSourceEL)
	{
		this.dataSourceEL = dataSourceEL;
		dataSourceSpecified = true;
	}

	public void setStartRow(String startRowEL)
	{
		this.startRowEL = startRowEL;
	}

	public void setMaxRows(String maxRowsEL)
	{
		this.maxRowsEL = maxRowsEL;
		maxRowsSpecified = true;
	}

	public void setSql(String sqlEL)
	{
		this.sqlEL = sqlEL;
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	private void evaluateExpressions()
		throws JspException
	{
		Integer tempInt = null;
		if (dataSourceEL != null)
			rawDataSource = ExpressionEvaluatorManager.evaluate("dataSource", dataSourceEL, java.lang.Object.class, this, pageContext);
		if (sqlEL != null)
			sql = (String)ExpressionEvaluatorManager.evaluate("sql", sqlEL, java.lang.String.class, this, pageContext);
		if (startRowEL != null)
		{
			tempInt = (Integer)ExpressionEvaluatorManager.evaluate("startRow", startRowEL, java.lang.Integer.class, this, pageContext);
			if (tempInt != null)
				startRow = tempInt.intValue();
		}
		if (maxRowsEL != null)
		{
			tempInt = (Integer)ExpressionEvaluatorManager.evaluate("maxRows", maxRowsEL, java.lang.Integer.class, this, pageContext);
			if (tempInt != null)
				maxRows = tempInt.intValue();
		}
	}
}
