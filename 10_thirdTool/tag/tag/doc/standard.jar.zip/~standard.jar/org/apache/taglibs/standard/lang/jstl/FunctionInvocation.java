// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FunctionInvocation.java

package org.apache.taglibs.standard.lang.jstl;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			Expression, ELException, Constants, Logger, 
//			Coercions, VariableResolver

public class FunctionInvocation extends Expression
{

	private String functionName;
	private List argumentList;

	public String getFunctionName()
	{
		return functionName;
	}

	public void setFunctionName(String f)
	{
		functionName = f;
	}

	public List getArgumentList()
	{
		return argumentList;
	}

	public void setArgumentList(List l)
	{
		argumentList = l;
	}

	public FunctionInvocation(String functionName, List argumentList)
	{
		this.functionName = functionName;
		this.argumentList = argumentList;
	}

	public String getExpressionString()
	{
		StringBuffer b = new StringBuffer();
		b.append(functionName);
		b.append("(");
		Iterator i = argumentList.iterator();
		do
		{
			if (!i.hasNext())
				break;
			b.append(((Expression)i.next()).getExpressionString());
			if (i.hasNext())
				b.append(", ");
		} while (true);
		b.append(")");
		return b.toString();
	}

	public Object evaluate(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger)
		throws ELException
	{
		String functionName;
		Method target;
		Object arguments[];
		if (functions == null)
			pLogger.logError(Constants.UNKNOWN_FUNCTION, this.functionName);
		functionName = this.functionName;
		if (functionName.indexOf(":") == -1)
		{
			if (defaultPrefix == null)
				pLogger.logError(Constants.UNKNOWN_FUNCTION, functionName);
			functionName = defaultPrefix + ":" + functionName;
		}
		target = (Method)functions.get(functionName);
		if (target == null)
			pLogger.logError(Constants.UNKNOWN_FUNCTION, functionName);
		Class params[] = target.getParameterTypes();
		if (params.length != argumentList.size())
			pLogger.logError(Constants.INAPPROPRIATE_FUNCTION_ARG_COUNT, new Integer(params.length), new Integer(argumentList.size()));
		arguments = new Object[argumentList.size()];
		for (int i = 0; i < params.length; i++)
		{
			arguments[i] = ((Expression)argumentList.get(i)).evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
			arguments[i] = Coercions.coerce(arguments[i], params[i], pLogger);
		}

		return target.invoke(null, arguments);
		InvocationTargetException ex;
		ex;
		pLogger.logError(Constants.FUNCTION_INVOCATION_ERROR, ex.getTargetException(), functionName);
		return null;
		ex;
		pLogger.logError(Constants.FUNCTION_INVOCATION_ERROR, ex, functionName);
		return null;
	}
}
