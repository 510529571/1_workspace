// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Coercions.java

package org.apache.taglibs.standard.lang.jstl;

import java.beans.PropertyEditor;
import java.beans.PropertyEditorManager;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			ELException, Logger, Constants, PrimitiveObjects, 
//			ArithmeticOperator, RelationalOperator, EqualityOperator

public class Coercions
{

	public Coercions()
	{
	}

	public static Object coerce(Object pValue, Class pClass, Logger pLogger)
		throws ELException
	{
		if (pClass == (java.lang.String.class))
			return coerceToString(pValue, pLogger);
		if (isPrimitiveNumberClass(pClass))
			return coerceToPrimitiveNumber(pValue, pClass, pLogger);
		if (pClass == (java.lang.Character.class) || pClass == Character.TYPE)
			return coerceToCharacter(pValue, pLogger);
		if (pClass == (java.lang.Boolean.class) || pClass == Boolean.TYPE)
			return coerceToBoolean(pValue, pLogger);
		else
			return coerceToObject(pValue, pClass, pLogger);
	}

	static boolean isPrimitiveNumberClass(Class pClass)
	{
		return pClass == (java.lang.Byte.class) || pClass == Byte.TYPE || pClass == (java.lang.Short.class) || pClass == Short.TYPE || pClass == (java.lang.Integer.class) || pClass == Integer.TYPE || pClass == (java.lang.Long.class) || pClass == Long.TYPE || pClass == (java.lang.Float.class) || pClass == Float.TYPE || pClass == (java.lang.Double.class) || pClass == Double.TYPE;
	}

	public static String coerceToString(Object pValue, Logger pLogger)
		throws ELException
	{
		if (pValue == null)
			return "";
		if (pValue instanceof String)
			return (String)pValue;
		return pValue.toString();
		Exception exc;
		exc;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.TOSTRING_EXCEPTION, exc, pValue.getClass().getName());
		return "";
	}

	public static Number coerceToPrimitiveNumber(Object pValue, Class pClass, Logger pLogger)
		throws ELException
	{
		if (pValue == null || "".equals(pValue))
			return coerceToPrimitiveNumber(0L, pClass);
		if (pValue instanceof Character)
		{
			char val = ((Character)pValue).charValue();
			return coerceToPrimitiveNumber((short)val, pClass);
		}
		if (pValue instanceof Boolean)
		{
			if (pLogger.isLoggingError())
				pLogger.logError(Constants.BOOLEAN_TO_NUMBER, pValue, pClass.getName());
			return coerceToPrimitiveNumber(0L, pClass);
		}
		if (pValue.getClass() == pClass)
			return (Number)pValue;
		if (pValue instanceof Number)
			return coerceToPrimitiveNumber((Number)pValue, pClass);
		if (!(pValue instanceof String))
			break MISSING_BLOCK_LABEL_148;
		return coerceToPrimitiveNumber((String)pValue, pClass);
		Exception exc;
		exc;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.STRING_TO_NUMBER_EXCEPTION, (String)pValue, pClass.getName());
		return coerceToPrimitiveNumber(0L, pClass);
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.COERCE_TO_NUMBER, pValue.getClass().getName(), pClass.getName());
		return coerceToPrimitiveNumber(0L, pClass);
	}

	public static Integer coerceToInteger(Object pValue, Logger pLogger)
		throws ELException
	{
		if (pValue == null)
			return null;
		if (pValue instanceof Character)
			return PrimitiveObjects.getInteger(((Character)pValue).charValue());
		if (pValue instanceof Boolean)
		{
			if (pLogger.isLoggingWarning())
				pLogger.logWarning(Constants.BOOLEAN_TO_NUMBER, pValue, (java.lang.Integer.class).getName());
			return PrimitiveObjects.getInteger(((Boolean)pValue).booleanValue() ? 1 : 0);
		}
		if (pValue instanceof Integer)
			return (Integer)pValue;
		if (pValue instanceof Number)
			return PrimitiveObjects.getInteger(((Number)pValue).intValue());
		if (!(pValue instanceof String))
			break MISSING_BLOCK_LABEL_179;
		return Integer.valueOf((String)pValue);
		Exception exc;
		exc;
		if (pLogger.isLoggingWarning())
			pLogger.logWarning(Constants.STRING_TO_NUMBER_EXCEPTION, (String)pValue, (java.lang.Integer.class).getName());
		return null;
		if (pLogger.isLoggingWarning())
			pLogger.logWarning(Constants.COERCE_TO_NUMBER, pValue.getClass().getName(), (java.lang.Integer.class).getName());
		return null;
	}

	static Number coerceToPrimitiveNumber(long pValue, Class pClass)
		throws ELException
	{
		if (pClass == (java.lang.Byte.class) || pClass == Byte.TYPE)
			return PrimitiveObjects.getByte((byte)(int)pValue);
		if (pClass == (java.lang.Short.class) || pClass == Short.TYPE)
			return PrimitiveObjects.getShort((short)(int)pValue);
		if (pClass == (java.lang.Integer.class) || pClass == Integer.TYPE)
			return PrimitiveObjects.getInteger((int)pValue);
		if (pClass == (java.lang.Long.class) || pClass == Long.TYPE)
			return PrimitiveObjects.getLong(pValue);
		if (pClass == (java.lang.Float.class) || pClass == Float.TYPE)
			return PrimitiveObjects.getFloat(pValue);
		if (pClass == (java.lang.Double.class) || pClass == Double.TYPE)
			return PrimitiveObjects.getDouble(pValue);
		else
			return PrimitiveObjects.getInteger(0);
	}

	static Number coerceToPrimitiveNumber(double pValue, Class pClass)
		throws ELException
	{
		if (pClass == (java.lang.Byte.class) || pClass == Byte.TYPE)
			return PrimitiveObjects.getByte((byte)(int)pValue);
		if (pClass == (java.lang.Short.class) || pClass == Short.TYPE)
			return PrimitiveObjects.getShort((short)(int)pValue);
		if (pClass == (java.lang.Integer.class) || pClass == Integer.TYPE)
			return PrimitiveObjects.getInteger((int)pValue);
		if (pClass == (java.lang.Long.class) || pClass == Long.TYPE)
			return PrimitiveObjects.getLong((long)pValue);
		if (pClass == (java.lang.Float.class) || pClass == Float.TYPE)
			return PrimitiveObjects.getFloat((float)pValue);
		if (pClass == (java.lang.Double.class) || pClass == Double.TYPE)
			return PrimitiveObjects.getDouble(pValue);
		else
			return PrimitiveObjects.getInteger(0);
	}

	static Number coerceToPrimitiveNumber(Number pValue, Class pClass)
		throws ELException
	{
		if (pClass == (java.lang.Byte.class) || pClass == Byte.TYPE)
			return PrimitiveObjects.getByte(pValue.byteValue());
		if (pClass == (java.lang.Short.class) || pClass == Short.TYPE)
			return PrimitiveObjects.getShort(pValue.shortValue());
		if (pClass == (java.lang.Integer.class) || pClass == Integer.TYPE)
			return PrimitiveObjects.getInteger(pValue.intValue());
		if (pClass == (java.lang.Long.class) || pClass == Long.TYPE)
			return PrimitiveObjects.getLong(pValue.longValue());
		if (pClass == (java.lang.Float.class) || pClass == Float.TYPE)
			return PrimitiveObjects.getFloat(pValue.floatValue());
		if (pClass == (java.lang.Double.class) || pClass == Double.TYPE)
			return PrimitiveObjects.getDouble(pValue.doubleValue());
		else
			return PrimitiveObjects.getInteger(0);
	}

	static Number coerceToPrimitiveNumber(String pValue, Class pClass)
		throws ELException
	{
		if (pClass == (java.lang.Byte.class) || pClass == Byte.TYPE)
			return Byte.valueOf(pValue);
		if (pClass == (java.lang.Short.class) || pClass == Short.TYPE)
			return Short.valueOf(pValue);
		if (pClass == (java.lang.Integer.class) || pClass == Integer.TYPE)
			return Integer.valueOf(pValue);
		if (pClass == (java.lang.Long.class) || pClass == Long.TYPE)
			return Long.valueOf(pValue);
		if (pClass == (java.lang.Float.class) || pClass == Float.TYPE)
			return Float.valueOf(pValue);
		if (pClass == (java.lang.Double.class) || pClass == Double.TYPE)
			return Double.valueOf(pValue);
		else
			return PrimitiveObjects.getInteger(0);
	}

	public static Character coerceToCharacter(Object pValue, Logger pLogger)
		throws ELException
	{
		if (pValue == null || "".equals(pValue))
			return PrimitiveObjects.getCharacter('\0');
		if (pValue instanceof Character)
			return (Character)pValue;
		if (pValue instanceof Boolean)
		{
			if (pLogger.isLoggingError())
				pLogger.logError(Constants.BOOLEAN_TO_CHARACTER, pValue);
			return PrimitiveObjects.getCharacter('\0');
		}
		if (pValue instanceof Number)
			return PrimitiveObjects.getCharacter((char)((Number)pValue).shortValue());
		if (pValue instanceof String)
		{
			String str = (String)pValue;
			return PrimitiveObjects.getCharacter(str.charAt(0));
		}
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.COERCE_TO_CHARACTER, pValue.getClass().getName());
		return PrimitiveObjects.getCharacter('\0');
	}

	public static Boolean coerceToBoolean(Object pValue, Logger pLogger)
		throws ELException
	{
		String str;
		if (pValue == null || "".equals(pValue))
			return Boolean.FALSE;
		if (pValue instanceof Boolean)
			return (Boolean)pValue;
		if (!(pValue instanceof String))
			break MISSING_BLOCK_LABEL_70;
		str = (String)pValue;
		return Boolean.valueOf(str);
		Exception exc;
		exc;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.STRING_TO_BOOLEAN, exc, (String)pValue);
		return Boolean.FALSE;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.COERCE_TO_BOOLEAN, pValue.getClass().getName());
		return Boolean.TRUE;
	}

	public static Object coerceToObject(Object pValue, Class pClass, Logger pLogger)
		throws ELException
	{
		String str;
		PropertyEditor pe;
		if (pValue == null)
			return null;
		if (pClass.isAssignableFrom(pValue.getClass()))
			return pValue;
		if (!(pValue instanceof String))
			break MISSING_BLOCK_LABEL_126;
		str = (String)pValue;
		pe = PropertyEditorManager.findEditor(pClass);
		if (pe == null)
		{
			if ("".equals(str))
				return null;
			if (pLogger.isLoggingError())
				pLogger.logError(Constants.NO_PROPERTY_EDITOR, str, pClass.getName());
			return null;
		}
		pe.setAsText(str);
		return pe.getValue();
		IllegalArgumentException exc;
		exc;
		if ("".equals(str))
			return null;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.PROPERTY_EDITOR_ERROR, exc, pValue, pClass.getName());
		return null;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.COERCE_TO_OBJECT, pValue.getClass().getName(), pClass.getName());
		return null;
	}

	public static Object applyArithmeticOperator(Object pLeft, Object pRight, ArithmeticOperator pOperator, Logger pLogger)
		throws ELException
	{
		if (pLeft == null && pRight == null)
		{
			if (pLogger.isLoggingWarning())
				pLogger.logWarning(Constants.ARITH_OP_NULL, pOperator.getOperatorSymbol());
			return PrimitiveObjects.getInteger(0);
		}
		if (isFloatingPointType(pLeft) || isFloatingPointType(pRight) || isFloatingPointString(pLeft) || isFloatingPointString(pRight))
		{
			double left = coerceToPrimitiveNumber(pLeft, java.lang.Double.class, pLogger).doubleValue();
			double right = coerceToPrimitiveNumber(pRight, java.lang.Double.class, pLogger).doubleValue();
			return PrimitiveObjects.getDouble(pOperator.apply(left, right, pLogger));
		} else
		{
			long left = coerceToPrimitiveNumber(pLeft, java.lang.Long.class, pLogger).longValue();
			long right = coerceToPrimitiveNumber(pRight, java.lang.Long.class, pLogger).longValue();
			return PrimitiveObjects.getLong(pOperator.apply(left, right, pLogger));
		}
	}

	public static Object applyRelationalOperator(Object pLeft, Object pRight, RelationalOperator pOperator, Logger pLogger)
		throws ELException
	{
		if (isFloatingPointType(pLeft) || isFloatingPointType(pRight))
		{
			double left = coerceToPrimitiveNumber(pLeft, java.lang.Double.class, pLogger).doubleValue();
			double right = coerceToPrimitiveNumber(pRight, java.lang.Double.class, pLogger).doubleValue();
			return PrimitiveObjects.getBoolean(pOperator.apply(left, right, pLogger));
		}
		if (isIntegerType(pLeft) || isIntegerType(pRight))
		{
			long left = coerceToPrimitiveNumber(pLeft, java.lang.Long.class, pLogger).longValue();
			long right = coerceToPrimitiveNumber(pRight, java.lang.Long.class, pLogger).longValue();
			return PrimitiveObjects.getBoolean(pOperator.apply(left, right, pLogger));
		}
		if ((pLeft instanceof String) || (pRight instanceof String))
		{
			String left = coerceToString(pLeft, pLogger);
			String right = coerceToString(pRight, pLogger);
			return PrimitiveObjects.getBoolean(pOperator.apply(left, right, pLogger));
		}
		if (!(pLeft instanceof Comparable))
			break MISSING_BLOCK_LABEL_303;
		int result = ((Comparable)pLeft).compareTo(pRight);
		return PrimitiveObjects.getBoolean(pOperator.apply(result, -result, pLogger));
		Exception exc;
		exc;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.COMPARABLE_ERROR, exc, pLeft.getClass().getName(), pRight != null ? ((Object) (pRight.getClass().getName())) : "null", pOperator.getOperatorSymbol());
		return Boolean.FALSE;
		if (!(pRight instanceof Comparable))
			break MISSING_BLOCK_LABEL_387;
		exc = ((Comparable)pRight).compareTo(pLeft);
		return PrimitiveObjects.getBoolean(pOperator.apply(-exc, exc, pLogger));
		exc;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.COMPARABLE_ERROR, exc, pRight.getClass().getName(), pLeft != null ? ((Object) (pLeft.getClass().getName())) : "null", pOperator.getOperatorSymbol());
		return Boolean.FALSE;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.ARITH_OP_BAD_TYPE, pOperator.getOperatorSymbol(), pLeft.getClass().getName(), pRight.getClass().getName());
		return Boolean.FALSE;
	}

	public static Object applyEqualityOperator(Object pLeft, Object pRight, EqualityOperator pOperator, Logger pLogger)
		throws ELException
	{
		if (pLeft == pRight)
			return PrimitiveObjects.getBoolean(pOperator.apply(true, pLogger));
		if (pLeft == null || pRight == null)
			return PrimitiveObjects.getBoolean(pOperator.apply(false, pLogger));
		if (isFloatingPointType(pLeft) || isFloatingPointType(pRight))
		{
			double left = coerceToPrimitiveNumber(pLeft, java.lang.Double.class, pLogger).doubleValue();
			double right = coerceToPrimitiveNumber(pRight, java.lang.Double.class, pLogger).doubleValue();
			return PrimitiveObjects.getBoolean(pOperator.apply(left == right, pLogger));
		}
		if (isIntegerType(pLeft) || isIntegerType(pRight))
		{
			long left = coerceToPrimitiveNumber(pLeft, java.lang.Long.class, pLogger).longValue();
			long right = coerceToPrimitiveNumber(pRight, java.lang.Long.class, pLogger).longValue();
			return PrimitiveObjects.getBoolean(pOperator.apply(left == right, pLogger));
		}
		if ((pLeft instanceof Boolean) || (pRight instanceof Boolean))
		{
			boolean left = coerceToBoolean(pLeft, pLogger).booleanValue();
			boolean right = coerceToBoolean(pRight, pLogger).booleanValue();
			return PrimitiveObjects.getBoolean(pOperator.apply(left == right, pLogger));
		}
		if ((pLeft instanceof String) || (pRight instanceof String))
		{
			String left = coerceToString(pLeft, pLogger);
			String right = coerceToString(pRight, pLogger);
			return PrimitiveObjects.getBoolean(pOperator.apply(left.equals(right), pLogger));
		}
		return PrimitiveObjects.getBoolean(pOperator.apply(pLeft.equals(pRight), pLogger));
		Exception exc;
		exc;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.ERROR_IN_EQUALS, exc, pLeft.getClass().getName(), pRight.getClass().getName(), pOperator.getOperatorSymbol());
		return Boolean.FALSE;
	}

	public static boolean isFloatingPointType(Object pObject)
	{
		return pObject != null && isFloatingPointType(pObject.getClass());
	}

	public static boolean isFloatingPointType(Class pClass)
	{
		return pClass == (java.lang.Float.class) || pClass == Float.TYPE || pClass == (java.lang.Double.class) || pClass == Double.TYPE;
	}

	public static boolean isFloatingPointString(Object pObject)
	{
		if (pObject instanceof String)
		{
			String str = (String)pObject;
			int len = str.length();
			for (int i = 0; i < len; i++)
			{
				char ch = str.charAt(i);
				if (ch == '.' || ch == 'e' || ch == 'E')
					return true;
			}

			return false;
		} else
		{
			return false;
		}
	}

	public static boolean isIntegerType(Object pObject)
	{
		return pObject != null && isIntegerType(pObject.getClass());
	}

	public static boolean isIntegerType(Class pClass)
	{
		return pClass == (java.lang.Byte.class) || pClass == Byte.TYPE || pClass == (java.lang.Short.class) || pClass == Short.TYPE || pClass == (java.lang.Character.class) || pClass == Character.TYPE || pClass == (java.lang.Integer.class) || pClass == Integer.TYPE || pClass == (java.lang.Long.class) || pClass == Long.TYPE;
	}
}
