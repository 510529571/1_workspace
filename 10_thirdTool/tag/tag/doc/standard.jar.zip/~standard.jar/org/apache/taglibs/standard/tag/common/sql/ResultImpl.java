// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ResultImpl.java

package org.apache.taglibs.standard.tag.common.sql;

import java.sql.*;
import java.util.*;
import javax.servlet.jsp.jstl.sql.Result;

public class ResultImpl
	implements Result
{

	private List rowMap;
	private List rowByIndex;
	private String columnNames[];
	private boolean isLimited;

	public ResultImpl(ResultSet rs, int startRow, int maxRows)
		throws SQLException
	{
		rowMap = new ArrayList();
		rowByIndex = new ArrayList();
		ResultSetMetaData rsmd = rs.getMetaData();
		int noOfColumns = rsmd.getColumnCount();
		columnNames = new String[noOfColumns];
		for (int i = 1; i <= noOfColumns; i++)
			columnNames[i - 1] = rsmd.getColumnName(i);

		for (int i = 0; i < startRow; i++)
			rs.next();

		int processedRows = 0;
		do
		{
			if (!rs.next())
				break;
			if (maxRows != -1 && processedRows == maxRows)
			{
				isLimited = true;
				break;
			}
			Object columns[] = new Object[noOfColumns];
			SortedMap columnMap = new TreeMap(String.CASE_INSENSITIVE_ORDER);
			for (int i = 1; i <= noOfColumns; i++)
			{
				Object value = rs.getObject(i);
				if (rs.wasNull())
					value = null;
				columns[i - 1] = value;
				columnMap.put(columnNames[i - 1], value);
			}

			rowMap.add(columnMap);
			rowByIndex.add(((Object) (columns)));
			processedRows++;
		} while (true);
	}

	public SortedMap[] getRows()
	{
		if (rowMap == null)
			return null;
		else
			return (SortedMap[])rowMap.toArray(new SortedMap[0]);
	}

	public Object[][] getRowsByIndex()
	{
		if (rowByIndex == null)
			return (Object[][])null;
		else
			return (Object[][])rowByIndex.toArray(((Object []) (new Object[0][0])));
	}

	public String[] getColumnNames()
	{
		return columnNames;
	}

	public int getRowCount()
	{
		if (rowMap == null)
			return -1;
		else
			return rowMap.size();
	}

	public boolean isLimitedByMaxRows()
	{
		return isLimited;
	}
}
