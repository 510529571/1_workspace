// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ELParser.java

package org.apache.taglibs.standard.lang.jstl.parser;

import java.io.InputStream;
import java.io.Reader;
import java.util.*;
import org.apache.taglibs.standard.lang.jstl.*;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl.parser:
//			ParseException, SimpleCharStream, ELParserTokenManager, Token, 
//			ELParserConstants

public class ELParser
	implements ELParserConstants
{
	static final class JJCalls
	{

		int gen;
		Token first;
		int arg;
		JJCalls next;

		JJCalls()
		{
		}
	}


	public ELParserTokenManager token_source;
	SimpleCharStream jj_input_stream;
	public Token token;
	public Token jj_nt;
	private int jj_ntk;
	private Token jj_scanpos;
	private Token jj_lastpos;
	private int jj_la;
	public boolean lookingAhead;
	private boolean jj_semLA;
	private int jj_gen;
	private final int jj_la1[];
	private final int jj_la1_0[] = {
		6, 6, 6, 0, 0, 0, 0, 0x18600000, 0x600000, 0x18000000, 
		0x18600000, 0x79e0000, 0x180000, 0x60000, 0x6000000, 0x1800000, 0x79e0000, 0, 0, 0, 
		0, 0, 0, 0, 0, 0, 0x10000, 0x20007580, 0, 0x80000000, 
		0x20007580, 0x10000, 30080, 12288
	};
	private final int jj_la1_1[] = {
		0, 0, 0, 49152, 49152, 12288, 12288, 0, 0, 0, 
		0, 0, 0, 0, 0, 0, 0, 24, 24, 992, 
		192, 768, 992, 0x10c10, 3072, 0x10c10, 2, 0, 0x20000, 0, 
		0x30c10, 2, 0, 0
	};
	private final JJCalls jj_2_rtns[];
	private boolean jj_rescan;
	private int jj_gc;
	private Vector jj_expentries;
	private int jj_expentry[];
	private int jj_kind;
	private int jj_lasttokens[];
	private int jj_endpos;

	public static void main(String args[])
		throws ParseException
	{
		ELParser parser = new ELParser(System.in);
		parser.ExpressionString();
	}

	public final Object ExpressionString()
		throws ParseException
	{
		Object ret = "";
		List elems = null;
		switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
		{
		case 1: // '\001'
			ret = AttrValueString();
			break;

		case 2: // '\002'
			ret = AttrValueExpression();
			break;

		default:
			jj_la1[0] = jj_gen;
			jj_consume_token(-1);
			throw new ParseException();
		}
label0:
		do
			switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
			{
			default:
				jj_la1[1] = jj_gen;
				break label0;

			case 1: // '\001'
			case 2: // '\002'
				Object elem;
				switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
				{
				case 1: // '\001'
					elem = AttrValueString();
					break;

				case 2: // '\002'
					elem = AttrValueExpression();
					break;

				default:
					jj_la1[2] = jj_gen;
					jj_consume_token(-1);
					throw new ParseException();
				}
				if (elems == null)
				{
					elems = new ArrayList();
					elems.add(ret);
				}
				elems.add(elem);
				break;
			}
		while (true);
		if (elems != null)
			ret = new ExpressionString(elems.toArray());
		return ret;
	}

	public final String AttrValueString()
		throws ParseException
	{
		Token t = jj_consume_token(1);
		return t.image;
	}

	public final Expression AttrValueExpression()
		throws ParseException
	{
		jj_consume_token(2);
		Expression exp = Expression();
		jj_consume_token(15);
		return exp;
	}

	public final Expression Expression()
		throws ParseException
	{
		Expression ret = OrExpression();
		return ret;
	}

	public final Expression OrExpression()
		throws ParseException
	{
		List operators = null;
		List expressions = null;
		Expression startExpression = AndExpression();
label0:
		do
			switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
			{
			default:
				jj_la1[3] = jj_gen;
				break label0;

			case 46: // '.'
			case 47: // '/'
				switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
				{
				case 46: // '.'
					jj_consume_token(46);
					break;

				case 47: // '/'
					jj_consume_token(47);
					break;

				default:
					jj_la1[4] = jj_gen;
					jj_consume_token(-1);
					throw new ParseException();
				}
				org.apache.taglibs.standard.lang.jstl.BinaryOperator operator = OrOperator.SINGLETON;
				Expression expression = AndExpression();
				if (operators == null)
				{
					operators = new ArrayList();
					expressions = new ArrayList();
				}
				operators.add(operator);
				expressions.add(expression);
				break;
			}
		while (true);
		if (operators != null)
			return new BinaryOperatorExpression(startExpression, operators, expressions);
		else
			return startExpression;
	}

	public final Expression AndExpression()
		throws ParseException
	{
		List operators = null;
		List expressions = null;
		Expression startExpression = EqualityExpression();
label0:
		do
			switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
			{
			default:
				jj_la1[5] = jj_gen;
				break label0;

			case 44: // ','
			case 45: // '-'
				switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
				{
				case 44: // ','
					jj_consume_token(44);
					break;

				case 45: // '-'
					jj_consume_token(45);
					break;

				default:
					jj_la1[6] = jj_gen;
					jj_consume_token(-1);
					throw new ParseException();
				}
				org.apache.taglibs.standard.lang.jstl.BinaryOperator operator = AndOperator.SINGLETON;
				Expression expression = EqualityExpression();
				if (operators == null)
				{
					operators = new ArrayList();
					expressions = new ArrayList();
				}
				operators.add(operator);
				expressions.add(expression);
				break;
			}
		while (true);
		if (operators != null)
			return new BinaryOperatorExpression(startExpression, operators, expressions);
		else
			return startExpression;
	}

	public final Expression EqualityExpression()
		throws ParseException
	{
		List operators = null;
		List expressions = null;
		Expression startExpression = RelationalExpression();
label0:
		do
			switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
			{
			case 23: // '\027'
			case 24: // '\030'
			case 25: // '\031'
			case 26: // '\032'
			default:
				jj_la1[7] = jj_gen;
				break label0;

			case 21: // '\025'
			case 22: // '\026'
			case 27: // '\033'
			case 28: // '\034'
				org.apache.taglibs.standard.lang.jstl.BinaryOperator operator;
				switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
				{
				case 21: // '\025'
				case 22: // '\026'
					switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
					{
					case 21: // '\025'
						jj_consume_token(21);
						break;

					case 22: // '\026'
						jj_consume_token(22);
						break;

					default:
						jj_la1[8] = jj_gen;
						jj_consume_token(-1);
						throw new ParseException();
					}
					operator = EqualsOperator.SINGLETON;
					break;

				case 27: // '\033'
				case 28: // '\034'
					switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
					{
					case 27: // '\033'
						jj_consume_token(27);
						break;

					case 28: // '\034'
						jj_consume_token(28);
						break;

					default:
						jj_la1[9] = jj_gen;
						jj_consume_token(-1);
						throw new ParseException();
					}
					operator = NotEqualsOperator.SINGLETON;
					break;

				case 23: // '\027'
				case 24: // '\030'
				case 25: // '\031'
				case 26: // '\032'
				default:
					jj_la1[10] = jj_gen;
					jj_consume_token(-1);
					throw new ParseException();
				}
				Expression expression = RelationalExpression();
				if (operators == null)
				{
					operators = new ArrayList();
					expressions = new ArrayList();
				}
				operators.add(operator);
				expressions.add(expression);
				break;
			}
		while (true);
		if (operators != null)
			return new BinaryOperatorExpression(startExpression, operators, expressions);
		else
			return startExpression;
	}

	public final Expression RelationalExpression()
		throws ParseException
	{
		List operators = null;
		List expressions = null;
		Expression startExpression = AddExpression();
label0:
		do
			switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
			{
			case 21: // '\025'
			case 22: // '\026'
			default:
				jj_la1[11] = jj_gen;
				break label0;

			case 17: // '\021'
			case 18: // '\022'
			case 19: // '\023'
			case 20: // '\024'
			case 23: // '\027'
			case 24: // '\030'
			case 25: // '\031'
			case 26: // '\032'
				org.apache.taglibs.standard.lang.jstl.BinaryOperator operator;
				switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
				{
				case 19: // '\023'
				case 20: // '\024'
					switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
					{
					case 19: // '\023'
						jj_consume_token(19);
						break;

					case 20: // '\024'
						jj_consume_token(20);
						break;

					default:
						jj_la1[12] = jj_gen;
						jj_consume_token(-1);
						throw new ParseException();
					}
					operator = LessThanOperator.SINGLETON;
					break;

				case 17: // '\021'
				case 18: // '\022'
					switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
					{
					case 17: // '\021'
						jj_consume_token(17);
						break;

					case 18: // '\022'
						jj_consume_token(18);
						break;

					default:
						jj_la1[13] = jj_gen;
						jj_consume_token(-1);
						throw new ParseException();
					}
					operator = GreaterThanOperator.SINGLETON;
					break;

				case 25: // '\031'
				case 26: // '\032'
					switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
					{
					case 25: // '\031'
						jj_consume_token(25);
						break;

					case 26: // '\032'
						jj_consume_token(26);
						break;

					default:
						jj_la1[14] = jj_gen;
						jj_consume_token(-1);
						throw new ParseException();
					}
					operator = GreaterThanOrEqualsOperator.SINGLETON;
					break;

				case 23: // '\027'
				case 24: // '\030'
					switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
					{
					case 23: // '\027'
						jj_consume_token(23);
						break;

					case 24: // '\030'
						jj_consume_token(24);
						break;

					default:
						jj_la1[15] = jj_gen;
						jj_consume_token(-1);
						throw new ParseException();
					}
					operator = LessThanOrEqualsOperator.SINGLETON;
					break;

				case 21: // '\025'
				case 22: // '\026'
				default:
					jj_la1[16] = jj_gen;
					jj_consume_token(-1);
					throw new ParseException();
				}
				Expression expression = AddExpression();
				if (operators == null)
				{
					operators = new ArrayList();
					expressions = new ArrayList();
				}
				operators.add(operator);
				expressions.add(expression);
				break;
			}
		while (true);
		if (operators != null)
			return new BinaryOperatorExpression(startExpression, operators, expressions);
		else
			return startExpression;
	}

	public final Expression AddExpression()
		throws ParseException
	{
		List operators = null;
		List expressions = null;
		Expression startExpression = MultiplyExpression();
label0:
		do
			switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
			{
			default:
				jj_la1[17] = jj_gen;
				break label0;

			case 35: // '#'
			case 36: // '$'
				org.apache.taglibs.standard.lang.jstl.BinaryOperator operator;
				switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
				{
				case 35: // '#'
					jj_consume_token(35);
					operator = PlusOperator.SINGLETON;
					break;

				case 36: // '$'
					jj_consume_token(36);
					operator = MinusOperator.SINGLETON;
					break;

				default:
					jj_la1[18] = jj_gen;
					jj_consume_token(-1);
					throw new ParseException();
				}
				Expression expression = MultiplyExpression();
				if (operators == null)
				{
					operators = new ArrayList();
					expressions = new ArrayList();
				}
				operators.add(operator);
				expressions.add(expression);
				break;
			}
		while (true);
		if (operators != null)
			return new BinaryOperatorExpression(startExpression, operators, expressions);
		else
			return startExpression;
	}

	public final Expression MultiplyExpression()
		throws ParseException
	{
		List operators = null;
		List expressions = null;
		Expression startExpression = UnaryExpression();
label0:
		do
			switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
			{
			default:
				jj_la1[19] = jj_gen;
				break label0;

			case 37: // '%'
			case 38: // '&'
			case 39: // '\''
			case 40: // '('
			case 41: // ')'
				org.apache.taglibs.standard.lang.jstl.BinaryOperator operator;
				switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
				{
				case 37: // '%'
					jj_consume_token(37);
					operator = MultiplyOperator.SINGLETON;
					break;

				case 38: // '&'
				case 39: // '\''
					switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
					{
					case 38: // '&'
						jj_consume_token(38);
						break;

					case 39: // '\''
						jj_consume_token(39);
						break;

					default:
						jj_la1[20] = jj_gen;
						jj_consume_token(-1);
						throw new ParseException();
					}
					operator = DivideOperator.SINGLETON;
					break;

				case 40: // '('
				case 41: // ')'
					switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
					{
					case 40: // '('
						jj_consume_token(40);
						break;

					case 41: // ')'
						jj_consume_token(41);
						break;

					default:
						jj_la1[21] = jj_gen;
						jj_consume_token(-1);
						throw new ParseException();
					}
					operator = ModulusOperator.SINGLETON;
					break;

				default:
					jj_la1[22] = jj_gen;
					jj_consume_token(-1);
					throw new ParseException();
				}
				Expression expression = UnaryExpression();
				if (operators == null)
				{
					operators = new ArrayList();
					expressions = new ArrayList();
				}
				operators.add(operator);
				expressions.add(expression);
				break;
			}
		while (true);
		if (operators != null)
			return new BinaryOperatorExpression(startExpression, operators, expressions);
		else
			return startExpression;
	}

	public final Expression UnaryExpression()
		throws ParseException
	{
		org.apache.taglibs.standard.lang.jstl.UnaryOperator singleOperator = null;
		List operators = null;
label0:
		do
			switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
			{
			default:
				jj_la1[23] = jj_gen;
				break label0;

			case 36: // '$'
			case 42: // '*'
			case 43: // '+'
			case 48: // '0'
				org.apache.taglibs.standard.lang.jstl.UnaryOperator operator;
				switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
				{
				case 42: // '*'
				case 43: // '+'
					switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
					{
					case 42: // '*'
						jj_consume_token(42);
						break;

					case 43: // '+'
						jj_consume_token(43);
						break;

					default:
						jj_la1[24] = jj_gen;
						jj_consume_token(-1);
						throw new ParseException();
					}
					operator = NotOperator.SINGLETON;
					break;

				case 36: // '$'
					jj_consume_token(36);
					operator = UnaryMinusOperator.SINGLETON;
					break;

				case 48: // '0'
					jj_consume_token(48);
					operator = EmptyOperator.SINGLETON;
					break;

				default:
					jj_la1[25] = jj_gen;
					jj_consume_token(-1);
					throw new ParseException();
				}
				if (singleOperator == null)
					singleOperator = operator;
				else
				if (operators == null)
				{
					operators = new ArrayList();
					operators.add(singleOperator);
					operators.add(operator);
				} else
				{
					operators.add(operator);
				}
				break;
			}
		while (true);
		Expression expression = Value();
		if (operators != null)
			return new UnaryOperatorExpression(null, operators, expression);
		if (singleOperator != null)
			return new UnaryOperatorExpression(singleOperator, null, expression);
		else
			return expression;
	}

	public final Expression Value()
		throws ParseException
	{
		List suffixes = null;
		Expression prefix = ValuePrefix();
label0:
		do
			switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
			{
			default:
				jj_la1[26] = jj_gen;
				break label0;

			case 16: // '\020'
			case 33: // '!'
				ValueSuffix suffix = ValueSuffix();
				if (suffixes == null)
					suffixes = new ArrayList();
				suffixes.add(suffix);
				break;
			}
		while (true);
		if (suffixes == null)
			return prefix;
		else
			return new ComplexValue(prefix, suffixes);
	}

	public final Expression ValuePrefix()
		throws ParseException
	{
		Expression ret;
		switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
		{
		case 7: // '\007'
		case 8: // '\b'
		case 10: // '\n'
		case 12: // '\f'
		case 13: // '\r'
		case 14: // '\016'
			ret = Literal();
			break;

		case 29: // '\035'
			jj_consume_token(29);
			ret = Expression();
			jj_consume_token(30);
			break;

		case 9: // '\t'
		case 11: // '\013'
		case 15: // '\017'
		case 16: // '\020'
		case 17: // '\021'
		case 18: // '\022'
		case 19: // '\023'
		case 20: // '\024'
		case 21: // '\025'
		case 22: // '\026'
		case 23: // '\027'
		case 24: // '\030'
		case 25: // '\031'
		case 26: // '\032'
		case 27: // '\033'
		case 28: // '\034'
		default:
			jj_la1[27] = jj_gen;
			if (jj_2_1(0x7fffffff))
			{
				ret = FunctionInvocation();
				break;
			}
			switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
			{
			case 49: // '1'
				ret = NamedValue();
				break;

			default:
				jj_la1[28] = jj_gen;
				jj_consume_token(-1);
				throw new ParseException();
			}
			break;
		}
		return ret;
	}

	public final NamedValue NamedValue()
		throws ParseException
	{
		Token t = jj_consume_token(49);
		return new NamedValue(t.image);
	}

	public final FunctionInvocation FunctionInvocation()
		throws ParseException
	{
		List argumentList = new ArrayList();
		String qualifiedName = QualifiedName();
		jj_consume_token(29);
label0:
		switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
		{
		case 7: // '\007'
		case 8: // '\b'
		case 10: // '\n'
		case 12: // '\f'
		case 13: // '\r'
		case 14: // '\016'
		case 29: // '\035'
		case 36: // '$'
		case 42: // '*'
		case 43: // '+'
		case 48: // '0'
		case 49: // '1'
			Expression exp = Expression();
			argumentList.add(exp);
			do
				switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
				{
				default:
					jj_la1[29] = jj_gen;
					break label0;

				case 31: // '\037'
					jj_consume_token(31);
					exp = Expression();
					argumentList.add(exp);
					break;
				}
			while (true);

		case 9: // '\t'
		case 11: // '\013'
		case 15: // '\017'
		case 16: // '\020'
		case 17: // '\021'
		case 18: // '\022'
		case 19: // '\023'
		case 20: // '\024'
		case 21: // '\025'
		case 22: // '\026'
		case 23: // '\027'
		case 24: // '\030'
		case 25: // '\031'
		case 26: // '\032'
		case 27: // '\033'
		case 28: // '\034'
		case 30: // '\036'
		case 31: // '\037'
		case 32: // ' '
		case 33: // '!'
		case 34: // '"'
		case 35: // '#'
		case 37: // '%'
		case 38: // '&'
		case 39: // '\''
		case 40: // '('
		case 41: // ')'
		case 44: // ','
		case 45: // '-'
		case 46: // '.'
		case 47: // '/'
		default:
			jj_la1[30] = jj_gen;
			break;
		}
		jj_consume_token(30);
		String allowed = System.getProperty("javax.servlet.jsp.functions.allowed");
		if (allowed == null || !allowed.equalsIgnoreCase("true"))
			throw new ParseException("EL functions are not supported.");
		else
			return new FunctionInvocation(qualifiedName, argumentList);
	}

	public final ValueSuffix ValueSuffix()
		throws ParseException
	{
		ValueSuffix suffix;
		switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
		{
		case 16: // '\020'
			suffix = PropertySuffix();
			break;

		case 33: // '!'
			suffix = ArraySuffix();
			break;

		default:
			jj_la1[31] = jj_gen;
			jj_consume_token(-1);
			throw new ParseException();
		}
		return suffix;
	}

	public final PropertySuffix PropertySuffix()
		throws ParseException
	{
		jj_consume_token(16);
		String property = Identifier();
		return new PropertySuffix(property);
	}

	public final ArraySuffix ArraySuffix()
		throws ParseException
	{
		jj_consume_token(33);
		Expression index = Expression();
		jj_consume_token(34);
		return new ArraySuffix(index);
	}

	public final Literal Literal()
		throws ParseException
	{
		Literal ret;
		switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
		{
		case 12: // '\f'
		case 13: // '\r'
			ret = BooleanLiteral();
			break;

		case 7: // '\007'
			ret = IntegerLiteral();
			break;

		case 8: // '\b'
			ret = FloatingPointLiteral();
			break;

		case 10: // '\n'
			ret = StringLiteral();
			break;

		case 14: // '\016'
			ret = NullLiteral();
			break;

		case 9: // '\t'
		case 11: // '\013'
		default:
			jj_la1[32] = jj_gen;
			jj_consume_token(-1);
			throw new ParseException();
		}
		return ret;
	}

	public final BooleanLiteral BooleanLiteral()
		throws ParseException
	{
		switch (jj_ntk != -1 ? jj_ntk : jj_ntk())
		{
		case 12: // '\f'
			jj_consume_token(12);
			return BooleanLiteral.TRUE;

		case 13: // '\r'
			jj_consume_token(13);
			return BooleanLiteral.FALSE;
		}
		jj_la1[33] = jj_gen;
		jj_consume_token(-1);
		throw new ParseException();
	}

	public final StringLiteral StringLiteral()
		throws ParseException
	{
		Token t = jj_consume_token(10);
		return org.apache.taglibs.standard.lang.jstl.StringLiteral.fromToken(t.image);
	}

	public final IntegerLiteral IntegerLiteral()
		throws ParseException
	{
		Token t = jj_consume_token(7);
		return new IntegerLiteral(t.image);
	}

	public final FloatingPointLiteral FloatingPointLiteral()
		throws ParseException
	{
		Token t = jj_consume_token(8);
		return new FloatingPointLiteral(t.image);
	}

	public final NullLiteral NullLiteral()
		throws ParseException
	{
		jj_consume_token(14);
		return NullLiteral.SINGLETON;
	}

	public final String Identifier()
		throws ParseException
	{
		Token t = jj_consume_token(49);
		return t.image;
	}

	public final String QualifiedName()
		throws ParseException
	{
		String prefix = null;
		String localPart = null;
		if (jj_2_2(0x7fffffff))
		{
			prefix = Identifier();
			jj_consume_token(32);
		}
		localPart = Identifier();
		if (prefix == null)
			return localPart;
		else
			return prefix + ":" + localPart;
	}

	private final boolean jj_2_1(int xla)
	{
		jj_la = xla;
		jj_lastpos = jj_scanpos = token;
		boolean retval = !jj_3_1();
		jj_save(0, xla);
		return retval;
	}

	private final boolean jj_2_2(int xla)
	{
		jj_la = xla;
		jj_lastpos = jj_scanpos = token;
		boolean retval = !jj_3_2();
		jj_save(1, xla);
		return retval;
	}

	private final boolean jj_3R_13()
	{
		if (jj_3R_12())
			return true;
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		if (jj_scan_token(32))
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3_2()
	{
		if (jj_3R_12())
			return true;
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		if (jj_scan_token(32))
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3_1()
	{
		if (jj_3R_11())
			return true;
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		if (jj_scan_token(29))
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3R_12()
	{
		if (jj_scan_token(49))
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	private final boolean jj_3R_11()
	{
		Token xsp = jj_scanpos;
		if (jj_3R_13())
			jj_scanpos = xsp;
		else
		if (jj_la == 0 && jj_scanpos == jj_lastpos)
			return false;
		if (jj_3R_12())
			return true;
		return jj_la != 0 || jj_scanpos != jj_lastpos ? false : false;
	}

	public ELParser(InputStream stream)
	{
		lookingAhead = false;
		jj_la1 = new int[34];
		jj_2_rtns = new JJCalls[2];
		jj_rescan = false;
		jj_gc = 0;
		jj_expentries = new Vector();
		jj_kind = -1;
		jj_lasttokens = new int[100];
		jj_input_stream = new SimpleCharStream(stream, 1, 1);
		token_source = new ELParserTokenManager(jj_input_stream);
		token = new Token();
		jj_ntk = -1;
		jj_gen = 0;
		for (int i = 0; i < 34; i++)
			jj_la1[i] = -1;

		for (int i = 0; i < jj_2_rtns.length; i++)
			jj_2_rtns[i] = new JJCalls();

	}

	public void ReInit(InputStream stream)
	{
		jj_input_stream.ReInit(stream, 1, 1);
		token_source.ReInit(jj_input_stream);
		token = new Token();
		jj_ntk = -1;
		jj_gen = 0;
		for (int i = 0; i < 34; i++)
			jj_la1[i] = -1;

		for (int i = 0; i < jj_2_rtns.length; i++)
			jj_2_rtns[i] = new JJCalls();

	}

	public ELParser(Reader stream)
	{
		lookingAhead = false;
		jj_la1 = new int[34];
		jj_2_rtns = new JJCalls[2];
		jj_rescan = false;
		jj_gc = 0;
		jj_expentries = new Vector();
		jj_kind = -1;
		jj_lasttokens = new int[100];
		jj_input_stream = new SimpleCharStream(stream, 1, 1);
		token_source = new ELParserTokenManager(jj_input_stream);
		token = new Token();
		jj_ntk = -1;
		jj_gen = 0;
		for (int i = 0; i < 34; i++)
			jj_la1[i] = -1;

		for (int i = 0; i < jj_2_rtns.length; i++)
			jj_2_rtns[i] = new JJCalls();

	}

	public void ReInit(Reader stream)
	{
		jj_input_stream.ReInit(stream, 1, 1);
		token_source.ReInit(jj_input_stream);
		token = new Token();
		jj_ntk = -1;
		jj_gen = 0;
		for (int i = 0; i < 34; i++)
			jj_la1[i] = -1;

		for (int i = 0; i < jj_2_rtns.length; i++)
			jj_2_rtns[i] = new JJCalls();

	}

	public ELParser(ELParserTokenManager tm)
	{
		lookingAhead = false;
		jj_la1 = new int[34];
		jj_2_rtns = new JJCalls[2];
		jj_rescan = false;
		jj_gc = 0;
		jj_expentries = new Vector();
		jj_kind = -1;
		jj_lasttokens = new int[100];
		token_source = tm;
		token = new Token();
		jj_ntk = -1;
		jj_gen = 0;
		for (int i = 0; i < 34; i++)
			jj_la1[i] = -1;

		for (int i = 0; i < jj_2_rtns.length; i++)
			jj_2_rtns[i] = new JJCalls();

	}

	public void ReInit(ELParserTokenManager tm)
	{
		token_source = tm;
		token = new Token();
		jj_ntk = -1;
		jj_gen = 0;
		for (int i = 0; i < 34; i++)
			jj_la1[i] = -1;

		for (int i = 0; i < jj_2_rtns.length; i++)
			jj_2_rtns[i] = new JJCalls();

	}

	private final Token jj_consume_token(int kind)
		throws ParseException
	{
		Token oldToken;
		if ((oldToken = token).next != null)
			token = token.next;
		else
			token = token.next = token_source.getNextToken();
		jj_ntk = -1;
		if (token.kind == kind)
		{
			jj_gen++;
			if (++jj_gc > 100)
			{
				jj_gc = 0;
				for (int i = 0; i < jj_2_rtns.length; i++)
				{
					for (JJCalls c = jj_2_rtns[i]; c != null; c = c.next)
						if (c.gen < jj_gen)
							c.first = null;

				}

			}
			return token;
		} else
		{
			token = oldToken;
			jj_kind = kind;
			throw generateParseException();
		}
	}

	private final boolean jj_scan_token(int kind)
	{
		if (jj_scanpos == jj_lastpos)
		{
			jj_la--;
			if (jj_scanpos.next == null)
				jj_lastpos = jj_scanpos = jj_scanpos.next = token_source.getNextToken();
			else
				jj_lastpos = jj_scanpos = jj_scanpos.next;
		} else
		{
			jj_scanpos = jj_scanpos.next;
		}
		if (jj_rescan)
		{
			int i = 0;
			Token tok;
			for (tok = token; tok != null && tok != jj_scanpos; tok = tok.next)
				i++;

			if (tok != null)
				jj_add_error_token(kind, i);
		}
		return jj_scanpos.kind != kind;
	}

	public final Token getNextToken()
	{
		if (token.next != null)
			token = token.next;
		else
			token = token.next = token_source.getNextToken();
		jj_ntk = -1;
		jj_gen++;
		return token;
	}

	public final Token getToken(int index)
	{
		Token t = lookingAhead ? jj_scanpos : token;
		for (int i = 0; i < index; i++)
			if (t.next != null)
				t = t.next;
			else
				t = t.next = token_source.getNextToken();

		return t;
	}

	private final int jj_ntk()
	{
		if ((jj_nt = token.next) == null)
			return jj_ntk = (token.next = token_source.getNextToken()).kind;
		else
			return jj_ntk = jj_nt.kind;
	}

	private void jj_add_error_token(int kind, int pos)
	{
		if (pos >= 100)
			return;
		if (pos == jj_endpos + 1)
			jj_lasttokens[jj_endpos++] = kind;
		else
		if (jj_endpos != 0)
		{
			jj_expentry = new int[jj_endpos];
			for (int i = 0; i < jj_endpos; i++)
				jj_expentry[i] = jj_lasttokens[i];

			boolean exists = false;
			Enumeration enum_ = jj_expentries.elements();
label0:
			do
			{
				int oldentry[];
				do
				{
					if (!enum_.hasMoreElements())
						break label0;
					oldentry = (int[])enum_.nextElement();
				} while (oldentry.length != jj_expentry.length);
				exists = true;
				int i = 0;
				do
				{
					if (i >= jj_expentry.length)
						break;
					if (oldentry[i] != jj_expentry[i])
					{
						exists = false;
						break;
					}
					i++;
				} while (true);
			} while (!exists);
			if (!exists)
				jj_expentries.addElement(jj_expentry);
			if (pos != 0)
				jj_lasttokens[(jj_endpos = pos) - 1] = kind;
		}
	}

	public final ParseException generateParseException()
	{
		jj_expentries.removeAllElements();
		boolean la1tokens[] = new boolean[54];
		for (int i = 0; i < 54; i++)
			la1tokens[i] = false;

		if (jj_kind >= 0)
		{
			la1tokens[jj_kind] = true;
			jj_kind = -1;
		}
		for (int i = 0; i < 34; i++)
		{
			if (jj_la1[i] != jj_gen)
				continue;
			for (int j = 0; j < 32; j++)
			{
				if ((jj_la1_0[i] & 1 << j) != 0)
					la1tokens[j] = true;
				if ((jj_la1_1[i] & 1 << j) != 0)
					la1tokens[32 + j] = true;
			}

		}

		for (int i = 0; i < 54; i++)
			if (la1tokens[i])
			{
				jj_expentry = new int[1];
				jj_expentry[0] = i;
				jj_expentries.addElement(jj_expentry);
			}

		jj_endpos = 0;
		jj_rescan_token();
		jj_add_error_token(0, 0);
		int exptokseq[][] = new int[jj_expentries.size()][];
		for (int i = 0; i < jj_expentries.size(); i++)
			exptokseq[i] = (int[])jj_expentries.elementAt(i);

		return new ParseException(token, exptokseq, ELParserConstants.tokenImage);
	}

	public final void enable_tracing()
	{
	}

	public final void disable_tracing()
	{
	}

	private final void jj_rescan_token()
	{
		jj_rescan = true;
		for (int i = 0; i < 2; i++)
		{
			JJCalls p = jj_2_rtns[i];
			do
			{
				if (p.gen > jj_gen)
				{
					jj_la = p.arg;
					jj_lastpos = jj_scanpos = p.first;
					switch (i)
					{
					case 0: // '\0'
						jj_3_1();
						break;

					case 1: // '\001'
						jj_3_2();
						break;
					}
				}
				p = p.next;
			} while (p != null);
		}

		jj_rescan = false;
	}

	private final void jj_save(int index, int xla)
	{
		JJCalls p = jj_2_rtns[index];
		do
		{
			if (p.gen <= jj_gen)
				break;
			if (p.next == null)
			{
				p = p.next = new JJCalls();
				break;
			}
			p = p.next;
		} while (true);
		p.gen = (jj_gen + xla) - jj_la;
		p.first = token;
		p.arg = xla;
	}
}
