// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   XmlParseTEI.java

package org.apache.taglibs.standard.tei;

import javax.servlet.jsp.tagext.TagData;
import javax.servlet.jsp.tagext.TagExtraInfo;

// Referenced classes of package org.apache.taglibs.standard.tei:
//			Util

public class XmlParseTEI extends TagExtraInfo
{

	private static final String VAR = "var";
	private static final String VAR_DOM = "varDom";
	private static final String SCOPE = "scope";
	private static final String SCOPE_DOM = "scopeDom";

	public XmlParseTEI()
	{
	}

	public boolean isValid(TagData us)
	{
		if (Util.isSpecified(us, "var") && Util.isSpecified(us, "varDom"))
			return false;
		if (!Util.isSpecified(us, "var") && !Util.isSpecified(us, "varDom"))
			return false;
		if (Util.isSpecified(us, "scope") && !Util.isSpecified(us, "var"))
			return false;
		return !Util.isSpecified(us, "scopeDom") || Util.isSpecified(us, "varDom");
	}
}
