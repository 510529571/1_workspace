// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParamTagSupport.java

package org.apache.taglibs.standard.tag.common.sql;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.jstl.sql.SQLExecutionTag;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import org.apache.taglibs.standard.resources.Resources;

public abstract class ParamTagSupport extends BodyTagSupport
{

	protected Object value;

	public ParamTagSupport()
	{
	}

	public int doEndTag()
		throws JspException
	{
		SQLExecutionTag parent = (SQLExecutionTag)findAncestorWithClass(this, javax.servlet.jsp.jstl.sql.SQLExecutionTag.class);
		if (parent == null)
			throw new JspTagException(Resources.getMessage("SQL_PARAM_OUTSIDE_PARENT"));
		Object paramValue = null;
		if (value != null)
			paramValue = value;
		else
		if (bodyContent != null)
		{
			paramValue = bodyContent.getString().trim();
			if (((String)paramValue).trim().length() == 0)
				paramValue = null;
		}
		parent.addSQLParameter(paramValue);
		return 6;
	}
}
