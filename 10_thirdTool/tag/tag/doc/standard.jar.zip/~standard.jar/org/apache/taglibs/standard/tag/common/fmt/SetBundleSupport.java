// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SetBundleSupport.java

package org.apache.taglibs.standard.tag.common.fmt;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.jstl.core.Config;
import javax.servlet.jsp.tagext.TagSupport;
import org.apache.taglibs.standard.tag.common.core.Util;

// Referenced classes of package org.apache.taglibs.standard.tag.common.fmt:
//			BundleSupport

public abstract class SetBundleSupport extends TagSupport
{

	protected String basename;
	private int scope;
	private String var;

	public SetBundleSupport()
	{
		init();
	}

	private void init()
	{
		basename = null;
		scope = 1;
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
	}

	public int doEndTag()
		throws JspException
	{
		javax.servlet.jsp.jstl.fmt.LocalizationContext locCtxt = BundleSupport.getLocalizationContext(pageContext, basename);
		if (var != null)
			pageContext.setAttribute(var, locCtxt, scope);
		else
			Config.set(pageContext, "javax.servlet.jsp.jstl.fmt.localizationContext", locCtxt, scope);
		return 6;
	}

	public void release()
	{
		init();
	}
}
