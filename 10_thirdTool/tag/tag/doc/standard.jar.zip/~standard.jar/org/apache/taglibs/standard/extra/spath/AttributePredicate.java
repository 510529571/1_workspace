// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   AttributePredicate.java

package org.apache.taglibs.standard.extra.spath;

import org.xml.sax.Attributes;

// Referenced classes of package org.apache.taglibs.standard.extra.spath:
//			Predicate

public class AttributePredicate extends Predicate
{

	private String attribute;
	private String target;

	public AttributePredicate(String attribute, String target)
	{
		if (attribute == null)
			throw new IllegalArgumentException("non-null attribute needed");
		if (attribute.indexOf(":") != -1)
			throw new IllegalArgumentException("namespace-qualified attribute names are not currently supported");
		this.attribute = attribute;
		if (target == null)
		{
			throw new IllegalArgumentException("non-null target needed");
		} else
		{
			this.target = target.substring(1, target.length() - 1);
			return;
		}
	}

	public boolean isMatchingAttribute(Attributes a)
	{
		String attValue = a.getValue("", attribute);
		return attValue != null && attValue.equals(target);
	}
}
