// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SPathTag.java

package org.apache.taglibs.standard.extra.spath;

import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.TagSupport;

// Referenced classes of package org.apache.taglibs.standard.extra.spath:
//			SPathFilter, SPathParser, ParseException

public class SPathTag extends TagSupport
{

	private String select;
	private String var;

	public SPathTag()
	{
		init();
	}

	private void init()
	{
		select = var = null;
	}

	public int doStartTag()
		throws JspException
	{
		SPathFilter s = new SPathFilter((new SPathParser(select)).expression());
		pageContext.setAttribute(var, s);
		return 0;
		ParseException ex;
		ex;
		throw new JspTagException(ex.toString(), ex);
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setSelect(String select)
	{
		this.select = select;
	}

	public void setVar(String var)
	{
		this.var = var;
	}
}
