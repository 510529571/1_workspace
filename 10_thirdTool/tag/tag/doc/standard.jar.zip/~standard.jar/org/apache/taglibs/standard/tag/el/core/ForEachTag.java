// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ForEachTag.java

package org.apache.taglibs.standard.tag.el.core;

import java.util.ArrayList;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.jstl.core.LoopTag;
import javax.servlet.jsp.tagext.IterationTag;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.tag.common.core.ForEachSupport;
import org.apache.taglibs.standard.tag.common.core.NullAttributeException;

public class ForEachTag extends ForEachSupport
	implements LoopTag, IterationTag
{

	private String begin_;
	private String end_;
	private String step_;
	private String items_;

	public ForEachTag()
	{
		init();
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setBegin(String begin_)
	{
		this.begin_ = begin_;
		beginSpecified = true;
	}

	public void setEnd(String end_)
	{
		this.end_ = end_;
		endSpecified = true;
	}

	public void setStep(String step_)
	{
		this.step_ = step_;
		stepSpecified = true;
	}

	public void setItems(String items_)
	{
		this.items_ = items_;
	}

	private void init()
	{
		begin_ = null;
		end_ = null;
		step_ = null;
		items_ = null;
	}

	private void evaluateExpressions()
		throws JspException
	{
		if (begin_ != null)
		{
			Object r = ExpressionEvaluatorManager.evaluate("begin", begin_, java.lang.Integer.class, this, pageContext);
			if (r == null)
				throw new NullAttributeException("forEach", "begin");
			begin = ((Integer)r).intValue();
			validateBegin();
		}
		if (end_ != null)
		{
			Object r = ExpressionEvaluatorManager.evaluate("end", end_, java.lang.Integer.class, this, pageContext);
			if (r == null)
				throw new NullAttributeException("forEach", "end");
			end = ((Integer)r).intValue();
			validateEnd();
		}
		if (step_ != null)
		{
			Object r = ExpressionEvaluatorManager.evaluate("step", step_, java.lang.Integer.class, this, pageContext);
			if (r == null)
				throw new NullAttributeException("forEach", "step");
			step = ((Integer)r).intValue();
			validateStep();
		}
		if (items_ != null)
		{
			rawItems = ExpressionEvaluatorManager.evaluate("items", items_, java.lang.Object.class, this, pageContext);
			if (rawItems == null)
				rawItems = new ArrayList();
		}
	}
}
