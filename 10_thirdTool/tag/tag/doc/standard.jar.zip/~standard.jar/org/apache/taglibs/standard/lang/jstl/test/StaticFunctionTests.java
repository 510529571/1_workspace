// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   StaticFunctionTests.java

package org.apache.taglibs.standard.lang.jstl.test;

import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import org.apache.taglibs.standard.lang.jstl.Evaluator;

public class StaticFunctionTests
{

	public StaticFunctionTests()
	{
	}

	public static void main(String args[])
		throws Exception
	{
		Map m = getSampleMethodMap();
		Evaluator e = new Evaluator();
		Object o = e.evaluate("", "4", java.lang.Integer.class, null, null, m, "foo");
		System.out.println(o);
		o = e.evaluate("", "${4}", java.lang.Integer.class, null, null, m, "foo");
		System.out.println(o);
		o = e.evaluate("", "${2+2}", java.lang.Integer.class, null, null, m, "foo");
		System.out.println(o);
		o = e.evaluate("", "${foo:add(2, 3)}", java.lang.Integer.class, null, null, m, "foo");
		System.out.println(o);
		o = e.evaluate("", "${foo:multiply(2, 3)}", java.lang.Integer.class, null, null, m, "foo");
		System.out.println(o);
		o = e.evaluate("", "${add(2, 3)}", java.lang.Integer.class, null, null, m, "foo");
		System.out.println(o);
		o = e.evaluate("", "${multiply(2, 3)}", java.lang.Integer.class, null, null, m, "foo");
		System.out.println(o);
		o = e.evaluate("", "${add(2, 3) + 5}", java.lang.Integer.class, null, null, m, "foo");
		System.out.println(o);
		System.out.println("---");
		o = e.evaluate("", "${getInt(getInteger(getInt(5)))}", java.lang.Integer.class, null, null, m, "foo");
		System.out.println(o);
		o = e.evaluate("", "${getInteger(getInt(getInteger(5)))}", java.lang.Integer.class, null, null, m, "foo");
		System.out.println(o);
		o = e.evaluate("", "${getInt(getInt(getInt(5)))}", java.lang.Integer.class, null, null, m, "foo");
		System.out.println(o);
		o = e.evaluate("", "${getInteger(getInteger(getInteger(5)))}", java.lang.Integer.class, null, null, m, "foo");
		System.out.println(o);
	}

	public static int add(int a, int b)
	{
		return a + b;
	}

	public static int multiply(int a, int b)
	{
		return a * b;
	}

	public static int getInt(Integer i)
	{
		return i.intValue();
	}

	public static Integer getInteger(int i)
	{
		return new Integer(i);
	}

	public static Map getSampleMethodMap()
		throws Exception
	{
		Map m = new HashMap();
		Class c = org.apache.taglibs.standard.lang.jstl.test.StaticFunctionTests.class;
		m.put("foo:add", c.getMethod("add", new Class[] {
			Integer.TYPE, Integer.TYPE
		}));
		m.put("foo:multiply", c.getMethod("multiply", new Class[] {
			Integer.TYPE, Integer.TYPE
		}));
		m.put("foo:getInt", c.getMethod("getInt", new Class[] {
			java.lang.Integer.class
		}));
		m.put("foo:getInteger", c.getMethod("getInteger", new Class[] {
			Integer.TYPE
		}));
		return m;
	}
}
