// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ImportSupport.java

package org.apache.taglibs.standard.tag.common.core;

import java.io.*;
import java.net.*;
import java.util.Locale;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.TryCatchFinally;
import org.apache.taglibs.standard.resources.Resources;

// Referenced classes of package org.apache.taglibs.standard.tag.common.core:
//			NullAttributeException, ParamParent, ParamSupport, Util

public abstract class ImportSupport extends BodyTagSupport
	implements TryCatchFinally, ParamParent
{
	private class ImportResponseWrapper extends HttpServletResponseWrapper
	{

		private StringWriter sw;
		private ByteArrayOutputStream bos;
		private ServletOutputStream sos;
		private boolean isWriterUsed;
		private boolean isStreamUsed;
		private int status;

		public PrintWriter getWriter()
		{
			if (isStreamUsed)
			{
				throw new IllegalStateException(Resources.getMessage("IMPORT_ILLEGAL_STREAM"));
			} else
			{
				isWriterUsed = true;
				return new PrintWriter(sw);
			}
		}

		public ServletOutputStream getOutputStream()
		{
			if (isWriterUsed)
			{
				throw new IllegalStateException(Resources.getMessage("IMPORT_ILLEGAL_WRITER"));
			} else
			{
				isStreamUsed = true;
				return sos;
			}
		}

		public void setContentType(String s)
		{
		}

		public void setLocale(Locale locale)
		{
		}

		public void setStatus(int status)
		{
			this.status = status;
		}

		public int getStatus()
		{
			return status;
		}

		public String getString()
			throws UnsupportedEncodingException
		{
			if (isWriterUsed)
				return sw.toString();
			if (isStreamUsed)
			{
				if (charEncoding != null && !charEncoding.equals(""))
					return bos.toString(charEncoding);
				else
					return bos.toString("ISO-8859-1");
			} else
			{
				return "";
			}
		}


		public ImportResponseWrapper(HttpServletResponse response)
		{
			super(response);
			sw = new StringWriter();
			bos = new ByteArrayOutputStream();
			sos = new ServletOutputStream() {

				public void write(int b)
					throws IOException
				{
					bos.write(b);
				}

			};
			status = 200;
		}
	}


	public static final String VALID_SCHEME_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+.-";
	public static final String DEFAULT_ENCODING = "ISO-8859-1";
	protected String url;
	protected String context;
	protected String charEncoding;
	private String var;
	private int scope;
	private String varReader;
	private Reader r;
	private boolean isAbsoluteUrl;
	private ParamSupport.ParamManager params;
	private String urlWithParams;

	public ImportSupport()
	{
		init();
	}

	private void init()
	{
		url = var = varReader = context = charEncoding = urlWithParams = null;
		params = null;
		scope = 1;
	}

	public int doStartTag()
		throws JspException
	{
		if (context != null && (!context.startsWith("/") || !url.startsWith("/")))
			throw new JspTagException(Resources.getMessage("IMPORT_BAD_RELATIVE"));
		urlWithParams = null;
		params = new ParamSupport.ParamManager();
		if (url == null || url.equals(""))
			throw new NullAttributeException("import", "url");
		isAbsoluteUrl = isAbsoluteUrl();
		try
		{
			if (varReader != null)
			{
				r = acquireReader();
				pageContext.setAttribute(varReader, r);
			}
		}
		catch (IOException ex)
		{
			throw new JspTagException(ex.toString(), ex);
		}
		return 1;
	}

	public int doEndTag()
		throws JspException
	{
		if (varReader == null)
			if (var != null)
				pageContext.setAttribute(var, acquireString(), scope);
			else
				pageContext.getOut().print(acquireString());
		return 6;
		IOException ex;
		ex;
		throw new JspTagException(ex.toString(), ex);
	}

	public void doCatch(Throwable t)
		throws Throwable
	{
		throw t;
	}

	public void doFinally()
	{
		try
		{
			if (varReader != null)
			{
				if (r != null)
					r.close();
				pageContext.removeAttribute(varReader, 1);
			}
		}
		catch (IOException ex) { }
	}

	public void release()
	{
		init();
		super.release();
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setVarReader(String varReader)
	{
		this.varReader = varReader;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
	}

	public void addParameter(String name, String value)
	{
		params.addParameter(name, value);
	}

	private String acquireString()
		throws IOException, JspException
	{
		if (isAbsoluteUrl)
		{
			BufferedReader r = new BufferedReader(acquireReader());
			StringBuffer sb = new StringBuffer();
			int i;
			while ((i = r.read()) != -1) 
				sb.append((char)i);
			return sb.toString();
		}
		if (!(pageContext.getRequest() instanceof HttpServletRequest) || !(pageContext.getResponse() instanceof HttpServletResponse))
			throw new JspTagException(Resources.getMessage("IMPORT_REL_WITHOUT_HTTP"));
		ServletContext c = null;
		String targetUrl = targetUrl();
		if (context != null)
		{
			c = pageContext.getServletContext().getContext(context);
		} else
		{
			c = pageContext.getServletContext();
			if (!targetUrl.startsWith("/"))
			{
				String sp = ((HttpServletRequest)pageContext.getRequest()).getServletPath();
				targetUrl = sp.substring(0, sp.lastIndexOf('/')) + '/' + targetUrl;
			}
		}
		if (c == null)
			throw new JspTagException(Resources.getMessage("IMPORT_REL_WITHOUT_DISPATCHER", context, targetUrl));
		RequestDispatcher rd = c.getRequestDispatcher(stripSession(targetUrl));
		if (rd == null)
			throw new JspTagException(stripSession(targetUrl));
		ImportResponseWrapper irw = new ImportResponseWrapper((HttpServletResponse)pageContext.getResponse());
		try
		{
			rd.include(pageContext.getRequest(), irw);
		}
		catch (IOException ex)
		{
			throw new JspException(ex);
		}
		catch (RuntimeException ex)
		{
			throw new JspException(ex);
		}
		catch (ServletException ex)
		{
			Throwable rc = ex.getRootCause();
			if (rc == null)
				throw new JspException(ex);
			else
				throw new JspException(rc);
		}
		if (irw.getStatus() < 200 || irw.getStatus() > 299)
			throw new JspTagException(irw.getStatus() + " " + stripSession(targetUrl));
		else
			return irw.getString();
	}

	private Reader acquireReader()
		throws IOException, JspException
	{
		String target;
		if (!isAbsoluteUrl)
			return new StringReader(acquireString());
		target = targetUrl();
		Reader r;
		URL u = new URL(target);
		URLConnection uc = u.openConnection();
		java.io.InputStream i = uc.getInputStream();
		r = null;
		String charSet;
		if (charEncoding != null && !charEncoding.equals(""))
		{
			charSet = charEncoding;
		} else
		{
			String contentType = uc.getContentType();
			if (contentType != null)
			{
				charSet = Util.getContentTypeAttribute(contentType, "charset");
				if (charSet == null)
					charSet = "ISO-8859-1";
			} else
			{
				charSet = "ISO-8859-1";
			}
		}
		try
		{
			r = new InputStreamReader(i, charSet);
		}
		catch (Exception ex)
		{
			r = new InputStreamReader(i, "ISO-8859-1");
		}
		if (uc instanceof HttpURLConnection)
		{
			int status = ((HttpURLConnection)uc).getResponseCode();
			if (status < 200 || status > 299)
				throw new JspTagException(status + " " + target);
		}
		return r;
		IOException ex;
		ex;
		throw new JspException(Resources.getMessage("IMPORT_ABS_ERROR", target, ex), ex);
		ex;
		throw new JspException(Resources.getMessage("IMPORT_ABS_ERROR", target, ex), ex);
	}

	private String targetUrl()
	{
		if (urlWithParams == null)
			urlWithParams = params.aggregateParams(url);
		return urlWithParams;
	}

	private boolean isAbsoluteUrl()
		throws JspTagException
	{
		return isAbsoluteUrl(url);
	}

	public static boolean isAbsoluteUrl(String url)
	{
		if (url == null)
			return false;
		int colonPos;
		if ((colonPos = url.indexOf(":")) == -1)
			return false;
		for (int i = 0; i < colonPos; i++)
			if ("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+.-".indexOf(url.charAt(i)) == -1)
				return false;

		return true;
	}

	public static String stripSession(String url)
	{
		StringBuffer u = new StringBuffer(url);
		int sessionStart;
		while ((sessionStart = u.toString().indexOf(";jsessionid=")) != -1) 
		{
			int sessionEnd = u.toString().indexOf(";", sessionStart + 1);
			if (sessionEnd == -1)
				sessionEnd = u.toString().indexOf("?", sessionStart + 1);
			if (sessionEnd == -1)
				sessionEnd = u.length();
			u.delete(sessionStart, sessionEnd);
		}
		return u.toString();
	}
}
