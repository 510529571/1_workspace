// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Token.java

package org.apache.taglibs.standard.extra.spath;


public class Token
{

	public int kind;
	public int beginLine;
	public int beginColumn;
	public int endLine;
	public int endColumn;
	public String image;
	public Token next;
	public Token specialToken;

	public Token()
	{
	}

	public final String toString()
	{
		return image;
	}

	public static final Token newToken(int ofKind)
	{
		switch (ofKind)
		{
		default:
			return new Token();
		}
	}
}
