// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   BundleSupport.java

package org.apache.taglibs.standard.tag.common.fmt;

import java.io.IOException;
import java.util.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.*;
import javax.servlet.jsp.jstl.core.Config;
import javax.servlet.jsp.jstl.fmt.LocalizationContext;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import org.apache.taglibs.standard.tag.common.core.Util;

// Referenced classes of package org.apache.taglibs.standard.tag.common.fmt:
//			SetLocaleSupport

public abstract class BundleSupport extends BodyTagSupport
{

	private static final Locale EMPTY_LOCALE = new Locale("", "");
	protected String basename;
	protected String prefix;
	private Locale fallbackLocale;
	private LocalizationContext locCtxt;

	public BundleSupport()
	{
		init();
	}

	private void init()
	{
		basename = prefix = null;
		locCtxt = null;
	}

	public LocalizationContext getLocalizationContext()
	{
		return locCtxt;
	}

	public String getPrefix()
	{
		return prefix;
	}

	public int doStartTag()
		throws JspException
	{
		locCtxt = getLocalizationContext(pageContext, basename);
		return 2;
	}

	public int doEndTag()
		throws JspException
	{
		if (bodyContent != null)
			try
			{
				pageContext.getOut().print(bodyContent.getString());
			}
			catch (IOException ioe)
			{
				throw new JspTagException(ioe.toString(), ioe);
			}
		return 6;
	}

	public void release()
	{
		init();
	}

	public static LocalizationContext getLocalizationContext(PageContext pc)
	{
		LocalizationContext locCtxt = null;
		Object obj = Config.find(pc, "javax.servlet.jsp.jstl.fmt.localizationContext");
		if (obj == null)
			return null;
		if (obj instanceof LocalizationContext)
			locCtxt = (LocalizationContext)obj;
		else
			locCtxt = getLocalizationContext(pc, (String)obj);
		return locCtxt;
	}

	public static LocalizationContext getLocalizationContext(PageContext pc, String basename)
	{
		LocalizationContext locCtxt = null;
		ResourceBundle bundle = null;
		if (basename == null || basename.equals(""))
			return new LocalizationContext();
		Locale pref = SetLocaleSupport.getLocale(pc, "javax.servlet.jsp.jstl.fmt.locale");
		if (pref != null)
		{
			bundle = findMatch(basename, pref);
			if (bundle != null)
				locCtxt = new LocalizationContext(bundle, pref);
		} else
		{
			locCtxt = findMatch(pc, basename);
		}
		if (locCtxt == null)
		{
			pref = SetLocaleSupport.getLocale(pc, "javax.servlet.jsp.jstl.fmt.fallbackLocale");
			if (pref != null)
			{
				bundle = findMatch(basename, pref);
				if (bundle != null)
					locCtxt = new LocalizationContext(bundle, pref);
			}
		}
		if (locCtxt == null)
			try
			{
				bundle = ResourceBundle.getBundle(basename, EMPTY_LOCALE, Thread.currentThread().getContextClassLoader());
				if (bundle != null)
					locCtxt = new LocalizationContext(bundle, null);
			}
			catch (MissingResourceException mre) { }
		if (locCtxt != null)
		{
			if (locCtxt.getLocale() != null)
				SetLocaleSupport.setResponseLocale(pc, locCtxt.getLocale());
		} else
		{
			locCtxt = new LocalizationContext();
		}
		return locCtxt;
	}

	private static LocalizationContext findMatch(PageContext pageContext, String basename)
	{
		LocalizationContext locCtxt = null;
		Enumeration enum_ = Util.getRequestLocales((HttpServletRequest)pageContext.getRequest());
		do
		{
			if (!enum_.hasMoreElements())
				break;
			Locale pref = (Locale)enum_.nextElement();
			ResourceBundle match = findMatch(basename, pref);
			if (match == null)
				continue;
			locCtxt = new LocalizationContext(match, pref);
			break;
		} while (true);
		return locCtxt;
	}

	private static ResourceBundle findMatch(String basename, Locale pref)
	{
		ResourceBundle match = null;
		try
		{
			ResourceBundle bundle = ResourceBundle.getBundle(basename, pref, Thread.currentThread().getContextClassLoader());
			Locale avail = bundle.getLocale();
			if (pref.equals(avail))
				match = bundle;
			else
			if (pref.getLanguage().equals(avail.getLanguage()) && ("".equals(avail.getCountry()) || pref.getCountry().equals(avail.getCountry())))
				match = bundle;
		}
		catch (MissingResourceException mre) { }
		return match;
	}

}
