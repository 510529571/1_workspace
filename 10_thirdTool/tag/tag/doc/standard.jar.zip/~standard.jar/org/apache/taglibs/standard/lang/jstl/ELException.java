// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ELException.java

package org.apache.taglibs.standard.lang.jstl;


public class ELException extends Exception
{

	Throwable mRootCause;

	public ELException()
	{
	}

	public ELException(String pMessage)
	{
		super(pMessage);
	}

	public ELException(Throwable pRootCause)
	{
		mRootCause = pRootCause;
	}

	public ELException(String pMessage, Throwable pRootCause)
	{
		super(pMessage);
		mRootCause = pRootCause;
	}

	public Throwable getRootCause()
	{
		return mRootCause;
	}

	public String toString()
	{
		if (getMessage() == null)
			return mRootCause.toString();
		if (mRootCause == null)
			return getMessage();
		else
			return getMessage() + ": " + mRootCause;
	}
}
