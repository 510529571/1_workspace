// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   EqualsOperator.java

package org.apache.taglibs.standard.lang.jstl;


// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			EqualityOperator, Logger

public class EqualsOperator extends EqualityOperator
{

	public static final EqualsOperator SINGLETON = new EqualsOperator();

	public EqualsOperator()
	{
	}

	public String getOperatorSymbol()
	{
		return "==";
	}

	public boolean apply(boolean pAreEqual, Logger pLogger)
	{
		return pAreEqual;
	}

}
