// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SetSupport.java

package org.apache.taglibs.standard.tag.common.core;

import java.beans.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;
import javax.servlet.jsp.*;
import javax.servlet.jsp.el.*;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import org.apache.taglibs.standard.resources.Resources;

// Referenced classes of package org.apache.taglibs.standard.tag.common.core:
//			Util

public class SetSupport extends BodyTagSupport
{

	protected Object value;
	protected boolean valueSpecified;
	protected Object target;
	protected String property;
	private String var;
	private int scope;
	private boolean scopeSpecified;

	public SetSupport()
	{
		init();
	}

	private void init()
	{
		value = var = null;
		scopeSpecified = valueSpecified = false;
		scope = 1;
	}

	public void release()
	{
		super.release();
		init();
	}

	public int doEndTag()
		throws JspException
	{
		Object result;
		if (value != null)
			result = value;
		else
		if (valueSpecified)
			result = null;
		else
		if (bodyContent == null || bodyContent.getString() == null)
			result = "";
		else
			result = bodyContent.getString().trim();
		if (var != null)
		{
			if (result != null)
				pageContext.setAttribute(var, result, scope);
			else
			if (scopeSpecified)
				pageContext.removeAttribute(var, scope);
			else
				pageContext.removeAttribute(var);
		} else
		if (target != null)
		{
			if (target instanceof Map)
			{
				if (result == null)
					((Map)target).remove(property);
				else
					((Map)target).put(property, result);
			} else
			{
				try
				{
					PropertyDescriptor pd[] = Introspector.getBeanInfo(target.getClass()).getPropertyDescriptors();
					boolean succeeded = false;
					for (int i = 0; i < pd.length; i++)
					{
						if (!pd[i].getName().equals(property))
							continue;
						Method m = pd[i].getWriteMethod();
						if (m == null)
							throw new JspException(Resources.getMessage("SET_NO_SETTER_METHOD", property));
						if (result != null)
							try
							{
								m.invoke(target, new Object[] {
									convertToExpectedType(result, m.getParameterTypes()[0])
								});
							}
							catch (ELException ex)
							{
								throw new JspTagException(ex);
							}
						else
							m.invoke(target, new Object[] {
								null
							});
						succeeded = true;
					}

					if (!succeeded)
						throw new JspTagException(Resources.getMessage("SET_INVALID_PROPERTY", property));
				}
				catch (IllegalAccessException ex)
				{
					throw new JspException(ex);
				}
				catch (IntrospectionException ex)
				{
					throw new JspException(ex);
				}
				catch (InvocationTargetException ex)
				{
					throw new JspException(ex);
				}
			}
		} else
		{
			throw new JspTagException();
		}
		return 6;
	}

	private Object convertToExpectedType(final Object value, Class expectedType)
		throws ELException
	{
		ExpressionEvaluator evaluator = pageContext.getExpressionEvaluator();
		return evaluator.evaluate("${result}", expectedType, new VariableResolver() {

			public Object resolveVariable(String pName)
				throws ELException
			{
				return value;
			}

		}, null);
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
		scopeSpecified = true;
	}
}
