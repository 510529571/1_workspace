// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   PrimitiveObjects.java

package org.apache.taglibs.standard.lang.jstl;


class PrimitiveObjects
{

	static int BYTE_LOWER_BOUND = 0;
	static int BYTE_UPPER_BOUND = 255;
	static int CHARACTER_LOWER_BOUND = 0;
	static int CHARACTER_UPPER_BOUND = 255;
	static int SHORT_LOWER_BOUND = -1000;
	static int SHORT_UPPER_BOUND = 1000;
	static int INTEGER_LOWER_BOUND = -1000;
	static int INTEGER_UPPER_BOUND = 1000;
	static int LONG_LOWER_BOUND = -1000;
	static int LONG_UPPER_BOUND = 1000;
	static Byte mBytes[] = createBytes();
	static Character mCharacters[] = createCharacters();
	static Short mShorts[] = createShorts();
	static Integer mIntegers[] = createIntegers();
	static Long mLongs[] = createLongs();

	PrimitiveObjects()
	{
	}

	public static Boolean getBoolean(boolean pValue)
	{
		return pValue ? Boolean.TRUE : Boolean.FALSE;
	}

	public static Byte getByte(byte pValue)
	{
		if (pValue >= BYTE_LOWER_BOUND && pValue <= BYTE_UPPER_BOUND)
			return mBytes[pValue - BYTE_LOWER_BOUND];
		else
			return new Byte(pValue);
	}

	public static Character getCharacter(char pValue)
	{
		if (pValue >= CHARACTER_LOWER_BOUND && pValue <= CHARACTER_UPPER_BOUND)
			return mCharacters[pValue - CHARACTER_LOWER_BOUND];
		else
			return new Character(pValue);
	}

	public static Short getShort(short pValue)
	{
		if (pValue >= SHORT_LOWER_BOUND && pValue <= SHORT_UPPER_BOUND)
			return mShorts[pValue - SHORT_LOWER_BOUND];
		else
			return new Short(pValue);
	}

	public static Integer getInteger(int pValue)
	{
		if (pValue >= INTEGER_LOWER_BOUND && pValue <= INTEGER_UPPER_BOUND)
			return mIntegers[pValue - INTEGER_LOWER_BOUND];
		else
			return new Integer(pValue);
	}

	public static Long getLong(long pValue)
	{
		if (pValue >= (long)LONG_LOWER_BOUND && pValue <= (long)LONG_UPPER_BOUND)
			return mLongs[(int)pValue - LONG_LOWER_BOUND];
		else
			return new Long(pValue);
	}

	public static Float getFloat(float pValue)
	{
		return new Float(pValue);
	}

	public static Double getDouble(double pValue)
	{
		return new Double(pValue);
	}

	public static Class getPrimitiveObjectClass(Class pClass)
	{
		if (pClass == Boolean.TYPE)
			return java.lang.Boolean.class;
		if (pClass == Byte.TYPE)
			return java.lang.Byte.class;
		if (pClass == Short.TYPE)
			return java.lang.Short.class;
		if (pClass == Character.TYPE)
			return java.lang.Character.class;
		if (pClass == Integer.TYPE)
			return java.lang.Integer.class;
		if (pClass == Long.TYPE)
			return java.lang.Long.class;
		if (pClass == Float.TYPE)
			return java.lang.Float.class;
		if (pClass == Double.TYPE)
			return java.lang.Double.class;
		else
			return pClass;
	}

	static Byte[] createBytes()
	{
		int len = (BYTE_UPPER_BOUND - BYTE_LOWER_BOUND) + 1;
		Byte ret[] = new Byte[len];
		byte val = (byte)BYTE_LOWER_BOUND;
		for (int i = 0; i < len;)
		{
			ret[i] = new Byte(val);
			i++;
			val++;
		}

		return ret;
	}

	static Character[] createCharacters()
	{
		int len = (CHARACTER_UPPER_BOUND - CHARACTER_LOWER_BOUND) + 1;
		Character ret[] = new Character[len];
		char val = (char)CHARACTER_LOWER_BOUND;
		for (int i = 0; i < len;)
		{
			ret[i] = new Character(val);
			i++;
			val++;
		}

		return ret;
	}

	static Short[] createShorts()
	{
		int len = (SHORT_UPPER_BOUND - SHORT_LOWER_BOUND) + 1;
		Short ret[] = new Short[len];
		short val = (short)SHORT_LOWER_BOUND;
		for (int i = 0; i < len;)
		{
			ret[i] = new Short(val);
			i++;
			val++;
		}

		return ret;
	}

	static Integer[] createIntegers()
	{
		int len = (INTEGER_UPPER_BOUND - INTEGER_LOWER_BOUND) + 1;
		Integer ret[] = new Integer[len];
		int val = INTEGER_LOWER_BOUND;
		for (int i = 0; i < len;)
		{
			ret[i] = new Integer(val);
			i++;
			val++;
		}

		return ret;
	}

	static Long[] createLongs()
	{
		int len = (LONG_UPPER_BOUND - LONG_LOWER_BOUND) + 1;
		Long ret[] = new Long[len];
		long val = LONG_LOWER_BOUND;
		for (int i = 0; i < len;)
		{
			ret[i] = new Long(val);
			i++;
			val++;
		}

		return ret;
	}

}
