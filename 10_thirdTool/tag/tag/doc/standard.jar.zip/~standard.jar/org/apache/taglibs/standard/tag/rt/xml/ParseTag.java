// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParseTag.java

package org.apache.taglibs.standard.tag.rt.xml;

import javax.servlet.jsp.JspTagException;
import org.apache.taglibs.standard.tag.common.xml.ParseSupport;
import org.xml.sax.XMLFilter;

public class ParseTag extends ParseSupport
{

	public ParseTag()
	{
	}

	public void setXml(Object xml)
		throws JspTagException
	{
		this.xml = xml;
	}

	public void setDoc(Object xml)
		throws JspTagException
	{
		this.xml = xml;
	}

	public void setSystemId(String systemId)
		throws JspTagException
	{
		this.systemId = systemId;
	}

	public void setFilter(XMLFilter filter)
		throws JspTagException
	{
		this.filter = filter;
	}
}
