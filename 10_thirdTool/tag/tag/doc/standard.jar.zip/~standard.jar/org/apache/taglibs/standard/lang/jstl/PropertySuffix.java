// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   PropertySuffix.java

package org.apache.taglibs.standard.lang.jstl;

import java.util.Map;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			ArraySuffix, ELException, StringLiteral, VariableResolver, 
//			Logger

public class PropertySuffix extends ArraySuffix
{

	String mName;

	public String getName()
	{
		return mName;
	}

	public void setName(String pName)
	{
		mName = pName;
	}

	public PropertySuffix(String pName)
	{
		super(null);
		mName = pName;
	}

	Object evaluateIndex(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger)
		throws ELException
	{
		return mName;
	}

	String getOperatorSymbol()
	{
		return ".";
	}

	public String getExpressionString()
	{
		return "." + StringLiteral.toIdentifierToken(mName);
	}
}
