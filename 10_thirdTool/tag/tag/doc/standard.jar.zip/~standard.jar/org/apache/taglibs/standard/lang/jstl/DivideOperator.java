// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DivideOperator.java

package org.apache.taglibs.standard.lang.jstl;


// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			BinaryOperator, ELException, Logger, Constants, 
//			PrimitiveObjects, Coercions

public class DivideOperator extends BinaryOperator
{

	public static final DivideOperator SINGLETON = new DivideOperator();

	public DivideOperator()
	{
	}

	public String getOperatorSymbol()
	{
		return "/";
	}

	public Object apply(Object pLeft, Object pRight, Object pContext, Logger pLogger)
		throws ELException
	{
		double left;
		double right;
		if (pLeft == null && pRight == null)
		{
			if (pLogger.isLoggingWarning())
				pLogger.logWarning(Constants.ARITH_OP_NULL, getOperatorSymbol());
			return PrimitiveObjects.getInteger(0);
		}
		left = Coercions.coerceToPrimitiveNumber(pLeft, java.lang.Double.class, pLogger).doubleValue();
		right = Coercions.coerceToPrimitiveNumber(pRight, java.lang.Double.class, pLogger).doubleValue();
		return PrimitiveObjects.getDouble(left / right);
		Exception exc;
		exc;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.ARITH_ERROR, getOperatorSymbol(), "" + left, "" + right);
		return PrimitiveObjects.getInteger(0);
	}

}
