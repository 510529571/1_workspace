// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParseSupport.java

package org.apache.taglibs.standard.tag.common.xml;

import java.io.*;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.xml.parsers.*;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.sax.SAXTransformerFactory;
import javax.xml.transform.sax.TransformerHandler;
import org.apache.taglibs.standard.resources.Resources;
import org.apache.taglibs.standard.tag.common.core.ImportSupport;
import org.apache.taglibs.standard.tag.common.core.Util;
import org.w3c.dom.Document;
import org.xml.sax.*;
import org.xml.sax.helpers.XMLReaderFactory;

public abstract class ParseSupport extends BodyTagSupport
{
	public static class JstlEntityResolver
		implements EntityResolver
	{

		private final PageContext ctx;

		public InputSource resolveEntity(String publicId, String systemId)
			throws FileNotFoundException
		{
			if (systemId == null)
				return null;
			if (systemId.startsWith("jstl:"))
				systemId = systemId.substring(5);
			if (ImportSupport.isAbsoluteUrl(systemId))
				return null;
			java.io.InputStream s;
			if (systemId.startsWith("/"))
			{
				s = ctx.getServletContext().getResourceAsStream(systemId);
				if (s == null)
					throw new FileNotFoundException(Resources.getMessage("UNABLE_TO_RESOLVE_ENTITY", systemId));
			} else
			{
				String pagePath = ((HttpServletRequest)ctx.getRequest()).getServletPath();
				String basePath = pagePath.substring(0, pagePath.lastIndexOf("/"));
				s = ctx.getServletContext().getResourceAsStream(basePath + "/" + systemId);
				if (s == null)
					throw new FileNotFoundException(Resources.getMessage("UNABLE_TO_RESOLVE_ENTITY", systemId));
			}
			return new InputSource(s);
		}

		public JstlEntityResolver(PageContext ctx)
		{
			this.ctx = ctx;
		}
	}


	protected Object xml;
	protected String systemId;
	protected XMLFilter filter;
	private String var;
	private String varDom;
	private int scope;
	private int scopeDom;
	private DocumentBuilderFactory dbf;
	private DocumentBuilder db;
	private TransformerFactory tf;
	private TransformerHandler th;

	public ParseSupport()
	{
		init();
	}

	private void init()
	{
		var = varDom = null;
		xml = null;
		systemId = null;
		filter = null;
		dbf = null;
		db = null;
		tf = null;
		th = null;
		scope = 1;
		scopeDom = 1;
	}

	public int doEndTag()
		throws JspException
	{
		if (dbf == null)
		{
			dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			dbf.setValidating(false);
		}
		db = dbf.newDocumentBuilder();
		if (filter != null)
		{
			if (tf == null)
				tf = TransformerFactory.newInstance();
			if (!tf.getFeature("http://javax.xml.transform.sax.SAXTransformerFactory/feature"))
				throw new JspTagException(Resources.getMessage("PARSE_NO_SAXTRANSFORMER"));
			SAXTransformerFactory stf = (SAXTransformerFactory)tf;
			th = stf.newTransformerHandler();
		}
		Object xmlText = xml;
		if (xmlText == null)
			if (bodyContent != null && bodyContent.getString() != null)
				xmlText = bodyContent.getString().trim();
			else
				xmlText = "";
		Document d;
		if (xmlText instanceof String)
			d = parseStringWithFilter((String)xmlText, filter);
		else
		if (xmlText instanceof Reader)
			d = parseReaderWithFilter((Reader)xmlText, filter);
		else
			throw new JspTagException(Resources.getMessage("PARSE_INVALID_SOURCE"));
		if (var != null)
			pageContext.setAttribute(var, d, scope);
		if (varDom != null)
			pageContext.setAttribute(varDom, d, scopeDom);
		return 6;
		SAXException ex;
		ex;
		throw new JspException(ex);
		ex;
		throw new JspException(ex);
		ex;
		throw new JspException(ex);
		ex;
		throw new JspException(ex);
	}

	public void release()
	{
		init();
	}

	private Document parseInputSourceWithFilter(InputSource s, XMLFilter f)
		throws SAXException, IOException
	{
		if (f != null)
		{
			Document o = db.newDocument();
			th.setResult(new DOMResult(o));
			XMLReader xr = XMLReaderFactory.createXMLReader();
			xr.setEntityResolver(new JstlEntityResolver(pageContext));
			f.setParent(xr);
			f.setContentHandler(th);
			f.parse(s);
			return o;
		} else
		{
			return parseInputSource(s);
		}
	}

	private Document parseReaderWithFilter(Reader r, XMLFilter f)
		throws SAXException, IOException
	{
		return parseInputSourceWithFilter(new InputSource(r), f);
	}

	private Document parseStringWithFilter(String s, XMLFilter f)
		throws SAXException, IOException
	{
		StringReader r = new StringReader(s);
		return parseReaderWithFilter(r, f);
	}

	private Document parseURLWithFilter(String url, XMLFilter f)
		throws SAXException, IOException
	{
		return parseInputSourceWithFilter(new InputSource(url), f);
	}

	private Document parseInputSource(InputSource s)
		throws SAXException, IOException
	{
		db.setEntityResolver(new JstlEntityResolver(pageContext));
		if (systemId == null)
			s.setSystemId("jstl:");
		else
		if (ImportSupport.isAbsoluteUrl(systemId))
			s.setSystemId(systemId);
		else
			s.setSystemId("jstl:" + systemId);
		return db.parse(s);
	}

	private Document parseReader(Reader r)
		throws SAXException, IOException
	{
		return parseInputSource(new InputSource(r));
	}

	private Document parseString(String s)
		throws SAXException, IOException
	{
		StringReader r = new StringReader(s);
		return parseReader(r);
	}

	private Document parseURL(String url)
		throws SAXException, IOException
	{
		return parseInputSource(new InputSource(url));
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setVarDom(String varDom)
	{
		this.varDom = varDom;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
	}

	public void setScopeDom(String scopeDom)
	{
		this.scopeDom = Util.getScope(scopeDom);
	}
}
