// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParamSupport.java

package org.apache.taglibs.standard.tag.common.xml;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import org.apache.taglibs.standard.resources.Resources;

// Referenced classes of package org.apache.taglibs.standard.tag.common.xml:
//			TransformSupport

public abstract class ParamSupport extends BodyTagSupport
{

	protected String name;
	protected Object value;

	public ParamSupport()
	{
		init();
	}

	private void init()
	{
		name = null;
		value = null;
	}

	public int doEndTag()
		throws JspException
	{
		javax.servlet.jsp.tagext.Tag t = findAncestorWithClass(this, org.apache.taglibs.standard.tag.common.xml.TransformSupport.class);
		if (t == null)
			throw new JspTagException(Resources.getMessage("PARAM_OUTSIDE_TRANSFORM"));
		TransformSupport parent = (TransformSupport)t;
		Object value = this.value;
		if (value == null)
			if (bodyContent == null || bodyContent.getString() == null)
				value = "";
			else
				value = bodyContent.getString().trim();
		parent.addParameter(name, value);
		return 6;
	}

	public void release()
	{
		init();
	}
}
