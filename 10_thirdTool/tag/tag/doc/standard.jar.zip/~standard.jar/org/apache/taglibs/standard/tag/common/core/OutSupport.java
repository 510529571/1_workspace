// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   OutSupport.java

package org.apache.taglibs.standard.tag.common.core;

import java.io.IOException;
import java.io.Reader;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

// Referenced classes of package org.apache.taglibs.standard.tag.common.core:
//			Util

public class OutSupport extends BodyTagSupport
{

	protected Object value;
	protected String def;
	protected boolean escapeXml;
	private boolean needBody;

	public OutSupport()
	{
		init();
	}

	private void init()
	{
		value = def = null;
		escapeXml = true;
		needBody = false;
	}

	public void release()
	{
		super.release();
		init();
	}

	public int doStartTag()
		throws JspException
	{
		needBody = false;
		bodyContent = null;
		if (value == null)
			break MISSING_BLOCK_LABEL_34;
		out(pageContext, escapeXml, value);
		return 0;
		if (def != null)
			break MISSING_BLOCK_LABEL_48;
		needBody = true;
		return 2;
		if (def != null)
			out(pageContext, escapeXml, def);
		return 0;
		IOException ex;
		ex;
		throw new JspException(ex.toString(), ex);
	}

	public int doEndTag()
		throws JspException
	{
		if (!needBody)
			return 6;
		if (bodyContent != null && bodyContent.getString() != null)
			out(pageContext, escapeXml, bodyContent.getString().trim());
		return 6;
		IOException ex;
		ex;
		throw new JspException(ex.toString(), ex);
	}

	public static void out(PageContext pageContext, boolean escapeXml, Object obj)
		throws IOException
	{
		JspWriter w = pageContext.getOut();
		if (!escapeXml)
		{
			if (obj instanceof Reader)
			{
				Reader reader = (Reader)obj;
				char buf[] = new char[4096];
				int count;
				while ((count = reader.read(buf, 0, 4096)) != -1) 
					w.write(buf, 0, count);
			} else
			{
				w.write(obj.toString());
			}
		} else
		if (obj instanceof Reader)
		{
			Reader reader = (Reader)obj;
			char buf[] = new char[4096];
			int count;
			while ((count = reader.read(buf, 0, 4096)) != -1) 
				writeEscapedXml(buf, count, w);
		} else
		{
			String text = obj.toString();
			writeEscapedXml(text.toCharArray(), text.length(), w);
		}
	}

	private static void writeEscapedXml(char buffer[], int length, JspWriter w)
		throws IOException
	{
		int start = 0;
		for (int i = 0; i < length; i++)
		{
			char c = buffer[i];
			if (c > '>')
				continue;
			char escaped[] = Util.specialCharactersRepresentation[c];
			if (escaped == null)
				continue;
			if (start < i)
				w.write(buffer, start, i - start);
			w.write(escaped);
			start = i + 1;
		}

		if (start < length)
			w.write(buffer, start, length - start);
	}
}
