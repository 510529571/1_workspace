// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TransactionTag.java

package org.apache.taglibs.standard.tag.el.sql;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.tag.common.sql.TransactionTagSupport;

public class TransactionTag extends TransactionTagSupport
{

	private String dataSourceEL;
	private String isolationEL;

	public TransactionTag()
	{
	}

	public void setDataSource(String dataSourceEL)
	{
		this.dataSourceEL = dataSourceEL;
		dataSourceSpecified = true;
	}

	public void setIsolation(String isolationEL)
	{
		this.isolationEL = isolationEL;
	}

	public int doStartTag()
		throws JspException
	{
		if (dataSourceEL != null)
			rawDataSource = ExpressionEvaluatorManager.evaluate("dataSource", dataSourceEL, java.lang.Object.class, this, pageContext);
		if (isolationEL != null)
		{
			isolationEL = (String)ExpressionEvaluatorManager.evaluate("isolation", isolationEL, java.lang.String.class, this, pageContext);
			super.setIsolation(isolationEL);
		}
		return super.doStartTag();
	}
}
