// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParseNumberSupport.java

package org.apache.taglibs.standard.tag.common.fmt;

import java.io.IOException;
import java.text.*;
import java.util.Locale;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import org.apache.taglibs.standard.resources.Resources;
import org.apache.taglibs.standard.tag.common.core.Util;

// Referenced classes of package org.apache.taglibs.standard.tag.common.fmt:
//			SetLocaleSupport

public abstract class ParseNumberSupport extends BodyTagSupport
{

	private static final String NUMBER = "number";
	private static final String CURRENCY = "currency";
	private static final String PERCENT = "percent";
	protected String value;
	protected boolean valueSpecified;
	protected String type;
	protected String pattern;
	protected Locale parseLocale;
	protected boolean isIntegerOnly;
	protected boolean integerOnlySpecified;
	private String var;
	private int scope;

	public ParseNumberSupport()
	{
		init();
	}

	private void init()
	{
		value = type = pattern = var = null;
		valueSpecified = false;
		parseLocale = null;
		integerOnlySpecified = false;
		scope = 1;
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
	}

	public int doEndTag()
		throws JspException
	{
		String input = null;
		if (valueSpecified)
			input = value;
		else
		if (bodyContent != null && bodyContent.getString() != null)
			input = bodyContent.getString().trim();
		if (input == null || input.equals(""))
		{
			if (var != null)
				pageContext.removeAttribute(var, scope);
			return 6;
		}
		Locale loc = parseLocale;
		if (loc == null)
			loc = SetLocaleSupport.getFormattingLocale(pageContext, this, false, NumberFormat.getAvailableLocales());
		if (loc == null)
			throw new JspException(Resources.getMessage("PARSE_NUMBER_NO_PARSE_LOCALE"));
		NumberFormat parser = null;
		if (pattern != null && !pattern.equals(""))
		{
			DecimalFormatSymbols symbols = new DecimalFormatSymbols(loc);
			parser = new DecimalFormat(pattern, symbols);
		} else
		{
			parser = createParser(loc);
		}
		if (integerOnlySpecified)
			parser.setParseIntegerOnly(isIntegerOnly);
		Number parsed = null;
		try
		{
			parsed = parser.parse(input);
		}
		catch (ParseException pe)
		{
			throw new JspException(Resources.getMessage("PARSE_NUMBER_PARSE_ERROR", input), pe);
		}
		if (var != null)
			pageContext.setAttribute(var, parsed, scope);
		else
			try
			{
				pageContext.getOut().print(parsed);
			}
			catch (IOException ioe)
			{
				throw new JspTagException(ioe.toString(), ioe);
			}
		return 6;
	}

	public void release()
	{
		init();
	}

	private NumberFormat createParser(Locale loc)
		throws JspException
	{
		NumberFormat parser = null;
		if (type == null || "number".equalsIgnoreCase(type))
			parser = NumberFormat.getNumberInstance(loc);
		else
		if ("currency".equalsIgnoreCase(type))
			parser = NumberFormat.getCurrencyInstance(loc);
		else
		if ("percent".equalsIgnoreCase(type))
			parser = NumberFormat.getPercentInstance(loc);
		else
			throw new JspException(Resources.getMessage("PARSE_NUMBER_INVALID_TYPE", type));
		return parser;
	}
}
