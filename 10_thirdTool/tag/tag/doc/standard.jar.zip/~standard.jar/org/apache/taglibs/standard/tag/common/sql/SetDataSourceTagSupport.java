// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SetDataSourceTagSupport.java

package org.apache.taglibs.standard.tag.common.sql;

import javax.servlet.jsp.*;
import javax.servlet.jsp.jstl.core.Config;
import javax.servlet.jsp.tagext.TagSupport;
import org.apache.taglibs.standard.resources.Resources;
import org.apache.taglibs.standard.tag.common.core.Util;

// Referenced classes of package org.apache.taglibs.standard.tag.common.sql:
//			DataSourceWrapper, DataSourceUtil

public class SetDataSourceTagSupport extends TagSupport
{

	protected Object dataSource;
	protected boolean dataSourceSpecified;
	protected String jdbcURL;
	protected String driverClassName;
	protected String userName;
	protected String password;
	private int scope;
	private String var;

	public SetDataSourceTagSupport()
	{
		init();
	}

	private void init()
	{
		dataSource = null;
		dataSourceSpecified = false;
		jdbcURL = driverClassName = userName = password = null;
		var = null;
		scope = 1;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public int doStartTag()
		throws JspException
	{
		javax.sql.DataSource ds;
		if (dataSource != null)
		{
			ds = DataSourceUtil.getDataSource(dataSource, pageContext);
		} else
		{
			if (dataSourceSpecified)
				throw new JspException(Resources.getMessage("SQL_DATASOURCE_NULL"));
			DataSourceWrapper dsw = new DataSourceWrapper();
			try
			{
				if (driverClassName != null)
					dsw.setDriverClassName(driverClassName);
			}
			catch (Exception e)
			{
				throw new JspTagException(Resources.getMessage("DRIVER_INVALID_CLASS", e.toString()), e);
			}
			dsw.setJdbcURL(jdbcURL);
			dsw.setUserName(userName);
			dsw.setPassword(password);
			ds = dsw;
		}
		if (var != null)
			pageContext.setAttribute(var, ds, scope);
		else
			Config.set(pageContext, "javax.servlet.jsp.jstl.sql.dataSource", ds, scope);
		return 0;
	}

	public void release()
	{
		init();
	}
}
