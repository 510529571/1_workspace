// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JstlBaseTLV.java

package org.apache.taglibs.standard.tlv;

import java.io.IOException;
import java.util.*;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.*;
import javax.xml.parsers.*;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluator;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.resources.Resources;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public abstract class JstlBaseTLV extends TagLibraryValidator
{

	private final String EXP_ATT_PARAM = "expressionAttributes";
	protected static final String VAR = "var";
	protected static final String SCOPE = "scope";
	protected static final String PAGE_SCOPE = "page";
	protected static final String REQUEST_SCOPE = "request";
	protected static final String SESSION_SCOPE = "session";
	protected static final String APPLICATION_SCOPE = "application";
	protected final String JSP = "http://java.sun.com/JSP/Page";
	private static final int TYPE_UNDEFINED = 0;
	protected static final int TYPE_CORE = 1;
	protected static final int TYPE_FMT = 2;
	protected static final int TYPE_SQL = 3;
	protected static final int TYPE_XML = 4;
	private int tlvType;
	protected String uri;
	protected String prefix;
	protected Vector messageVector;
	protected Map config;
	protected boolean failed;
	protected String lastElementId;

	protected abstract DefaultHandler getHandler();

	public JstlBaseTLV()
	{
		tlvType = 0;
		init();
	}

	private void init()
	{
		messageVector = null;
		prefix = null;
		config = null;
	}

	public void release()
	{
		super.release();
		init();
	}

	public synchronized ValidationMessage[] validate(int type, String prefix, String uri, PageData page)
	{
		tlvType = type;
		this.uri = uri;
		messageVector = new Vector();
		this.prefix = prefix;
		SAXException ex;
		try
		{
			if (config == null)
				configure((String)getInitParameters().get("expressionAttributes"));
		}
		// Misplaced declaration of an exception variable
		catch (SAXException ex)
		{
			return vmFromString(Resources.getMessage("TLV_PARAMETER_ERROR", "expressionAttributes"));
		}
		DefaultHandler h = getHandler();
		SAXParserFactory f = SAXParserFactory.newInstance();
		f.setValidating(false);
		f.setNamespaceAware(true);
		SAXParser p = f.newSAXParser();
		p.parse(page.getInputStream(), h);
		if (messageVector.size() == 0)
			return null;
		return vmFromVector(messageVector);
		h;
		return vmFromString(h.toString());
		h;
		return vmFromString(h.toString());
		h;
		return vmFromString(h.toString());
	}

	protected String validateExpression(String elem, String att, String expr)
	{
		ExpressionEvaluator current;
		try
		{
			current = ExpressionEvaluatorManager.getEvaluatorByName("org.apache.taglibs.standard.lang.jstl.Evaluator");
		}
		catch (JspException ex)
		{
			return ex.getMessage();
		}
		String response = current.validate(att, expr);
		if (response == null)
			return response;
		else
			return "tag = '" + elem + "' / attribute = '" + att + "': " + response;
	}

	protected boolean isTag(String tagUri, String tagLn, String matchUri, String matchLn)
	{
		if (tagUri == null || tagLn == null || matchUri == null || matchLn == null)
			return false;
		if (tagUri.length() > matchUri.length())
			return tagUri.startsWith(matchUri) && tagLn.equals(matchLn);
		else
			return matchUri.startsWith(tagUri) && tagLn.equals(matchLn);
	}

	protected boolean isJspTag(String tagUri, String tagLn, String target)
	{
		return isTag(tagUri, tagLn, "http://java.sun.com/JSP/Page", target);
	}

	private boolean isTag(int type, String tagUri, String tagLn, String target)
	{
		return tlvType == type && isTag(tagUri, tagLn, uri, target);
	}

	protected boolean isCoreTag(String tagUri, String tagLn, String target)
	{
		return isTag(1, tagUri, tagLn, target);
	}

	protected boolean isFmtTag(String tagUri, String tagLn, String target)
	{
		return isTag(2, tagUri, tagLn, target);
	}

	protected boolean isSqlTag(String tagUri, String tagLn, String target)
	{
		return isTag(3, tagUri, tagLn, target);
	}

	protected boolean isXmlTag(String tagUri, String tagLn, String target)
	{
		return isTag(4, tagUri, tagLn, target);
	}

	protected boolean hasAttribute(Attributes a, String att)
	{
		return a.getValue(att) != null;
	}

	protected void fail(String message)
	{
		failed = true;
		messageVector.add(new ValidationMessage(lastElementId, message));
	}

	protected boolean isSpecified(TagData data, String attributeName)
	{
		return data.getAttribute(attributeName) != null;
	}

	protected boolean hasNoInvalidScope(Attributes a)
	{
		String scope = a.getValue("scope");
		return scope == null || scope.equals("page") || scope.equals("request") || scope.equals("session") || scope.equals("application");
	}

	protected boolean hasEmptyVar(Attributes a)
	{
		return "".equals(a.getValue("var"));
	}

	protected boolean hasDanglingScope(Attributes a)
	{
		return a.getValue("scope") != null && a.getValue("var") == null;
	}

	protected String getLocalPart(String qname)
	{
		int colon = qname.indexOf(":");
		if (colon == -1)
			return qname;
		else
			return qname.substring(colon + 1);
	}

	private void configure(String info)
	{
		config = new HashMap();
		if (info == null)
			return;
		String attribute;
		Object atts;
		for (StringTokenizer st = new StringTokenizer(info); st.hasMoreTokens(); ((Set)atts).add(attribute))
		{
			String pair = st.nextToken();
			StringTokenizer pairTokens = new StringTokenizer(pair, ":");
			String element = pairTokens.nextToken();
			attribute = pairTokens.nextToken();
			atts = config.get(element);
			if (atts == null)
			{
				atts = new HashSet();
				config.put(element, atts);
			}
		}

	}

	static ValidationMessage[] vmFromString(String message)
	{
		return (new ValidationMessage[] {
			new ValidationMessage(null, message)
		});
	}

	static ValidationMessage[] vmFromVector(Vector v)
	{
		ValidationMessage vm[] = new ValidationMessage[v.size()];
		for (int i = 0; i < vm.length; i++)
			vm[i] = (ValidationMessage)v.get(i);

		return vm;
	}
}
