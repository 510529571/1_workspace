// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   RemoveTag.java

package org.apache.taglibs.standard.tag.common.core;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;

// Referenced classes of package org.apache.taglibs.standard.tag.common.core:
//			Util

public class RemoveTag extends TagSupport
{

	private final String APPLICATION = "application";
	private final String SESSION = "session";
	private final String REQUEST = "request";
	private final String PAGE = "page";
	private int scope;
	private boolean scopeSpecified;
	private String var;

	public RemoveTag()
	{
		init();
	}

	private void init()
	{
		var = null;
		scope = 1;
		scopeSpecified = false;
	}

	public void release()
	{
		super.release();
		init();
	}

	public int doEndTag()
		throws JspException
	{
		if (!scopeSpecified)
			pageContext.removeAttribute(var);
		else
			pageContext.removeAttribute(var, scope);
		return 6;
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
		scopeSpecified = true;
	}
}
