// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JstlXmlTLV.java

package org.apache.taglibs.standard.tlv;

import java.util.*;
import javax.servlet.jsp.tagext.PageData;
import javax.servlet.jsp.tagext.ValidationMessage;
import org.apache.taglibs.standard.resources.Resources;
import org.xml.sax.Attributes;
import org.xml.sax.helpers.DefaultHandler;

// Referenced classes of package org.apache.taglibs.standard.tlv:
//			JstlBaseTLV

public class JstlXmlTLV extends JstlBaseTLV
{
	private class Handler extends DefaultHandler
	{

		private int depth;
		private Stack chooseDepths;
		private Stack chooseHasOtherwise;
		private Stack chooseHasWhen;
		private String lastElementName;
		private boolean bodyNecessary;
		private boolean bodyIllegal;
		private Stack transformWithSource;

		public void startElement(String ns, String ln, String qn, Attributes a)
		{
			if (ln == null)
				ln = getLocalPart(qn);
			if (qn.equals("jsp:text"))
				return;
			if (bodyIllegal)
				fail(Resources.getMessage("TLV_ILLEGAL_BODY", lastElementName));
			Set expAtts;
			if (qn.startsWith(prefix + ":") && (expAtts = (Set)config.get(ln)) != null)
			{
				for (int i = 0; i < a.getLength(); i++)
				{
					String attName = a.getLocalName(i);
					if (!expAtts.contains(attName))
						continue;
					String vMsg = validateExpression(ln, attName, a.getValue(i));
					if (vMsg != null)
						fail(vMsg);
				}

			}
			if (qn.startsWith(prefix + ":") && !hasNoInvalidScope(a))
				fail(Resources.getMessage("TLV_INVALID_ATTRIBUTE", "scope", qn, a.getValue("scope")));
			if (qn.startsWith(prefix + ":") && hasEmptyVar(a))
				fail(Resources.getMessage("TLV_EMPTY_VAR", qn));
			if (qn.startsWith(prefix + ":") && hasDanglingScope(a))
				fail(Resources.getMessage("TLV_DANGLING_SCOPE", qn));
			if (chooseChild())
			{
				if (isXmlTag(ns, ln, "when"))
				{
					chooseHasWhen.pop();
					chooseHasWhen.push(Boolean.TRUE);
				}
				if (!isXmlTag(ns, ln, "when") && !isXmlTag(ns, ln, "otherwise"))
					fail(Resources.getMessage("TLV_ILLEGAL_CHILD_TAG", prefix, "choose", qn));
				if (((Boolean)chooseHasOtherwise.peek()).booleanValue())
					fail(Resources.getMessage("TLV_ILLEGAL_ORDER", qn, prefix, "otherwise", "choose"));
				if (isXmlTag(ns, ln, "otherwise"))
				{
					chooseHasOtherwise.pop();
					chooseHasOtherwise.push(Boolean.TRUE);
				}
			}
			if (!transformWithSource.empty() && topDepth(transformWithSource) == depth - 1 && !isXmlTag(ns, ln, "param"))
				fail(Resources.getMessage("TLV_ILLEGAL_BODY", prefix + ":" + "transform"));
			if (isXmlTag(ns, ln, "choose"))
			{
				chooseDepths.push(new Integer(depth));
				chooseHasWhen.push(Boolean.FALSE);
				chooseHasOtherwise.push(Boolean.FALSE);
			}
			bodyIllegal = false;
			bodyNecessary = false;
			if (isXmlTag(ns, ln, "parse"))
			{
				if (hasAttribute(a, "xml"))
					bodyIllegal = true;
			} else
			if (isXmlTag(ns, ln, "param"))
			{
				if (hasAttribute(a, "value"))
					bodyIllegal = true;
				else
					bodyNecessary = true;
			} else
			if (isXmlTag(ns, ln, "transform") && hasAttribute(a, "xml"))
				transformWithSource.push(new Integer(depth));
			lastElementName = qn;
			lastElementId = a.getValue("http://java.sun.com/JSP/Page", "id");
			depth++;
		}

		public void characters(char ch[], int start, int length)
		{
			bodyNecessary = false;
			String s = (new String(ch, start, length)).trim();
			if (s.equals(""))
				return;
			if (bodyIllegal)
				fail(Resources.getMessage("TLV_ILLEGAL_BODY", lastElementName));
			if (chooseChild())
			{
				String msg = Resources.getMessage("TLV_ILLEGAL_TEXT_BODY", prefix, "choose", s.length() >= 7 ? ((Object) (s.substring(0, 7))) : ((Object) (s)));
				fail(msg);
			}
			if (!transformWithSource.empty() && topDepth(transformWithSource) == depth - 1)
				fail(Resources.getMessage("TLV_ILLEGAL_BODY", prefix + ":" + "transform"));
		}

		public void endElement(String ns, String ln, String qn)
		{
			if (qn.equals("jsp:text"))
				return;
			if (bodyNecessary)
				fail(Resources.getMessage("TLV_MISSING_BODY", lastElementName));
			bodyIllegal = false;
			if (isXmlTag(ns, ln, "choose"))
			{
				Boolean b = (Boolean)chooseHasWhen.pop();
				if (!b.booleanValue())
					fail(Resources.getMessage("TLV_PARENT_WITHOUT_SUBTAG", "choose", "when"));
				chooseDepths.pop();
				chooseHasOtherwise.pop();
			}
			if (!transformWithSource.empty() && topDepth(transformWithSource) == depth - 1)
				transformWithSource.pop();
			depth--;
		}

		private boolean chooseChild()
		{
			return !chooseDepths.empty() && depth - 1 == ((Integer)chooseDepths.peek()).intValue();
		}

		private int topDepth(Stack s)
		{
			return ((Integer)s.peek()).intValue();
		}

		private Handler()
		{
			depth = 0;
			chooseDepths = new Stack();
			chooseHasOtherwise = new Stack();
			chooseHasWhen = new Stack();
			lastElementName = null;
			bodyNecessary = false;
			bodyIllegal = false;
			transformWithSource = new Stack();
		}

	}


	private final String CHOOSE = "choose";
	private final String WHEN = "when";
	private final String OTHERWISE = "otherwise";
	private final String PARSE = "parse";
	private final String PARAM = "param";
	private final String TRANSFORM = "transform";
	private final String JSP_TEXT = "jsp:text";
	private final String VALUE = "value";
	private final String SOURCE = "xml";

	public JstlXmlTLV()
	{
	}

	public ValidationMessage[] validate(String prefix, String uri, PageData page)
	{
		return super.validate(4, prefix, uri, page);
	}

	protected DefaultHandler getHandler()
	{
		return new Handler();
	}
}
