// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   RedirectTag.java

package org.apache.taglibs.standard.tag.el.core;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.tag.common.core.RedirectSupport;

// Referenced classes of package org.apache.taglibs.standard.tag.el.core:
//			ExpressionUtil

public class RedirectTag extends RedirectSupport
{

	private String url_;
	private String context_;

	public RedirectTag()
	{
		init();
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setUrl(String url_)
	{
		this.url_ = url_;
	}

	public void setContext(String context_)
	{
		this.context_ = context_;
	}

	private void init()
	{
		url_ = context_ = null;
	}

	private void evaluateExpressions()
		throws JspException
	{
		url = (String)ExpressionUtil.evalNotNull("redirect", "url", url_, java.lang.String.class, this, pageContext);
		context = (String)ExpressionUtil.evalNotNull("redirect", "context", context_, java.lang.String.class, this, pageContext);
	}
}
