// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UpdateTag.java

package org.apache.taglibs.standard.tag.el.sql;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.tag.common.sql.UpdateTagSupport;

public class UpdateTag extends UpdateTagSupport
{

	private String dataSourceEL;
	private String sqlEL;

	public UpdateTag()
	{
	}

	public void setDataSource(String dataSourceEL)
	{
		this.dataSourceEL = dataSourceEL;
		dataSourceSpecified = true;
	}

	public void setSql(String sqlEL)
	{
		this.sqlEL = sqlEL;
	}

	public int doStartTag()
		throws JspException
	{
		if (dataSourceEL != null)
			rawDataSource = ExpressionEvaluatorManager.evaluate("dataSource", dataSourceEL, java.lang.Object.class, this, pageContext);
		if (sqlEL != null)
			sql = (String)ExpressionEvaluatorManager.evaluate("sql", sqlEL, java.lang.String.class, this, pageContext);
		return super.doStartTag();
	}
}
