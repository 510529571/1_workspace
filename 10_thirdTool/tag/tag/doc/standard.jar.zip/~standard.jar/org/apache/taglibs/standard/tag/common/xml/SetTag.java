// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SetTag.java

package org.apache.taglibs.standard.tag.common.xml;

import java.util.List;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.TagSupport;
import org.apache.taglibs.standard.tag.common.core.Util;

// Referenced classes of package org.apache.taglibs.standard.tag.common.xml:
//			XPathUtil

public class SetTag extends TagSupport
{

	private String select;
	private String var;
	private int scope;

	public SetTag()
	{
		init();
	}

	private void init()
	{
		var = null;
		select = null;
		scope = 1;
	}

	public int doStartTag()
		throws JspException
	{
		XPathUtil xu = new XPathUtil(pageContext);
		List result = xu.selectNodes(XPathUtil.getContext(this), select);
		Object ret = result;
		if (result.size() == 1)
		{
			Object o = result.get(0);
			if ((o instanceof String) || (o instanceof Boolean) || (o instanceof Number))
				ret = o;
		}
		pageContext.setAttribute(var, ret, scope);
		return 0;
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setSelect(String select)
	{
		this.select = select;
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
	}
}
