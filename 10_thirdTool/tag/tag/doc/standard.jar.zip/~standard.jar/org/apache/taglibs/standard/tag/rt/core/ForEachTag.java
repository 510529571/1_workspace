// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ForEachTag.java

package org.apache.taglibs.standard.tag.rt.core;

import java.util.ArrayList;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.jstl.core.LoopTag;
import javax.servlet.jsp.tagext.IterationTag;
import org.apache.taglibs.standard.tag.common.core.ForEachSupport;

public class ForEachTag extends ForEachSupport
	implements LoopTag, IterationTag
{

	public ForEachTag()
	{
	}

	public void setBegin(int begin)
		throws JspTagException
	{
		beginSpecified = true;
		this.begin = begin;
		validateBegin();
	}

	public void setEnd(int end)
		throws JspTagException
	{
		endSpecified = true;
		this.end = end;
		validateEnd();
	}

	public void setStep(int step)
		throws JspTagException
	{
		stepSpecified = true;
		this.step = step;
		validateStep();
	}

	public void setItems(Object o)
		throws JspTagException
	{
		if (o == null)
			rawItems = new ArrayList();
		else
			rawItems = o;
	}
}
