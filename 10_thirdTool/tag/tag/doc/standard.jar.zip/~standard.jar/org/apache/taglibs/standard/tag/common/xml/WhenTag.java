// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   WhenTag.java

package org.apache.taglibs.standard.tag.common.xml;

import javax.servlet.jsp.JspTagException;
import org.apache.taglibs.standard.tag.common.core.WhenTagSupport;

// Referenced classes of package org.apache.taglibs.standard.tag.common.xml:
//			XPathUtil

public class WhenTag extends WhenTagSupport
{

	private String select;

	public WhenTag()
	{
		init();
	}

	public void release()
	{
		super.release();
		init();
	}

	protected boolean condition()
		throws JspTagException
	{
		XPathUtil xu = new XPathUtil(pageContext);
		return xu.booleanValueOf(XPathUtil.getContext(this), select);
	}

	public void setSelect(String select)
	{
		this.select = select;
	}

	private void init()
	{
		select = null;
	}
}
