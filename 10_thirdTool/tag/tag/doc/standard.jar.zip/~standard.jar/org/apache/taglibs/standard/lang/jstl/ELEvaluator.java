// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ELEvaluator.java

package org.apache.taglibs.standard.lang.jstl;

import java.io.StringReader;
import java.text.MessageFormat;
import java.util.*;
import org.apache.taglibs.standard.lang.jstl.parser.ELParser;
import org.apache.taglibs.standard.lang.jstl.parser.ParseException;
import org.apache.taglibs.standard.lang.jstl.parser.Token;
import org.apache.taglibs.standard.lang.jstl.parser.TokenMgrError;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			ELException, Expression, ExpressionString, Logger, 
//			Constants, Coercions, VariableResolver

public class ELEvaluator
{

	static Map sCachedExpressionStrings = Collections.synchronizedMap(new HashMap());
	static Map sCachedExpectedTypes = new HashMap();
	static Logger sLogger;
	VariableResolver mResolver;
	boolean mBypassCache;

	public ELEvaluator(VariableResolver pResolver)
	{
		mResolver = pResolver;
	}

	public ELEvaluator(VariableResolver pResolver, boolean pBypassCache)
	{
		mResolver = pResolver;
		mBypassCache = pBypassCache;
	}

	public Object evaluate(String pExpressionString, Object pContext, Class pExpectedType, Map functions, String defaultPrefix)
		throws ELException
	{
		return evaluate(pExpressionString, pContext, pExpectedType, functions, defaultPrefix, sLogger);
	}

	Object evaluate(String pExpressionString, Object pContext, Class pExpectedType, Map functions, String defaultPrefix, Logger pLogger)
		throws ELException
	{
		if (pExpressionString == null)
			throw new ELException(Constants.NULL_EXPRESSION_STRING);
		Object parsedValue = parseExpressionString(pExpressionString);
		if (parsedValue instanceof String)
		{
			String strValue = (String)parsedValue;
			return convertStaticValueToExpectedType(strValue, pExpectedType, pLogger);
		}
		if (parsedValue instanceof Expression)
		{
			Object value = ((Expression)parsedValue).evaluate(pContext, mResolver, functions, defaultPrefix, pLogger);
			return convertToExpectedType(value, pExpectedType, pLogger);
		}
		if (parsedValue instanceof ExpressionString)
		{
			String strValue = ((ExpressionString)parsedValue).evaluate(pContext, mResolver, functions, defaultPrefix, pLogger);
			return convertToExpectedType(strValue, pExpectedType, pLogger);
		} else
		{
			return null;
		}
	}

	public Object parseExpressionString(String pExpressionString)
		throws ELException
	{
		if (pExpressionString.length() == 0)
			return "";
		Object ret = mBypassCache ? null : sCachedExpressionStrings.get(pExpressionString);
		if (ret == null)
		{
			java.io.Reader r = new StringReader(pExpressionString);
			ELParser parser = new ELParser(r);
			try
			{
				ret = parser.ExpressionString();
				sCachedExpressionStrings.put(pExpressionString, ret);
			}
			catch (ParseException exc)
			{
				throw new ELException(formatParseException(pExpressionString, exc));
			}
			catch (TokenMgrError exc)
			{
				throw new ELException(exc.getMessage());
			}
		}
		return ret;
	}

	Object convertToExpectedType(Object pValue, Class pExpectedType, Logger pLogger)
		throws ELException
	{
		return Coercions.coerce(pValue, pExpectedType, pLogger);
	}

	Object convertStaticValueToExpectedType(String pValue, Class pExpectedType, Logger pLogger)
		throws ELException
	{
		if (pExpectedType == (java.lang.String.class) || pExpectedType == (java.lang.Object.class))
			return pValue;
		Map valueByString = getOrCreateExpectedTypeMap(pExpectedType);
		if (!mBypassCache && valueByString.containsKey(pValue))
		{
			return valueByString.get(pValue);
		} else
		{
			Object ret = Coercions.coerce(pValue, pExpectedType, pLogger);
			valueByString.put(pValue, ret);
			return ret;
		}
	}

	static Map getOrCreateExpectedTypeMap(Class pExpectedType)
	{
		Map map = sCachedExpectedTypes;
		JVM INSTR monitorenter ;
		Map ret;
		ret = (Map)sCachedExpectedTypes.get(pExpectedType);
		if (ret == null)
		{
			ret = Collections.synchronizedMap(new HashMap());
			sCachedExpectedTypes.put(pExpectedType, ret);
		}
		return ret;
		Exception exception;
		exception;
		throw exception;
	}

	static String formatParseException(String pExpressionString, ParseException pExc)
	{
		StringBuffer expectedBuf = new StringBuffer();
		int maxSize = 0;
		boolean printedOne = false;
		if (pExc.expectedTokenSequences == null)
			return pExc.toString();
		for (int i = 0; i < pExc.expectedTokenSequences.length; i++)
		{
			if (maxSize < pExc.expectedTokenSequences[i].length)
				maxSize = pExc.expectedTokenSequences[i].length;
			for (int j = 0; j < pExc.expectedTokenSequences[i].length; j++)
			{
				if (printedOne)
					expectedBuf.append(", ");
				expectedBuf.append(pExc.tokenImage[pExc.expectedTokenSequences[i][j]]);
				printedOne = true;
			}

		}

		String expected = expectedBuf.toString();
		StringBuffer encounteredBuf = new StringBuffer();
		Token tok = pExc.currentToken.next;
		int i = 0;
		do
		{
			if (i >= maxSize)
				break;
			if (i != 0)
				encounteredBuf.append(" ");
			if (tok.kind == 0)
			{
				encounteredBuf.append(pExc.tokenImage[0]);
				break;
			}
			encounteredBuf.append(addEscapes(tok.image));
			tok = tok.next;
			i++;
		} while (true);
		String encountered = encounteredBuf.toString();
		return MessageFormat.format(Constants.PARSE_EXCEPTION, new Object[] {
			expected, encountered
		});
	}

	static String addEscapes(String str)
	{
		StringBuffer retval = new StringBuffer();
		for (int i = 0; i < str.length(); i++)
		{
			char ch;
			switch (str.charAt(i))
			{
			case 0: // '\0'
				break;

			case 8: // '\b'
				retval.append("\\b");
				break;

			case 9: // '\t'
				retval.append("\\t");
				break;

			case 10: // '\n'
				retval.append("\\n");
				break;

			case 12: // '\f'
				retval.append("\\f");
				break;

			case 13: // '\r'
				retval.append("\\r");
				break;

			case 1: // '\001'
			case 2: // '\002'
			case 3: // '\003'
			case 4: // '\004'
			case 5: // '\005'
			case 6: // '\006'
			case 7: // '\007'
			case 11: // '\013'
			default:
				if ((ch = str.charAt(i)) < ' ' || ch > '~')
				{
					String s = "0000" + Integer.toString(ch, 16);
					retval.append("\\u" + s.substring(s.length() - 4, s.length()));
				} else
				{
					retval.append(ch);
				}
				break;
			}
		}

		return retval.toString();
	}

	public String parseAndRender(String pExpressionString)
		throws ELException
	{
		Object val = parseExpressionString(pExpressionString);
		if (val instanceof String)
			return (String)val;
		if (val instanceof Expression)
			return "${" + ((Expression)val).getExpressionString() + "}";
		if (val instanceof ExpressionString)
			return ((ExpressionString)val).getExpressionString();
		else
			return "";
	}

	static 
	{
		sLogger = new Logger(System.out);
	}
}
