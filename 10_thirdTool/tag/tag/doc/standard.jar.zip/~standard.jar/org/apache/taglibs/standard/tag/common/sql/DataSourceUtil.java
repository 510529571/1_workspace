// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DataSourceUtil.java

package org.apache.taglibs.standard.tag.common.sql;

import javax.naming.*;
import javax.servlet.jsp.*;
import javax.servlet.jsp.jstl.core.Config;
import javax.sql.DataSource;
import org.apache.taglibs.standard.resources.Resources;

// Referenced classes of package org.apache.taglibs.standard.tag.common.sql:
//			DataSourceWrapper

public class DataSourceUtil
{

	private static final String ESCAPE = "\\";
	private static final String TOKEN = ",";

	public DataSourceUtil()
	{
	}

	static DataSource getDataSource(Object rawDataSource, PageContext pc)
		throws JspException
	{
		DataSource dataSource = null;
		if (rawDataSource == null)
			rawDataSource = Config.find(pc, "javax.servlet.jsp.jstl.sql.dataSource");
		if (rawDataSource == null)
			return null;
		if (rawDataSource instanceof String)
			try
			{
				Context ctx = new InitialContext();
				Context envCtx = (Context)ctx.lookup("java:comp/env");
				dataSource = (DataSource)envCtx.lookup((String)rawDataSource);
			}
			catch (NamingException ex)
			{
				dataSource = getDataSource((String)rawDataSource);
			}
		else
		if (rawDataSource instanceof DataSource)
			dataSource = (DataSource)rawDataSource;
		else
			throw new JspException(Resources.getMessage("SQL_DATASOURCE_INVALID_TYPE"));
		return dataSource;
	}

	private static DataSource getDataSource(String params)
		throws JspException
	{
		DataSourceWrapper dataSource = new DataSourceWrapper();
		String paramString[] = new String[4];
		int escCount = 0;
		int aryCount = 0;
		int begin = 0;
		for (int index = 0; index < params.length(); index++)
		{
			char nextChar = params.charAt(index);
			if (",".indexOf(nextChar) != -1 && escCount == 0)
			{
				paramString[aryCount] = params.substring(begin, index).trim();
				begin = index + 1;
				if (++aryCount > 4)
					throw new JspTagException(Resources.getMessage("JDBC_PARAM_COUNT"));
			}
			if ("\\".indexOf(nextChar) != -1)
				escCount++;
			else
				escCount = 0;
		}

		paramString[aryCount] = params.substring(begin).trim();
		dataSource.setJdbcURL(paramString[0]);
		if (paramString[1] != null)
			try
			{
				dataSource.setDriverClassName(paramString[1]);
			}
			catch (Exception ex)
			{
				throw new JspTagException(Resources.getMessage("DRIVER_INVALID_CLASS", ex.toString()), ex);
			}
		dataSource.setUserName(paramString[2]);
		dataSource.setPassword(paramString[3]);
		return dataSource;
	}
}
