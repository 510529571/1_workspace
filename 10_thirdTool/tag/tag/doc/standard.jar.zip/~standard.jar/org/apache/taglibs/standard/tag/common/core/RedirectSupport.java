// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   RedirectSupport.java

package org.apache.taglibs.standard.tag.common.core;

import java.io.IOException;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.BodyTagSupport;

// Referenced classes of package org.apache.taglibs.standard.tag.common.core:
//			ParamParent, Util, ParamSupport, UrlSupport, 
//			ImportSupport

public abstract class RedirectSupport extends BodyTagSupport
	implements ParamParent
{

	protected String url;
	protected String context;
	private String var;
	private int scope;
	private ParamSupport.ParamManager params;

	public RedirectSupport()
	{
		init();
	}

	private void init()
	{
		url = var = null;
		params = null;
		scope = 1;
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
	}

	public void addParameter(String name, String value)
	{
		params.addParameter(name, value);
	}

	public int doStartTag()
		throws JspException
	{
		params = new ParamSupport.ParamManager();
		return 2;
	}

	public int doEndTag()
		throws JspException
	{
		String baseUrl = UrlSupport.resolveUrl(url, context, pageContext);
		String result = params.aggregateParams(baseUrl);
		HttpServletResponse response = (HttpServletResponse)pageContext.getResponse();
		if (!ImportSupport.isAbsoluteUrl(result))
			result = response.encodeRedirectURL(result);
		try
		{
			response.sendRedirect(result);
		}
		catch (IOException ex)
		{
			throw new JspTagException(ex.toString(), ex);
		}
		return 5;
	}

	public void release()
	{
		init();
	}
}
