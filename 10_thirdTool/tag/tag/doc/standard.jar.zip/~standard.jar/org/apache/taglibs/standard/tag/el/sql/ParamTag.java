// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParamTag.java

package org.apache.taglibs.standard.tag.el.sql;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.tag.common.sql.ParamTagSupport;

public class ParamTag extends ParamTagSupport
{

	private String valueEL;

	public ParamTag()
	{
	}

	public void setValue(String valueEL)
	{
		this.valueEL = valueEL;
	}

	public int doStartTag()
		throws JspException
	{
		if (valueEL != null)
			value = ExpressionEvaluatorManager.evaluate("value", valueEL, java.lang.Object.class, this, pageContext);
		return super.doStartTag();
	}
}
