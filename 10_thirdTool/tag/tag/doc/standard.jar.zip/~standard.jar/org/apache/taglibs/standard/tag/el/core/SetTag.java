// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SetTag.java

package org.apache.taglibs.standard.tag.el.core;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.tag.common.core.NullAttributeException;
import org.apache.taglibs.standard.tag.common.core.SetSupport;

// Referenced classes of package org.apache.taglibs.standard.tag.el.core:
//			ExpressionUtil

public class SetTag extends SetSupport
{

	private String value_;
	private String target_;
	private String property_;

	public SetTag()
	{
		init();
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setValue(String value_)
	{
		this.value_ = value_;
		valueSpecified = true;
	}

	public void setTarget(String target_)
	{
		this.target_ = target_;
	}

	public void setProperty(String property_)
	{
		this.property_ = property_;
	}

	private void init()
	{
		value_ = target_ = property_ = null;
	}

	private void evaluateExpressions()
		throws JspException
	{
		try
		{
			value = ExpressionUtil.evalNotNull("set", "value", value_, java.lang.Object.class, this, pageContext);
		}
		catch (NullAttributeException ex)
		{
			value = null;
		}
		target = ExpressionUtil.evalNotNull("set", "target", target_, java.lang.Object.class, this, pageContext);
		try
		{
			property = (String)ExpressionUtil.evalNotNull("set", "property", property_, java.lang.String.class, this, pageContext);
		}
		catch (NullAttributeException ex)
		{
			property = null;
		}
	}
}
