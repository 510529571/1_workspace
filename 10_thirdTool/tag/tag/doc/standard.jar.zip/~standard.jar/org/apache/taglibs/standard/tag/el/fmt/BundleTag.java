// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   BundleTag.java

package org.apache.taglibs.standard.tag.el.fmt;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.tag.common.fmt.BundleSupport;

public class BundleTag extends BundleSupport
{

	private String basename_;
	private String prefix_;

	public BundleTag()
	{
		init();
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setBasename(String basename_)
	{
		this.basename_ = basename_;
	}

	public void setPrefix(String prefix_)
	{
		this.prefix_ = prefix_;
	}

	private void init()
	{
		basename_ = prefix_ = null;
	}

	private void evaluateExpressions()
		throws JspException
	{
		basename = (String)ExpressionEvaluatorManager.evaluate("basename", basename_, java.lang.String.class, this, pageContext);
		if (prefix_ != null)
			prefix = (String)ExpressionEvaluatorManager.evaluate("prefix", prefix_, java.lang.String.class, this, pageContext);
	}
}
