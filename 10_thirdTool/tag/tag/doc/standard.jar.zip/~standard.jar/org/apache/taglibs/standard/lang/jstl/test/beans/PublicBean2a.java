// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   PublicBean2a.java

package org.apache.taglibs.standard.lang.jstl.test.beans;


// Referenced classes of package org.apache.taglibs.standard.lang.jstl.test.beans:
//			PublicInterface2

public class PublicBean2a
	implements PublicInterface2
{

	public PublicBean2a()
	{
	}

	public Object getValue()
	{
		return "got the value";
	}
}
