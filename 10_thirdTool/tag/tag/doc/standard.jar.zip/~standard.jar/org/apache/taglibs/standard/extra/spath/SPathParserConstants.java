// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SPathParserConstants.java

package org.apache.taglibs.standard.extra.spath;


public interface SPathParserConstants
{

	public static final int EOF = 0;
	public static final int LITERAL = 1;
	public static final int QNAME = 2;
	public static final int NCNAME = 3;
	public static final int NSWILDCARD = 4;
	public static final int NCNAMECHAR = 5;
	public static final int LETTER = 6;
	public static final int DIGIT = 7;
	public static final int COMBINING_CHAR = 8;
	public static final int EXTENDER = 9;
	public static final int UNDERSCORE = 10;
	public static final int DOT = 11;
	public static final int DASH = 12;
	public static final int SLASH = 13;
	public static final int STAR = 14;
	public static final int COLON = 15;
	public static final int START_BRACKET = 16;
	public static final int END_BRACKET = 17;
	public static final int AT = 18;
	public static final int EQUALS = 19;
	public static final int DEFAULT = 0;
	public static final String tokenImage[] = {
		"<EOF>", "<LITERAL>", "<QNAME>", "<NCNAME>", "<NSWILDCARD>", "<NCNAMECHAR>", "<LETTER>", "<DIGIT>", "<COMBINING_CHAR>", "<EXTENDER>", 
		"\"_\"", "\".\"", "\"-\"", "\"/\"", "\"*\"", "\":\"", "\"[\"", "\"]\"", "\"@\"", "\"=\""
	};

}
