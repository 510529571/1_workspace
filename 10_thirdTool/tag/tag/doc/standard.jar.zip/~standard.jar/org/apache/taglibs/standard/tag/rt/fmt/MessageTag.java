// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MessageTag.java

package org.apache.taglibs.standard.tag.rt.fmt;

import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.jstl.fmt.LocalizationContext;
import org.apache.taglibs.standard.tag.common.fmt.MessageSupport;

public class MessageTag extends MessageSupport
{

	public MessageTag()
	{
	}

	public void setKey(String key)
		throws JspTagException
	{
		keyAttrValue = key;
		keySpecified = true;
	}

	public void setBundle(LocalizationContext locCtxt)
		throws JspTagException
	{
		bundleAttrValue = locCtxt;
		bundleSpecified = true;
	}
}
