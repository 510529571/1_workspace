// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   OutTag.java

package org.apache.taglibs.standard.tag.rt.core;

import org.apache.taglibs.standard.tag.common.core.OutSupport;

public class OutTag extends OutSupport
{

	public OutTag()
	{
	}

	public void setValue(Object value)
	{
		this.value = value;
	}

	public void setDefault(String def)
	{
		this.def = def;
	}

	public void setEscapeXml(boolean escapeXml)
	{
		this.escapeXml = escapeXml;
	}
}
