// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   AndOperator.java

package org.apache.taglibs.standard.lang.jstl;


// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			BinaryOperator, ELException, Coercions, PrimitiveObjects, 
//			Logger

public class AndOperator extends BinaryOperator
{

	public static final AndOperator SINGLETON = new AndOperator();

	public AndOperator()
	{
	}

	public String getOperatorSymbol()
	{
		return "and";
	}

	public Object apply(Object pLeft, Object pRight, Object pContext, Logger pLogger)
		throws ELException
	{
		boolean left = Coercions.coerceToBoolean(pLeft, pLogger).booleanValue();
		boolean right = Coercions.coerceToBoolean(pRight, pLogger).booleanValue();
		return PrimitiveObjects.getBoolean(left && right);
	}

	public boolean shouldEvaluate(Object pLeft)
	{
		return (pLeft instanceof Boolean) && ((Boolean)pLeft).booleanValue();
	}

	public boolean shouldCoerceToBoolean()
	{
		return true;
	}

}
