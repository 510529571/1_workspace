// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ImplicitObjects.java

package org.apache.taglibs.standard.lang.jstl;

import java.util.*;
import javax.servlet.ServletContext;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.PageContext;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			EnumeratedMap

public class ImplicitObjects
{

	static final String sAttributeName = "org.apache.taglibs.standard.ImplicitObjects";
	PageContext mContext;
	Map mPage;
	Map mRequest;
	Map mSession;
	Map mApplication;
	Map mParam;
	Map mParams;
	Map mHeader;
	Map mHeaders;
	Map mInitParam;
	Map mCookie;

	public ImplicitObjects(PageContext pContext)
	{
		mContext = pContext;
	}

	public static ImplicitObjects getImplicitObjects(PageContext pContext)
	{
		ImplicitObjects objs = (ImplicitObjects)pContext.getAttribute("org.apache.taglibs.standard.ImplicitObjects", 1);
		if (objs == null)
		{
			objs = new ImplicitObjects(pContext);
			pContext.setAttribute("org.apache.taglibs.standard.ImplicitObjects", objs, 1);
		}
		return objs;
	}

	public Map getPageScopeMap()
	{
		if (mPage == null)
			mPage = createPageScopeMap(mContext);
		return mPage;
	}

	public Map getRequestScopeMap()
	{
		if (mRequest == null)
			mRequest = createRequestScopeMap(mContext);
		return mRequest;
	}

	public Map getSessionScopeMap()
	{
		if (mSession == null)
			mSession = createSessionScopeMap(mContext);
		return mSession;
	}

	public Map getApplicationScopeMap()
	{
		if (mApplication == null)
			mApplication = createApplicationScopeMap(mContext);
		return mApplication;
	}

	public Map getParamMap()
	{
		if (mParam == null)
			mParam = createParamMap(mContext);
		return mParam;
	}

	public Map getParamsMap()
	{
		if (mParams == null)
			mParams = createParamsMap(mContext);
		return mParams;
	}

	public Map getHeaderMap()
	{
		if (mHeader == null)
			mHeader = createHeaderMap(mContext);
		return mHeader;
	}

	public Map getHeadersMap()
	{
		if (mHeaders == null)
			mHeaders = createHeadersMap(mContext);
		return mHeaders;
	}

	public Map getInitParamMap()
	{
		if (mInitParam == null)
			mInitParam = createInitParamMap(mContext);
		return mInitParam;
	}

	public Map getCookieMap()
	{
		if (mCookie == null)
			mCookie = createCookieMap(mContext);
		return mCookie;
	}

	public static Map createPageScopeMap(PageContext pContext)
	{
		final PageContext context = pContext;
		return new EnumeratedMap() {

			public Enumeration enumerateKeys()
			{
				return context.getAttributeNamesInScope(1);
			}

			public Object getValue(Object pKey)
			{
				if (pKey instanceof String)
					return context.getAttribute((String)pKey, 1);
				else
					return null;
			}

			public boolean isMutable()
			{
				return true;
			}

		};
	}

	public static Map createRequestScopeMap(PageContext pContext)
	{
		final PageContext context = pContext;
		return new EnumeratedMap() {

			public Enumeration enumerateKeys()
			{
				return context.getAttributeNamesInScope(2);
			}

			public Object getValue(Object pKey)
			{
				if (pKey instanceof String)
					return context.getAttribute((String)pKey, 2);
				else
					return null;
			}

			public boolean isMutable()
			{
				return true;
			}

		};
	}

	public static Map createSessionScopeMap(PageContext pContext)
	{
		final PageContext context = pContext;
		return new EnumeratedMap() {

			public Enumeration enumerateKeys()
			{
				return context.getAttributeNamesInScope(3);
			}

			public Object getValue(Object pKey)
			{
				if (pKey instanceof String)
					return context.getAttribute((String)pKey, 3);
				else
					return null;
			}

			public boolean isMutable()
			{
				return true;
			}

		};
	}

	public static Map createApplicationScopeMap(PageContext pContext)
	{
		final PageContext context = pContext;
		return new EnumeratedMap() {

			public Enumeration enumerateKeys()
			{
				return context.getAttributeNamesInScope(4);
			}

			public Object getValue(Object pKey)
			{
				if (pKey instanceof String)
					return context.getAttribute((String)pKey, 4);
				else
					return null;
			}

			public boolean isMutable()
			{
				return true;
			}

		};
	}

	public static Map createParamMap(PageContext pContext)
	{
		final HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
		return new EnumeratedMap() {

			public Enumeration enumerateKeys()
			{
				return request.getParameterNames();
			}

			public Object getValue(Object pKey)
			{
				if (pKey instanceof String)
					return request.getParameter((String)pKey);
				else
					return null;
			}

			public boolean isMutable()
			{
				return false;
			}

		};
	}

	public static Map createParamsMap(PageContext pContext)
	{
		final HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
		return new EnumeratedMap() {

			public Enumeration enumerateKeys()
			{
				return request.getParameterNames();
			}

			public Object getValue(Object pKey)
			{
				if (pKey instanceof String)
					return request.getParameterValues((String)pKey);
				else
					return null;
			}

			public boolean isMutable()
			{
				return false;
			}

		};
	}

	public static Map createHeaderMap(PageContext pContext)
	{
		final HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
		return new EnumeratedMap() {

			public Enumeration enumerateKeys()
			{
				return request.getHeaderNames();
			}

			public Object getValue(Object pKey)
			{
				if (pKey instanceof String)
					return request.getHeader((String)pKey);
				else
					return null;
			}

			public boolean isMutable()
			{
				return false;
			}

		};
	}

	public static Map createHeadersMap(PageContext pContext)
	{
		final HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
		return new EnumeratedMap() {

			public Enumeration enumerateKeys()
			{
				return request.getHeaderNames();
			}

			public Object getValue(Object pKey)
			{
				if (pKey instanceof String)
				{
					List l = new ArrayList();
					Enumeration enum_ = request.getHeaders((String)pKey);
					if (enum_ != null)
						for (; enum_.hasMoreElements(); l.add(enum_.nextElement()));
					String ret[] = (String[])l.toArray(new String[l.size()]);
					return ret;
				} else
				{
					return null;
				}
			}

			public boolean isMutable()
			{
				return false;
			}

		};
	}

	public static Map createInitParamMap(PageContext pContext)
	{
		final ServletContext context = pContext.getServletContext();
		return new EnumeratedMap() {

			public Enumeration enumerateKeys()
			{
				return context.getInitParameterNames();
			}

			public Object getValue(Object pKey)
			{
				if (pKey instanceof String)
					return context.getInitParameter((String)pKey);
				else
					return null;
			}

			public boolean isMutable()
			{
				return false;
			}

		};
	}

	public static Map createCookieMap(PageContext pContext)
	{
		HttpServletRequest request = (HttpServletRequest)pContext.getRequest();
		Cookie cookies[] = request.getCookies();
		Map ret = new HashMap();
		for (int i = 0; cookies != null && i < cookies.length; i++)
		{
			Cookie cookie = cookies[i];
			if (cookie == null)
				continue;
			String name = cookie.getName();
			if (!ret.containsKey(name))
				ret.put(name, cookie);
		}

		return ret;
	}
}
