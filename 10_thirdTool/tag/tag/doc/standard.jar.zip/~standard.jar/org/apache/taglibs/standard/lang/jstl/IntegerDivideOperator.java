// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   IntegerDivideOperator.java

package org.apache.taglibs.standard.lang.jstl;


// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			BinaryOperator, ELException, Logger, Constants, 
//			PrimitiveObjects, Coercions

public class IntegerDivideOperator extends BinaryOperator
{

	public static final IntegerDivideOperator SINGLETON = new IntegerDivideOperator();

	public IntegerDivideOperator()
	{
	}

	public String getOperatorSymbol()
	{
		return "idiv";
	}

	public Object apply(Object pLeft, Object pRight, Object pContext, Logger pLogger)
		throws ELException
	{
		long left;
		long right;
		if (pLeft == null && pRight == null)
		{
			if (pLogger.isLoggingWarning())
				pLogger.logWarning(Constants.ARITH_OP_NULL, getOperatorSymbol());
			return PrimitiveObjects.getInteger(0);
		}
		left = Coercions.coerceToPrimitiveNumber(pLeft, java.lang.Long.class, pLogger).longValue();
		right = Coercions.coerceToPrimitiveNumber(pRight, java.lang.Long.class, pLogger).longValue();
		return PrimitiveObjects.getLong(left / right);
		Exception exc;
		exc;
		if (pLogger.isLoggingError())
			pLogger.logError(Constants.ARITH_ERROR, getOperatorSymbol(), "" + left, "" + right);
		return PrimitiveObjects.getInteger(0);
	}

}
