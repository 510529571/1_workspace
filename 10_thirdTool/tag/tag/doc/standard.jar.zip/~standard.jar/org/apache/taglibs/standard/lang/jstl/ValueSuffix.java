// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ValueSuffix.java

package org.apache.taglibs.standard.lang.jstl;

import java.util.Map;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			ELException, VariableResolver, Logger

public abstract class ValueSuffix
{

	public ValueSuffix()
	{
	}

	public abstract String getExpressionString();

	public abstract Object evaluate(Object obj, Object obj1, VariableResolver variableresolver, Map map, String s, Logger logger)
		throws ELException;
}
