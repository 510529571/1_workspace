// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ExpressionEvaluatorManager.java

package org.apache.taglibs.standard.lang.support;

import java.util.HashMap;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;
import org.apache.taglibs.standard.lang.jstl.*;

// Referenced classes of package org.apache.taglibs.standard.lang.support:
//			ExpressionEvaluator

public class ExpressionEvaluatorManager
{

	public static final String EVALUATOR_CLASS = "org.apache.taglibs.standard.lang.jstl.Evaluator";
	private static HashMap nameMap = new HashMap();
	private static Logger logger;

	public ExpressionEvaluatorManager()
	{
	}

	public static Object evaluate(String attributeName, String expression, Class expectedType, Tag tag, PageContext pageContext)
		throws JspException
	{
		ExpressionEvaluator target = getEvaluatorByName("org.apache.taglibs.standard.lang.jstl.Evaluator");
		return target.evaluate(attributeName, expression, expectedType, tag, pageContext);
	}

	public static Object evaluate(String attributeName, String expression, Class expectedType, PageContext pageContext)
		throws JspException
	{
		ExpressionEvaluator target = getEvaluatorByName("org.apache.taglibs.standard.lang.jstl.Evaluator");
		return target.evaluate(attributeName, expression, expectedType, null, pageContext);
	}

	public static ExpressionEvaluator getEvaluatorByName(String name)
		throws JspException
	{
		Object oEvaluator;
		oEvaluator = nameMap.get(name);
		if (oEvaluator != null)
			return (ExpressionEvaluator)oEvaluator;
		HashMap hashmap = nameMap;
		JVM INSTR monitorenter ;
		oEvaluator = nameMap.get(name);
		if (oEvaluator != null)
			return (ExpressionEvaluator)oEvaluator;
		ExpressionEvaluator e;
		e = (ExpressionEvaluator)Class.forName(name).newInstance();
		nameMap.put(name, e);
		e;
		hashmap;
		JVM INSTR monitorexit ;
		return;
		Exception exception;
		exception;
		throw exception;
		ClassCastException ex;
		ex;
		throw new JspException("invalid ExpressionEvaluator: " + ex.toString(), ex);
		ex;
		throw new JspException("couldn't find ExpressionEvaluator: " + ex.toString(), ex);
		ex;
		throw new JspException("couldn't access ExpressionEvaluator: " + ex.toString(), ex);
		ex;
		throw new JspException("couldn't instantiate ExpressionEvaluator: " + ex.toString(), ex);
	}

	public static Object coerce(Object value, Class classe)
		throws JspException
	{
		return Coercions.coerce(value, classe, logger);
		ELException ex;
		ex;
		throw new JspException(ex);
	}

	static 
	{
		logger = new Logger(System.out);
	}
}
