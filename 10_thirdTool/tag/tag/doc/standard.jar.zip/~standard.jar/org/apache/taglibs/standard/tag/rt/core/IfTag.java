// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   IfTag.java

package org.apache.taglibs.standard.tag.rt.core;

import javax.servlet.jsp.jstl.core.ConditionalTagSupport;

public class IfTag extends ConditionalTagSupport
{

	private boolean test;

	public IfTag()
	{
		init();
	}

	public void release()
	{
		super.release();
		init();
	}

	protected boolean condition()
	{
		return test;
	}

	public void setTest(boolean test)
	{
		this.test = test;
	}

	private void init()
	{
		test = false;
	}
}
