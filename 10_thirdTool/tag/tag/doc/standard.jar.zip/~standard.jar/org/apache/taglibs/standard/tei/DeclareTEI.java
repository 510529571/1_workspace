// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DeclareTEI.java

package org.apache.taglibs.standard.tei;

import javax.servlet.jsp.tagext.*;

public class DeclareTEI extends TagExtraInfo
{

	public DeclareTEI()
	{
	}

	public VariableInfo[] getVariableInfo(TagData data)
	{
		VariableInfo id = new VariableInfo(data.getAttributeString("id"), data.getAttributeString("type") != null ? data.getAttributeString("type") : "java.lang.Object", true, 2);
		return (new VariableInfo[] {
			id
		});
	}
}
