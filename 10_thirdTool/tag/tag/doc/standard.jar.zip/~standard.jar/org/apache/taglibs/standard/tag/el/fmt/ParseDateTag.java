// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParseDateTag.java

package org.apache.taglibs.standard.tag.el.fmt;

import java.util.Locale;
import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.tag.common.fmt.ParseDateSupport;
import org.apache.taglibs.standard.tag.common.fmt.SetLocaleSupport;

public class ParseDateTag extends ParseDateSupport
{

	private String value_;
	private String type_;
	private String dateStyle_;
	private String timeStyle_;
	private String pattern_;
	private String timeZone_;
	private String parseLocale_;

	public ParseDateTag()
	{
		init();
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setValue(String value_)
	{
		this.value_ = value_;
		valueSpecified = true;
	}

	public void setType(String type_)
	{
		this.type_ = type_;
	}

	public void setDateStyle(String dateStyle_)
	{
		this.dateStyle_ = dateStyle_;
	}

	public void setTimeStyle(String timeStyle_)
	{
		this.timeStyle_ = timeStyle_;
	}

	public void setPattern(String pattern_)
	{
		this.pattern_ = pattern_;
	}

	public void setTimeZone(String timeZone_)
	{
		this.timeZone_ = timeZone_;
	}

	public void setParseLocale(String parseLocale_)
	{
		this.parseLocale_ = parseLocale_;
	}

	private void init()
	{
		value_ = type_ = dateStyle_ = timeStyle_ = pattern_ = timeZone_ = null;
		parseLocale_ = null;
	}

	private void evaluateExpressions()
		throws JspException
	{
		if (value_ != null)
			value = (String)ExpressionEvaluatorManager.evaluate("value", value_, java.lang.String.class, this, pageContext);
		if (type_ != null)
			type = (String)ExpressionEvaluatorManager.evaluate("type", type_, java.lang.String.class, this, pageContext);
		if (dateStyle_ != null)
			dateStyle = (String)ExpressionEvaluatorManager.evaluate("dateStyle", dateStyle_, java.lang.String.class, this, pageContext);
		if (timeStyle_ != null)
			timeStyle = (String)ExpressionEvaluatorManager.evaluate("timeStyle", timeStyle_, java.lang.String.class, this, pageContext);
		if (pattern_ != null)
			pattern = (String)ExpressionEvaluatorManager.evaluate("pattern", pattern_, java.lang.String.class, this, pageContext);
		if (timeZone_ != null)
			timeZone = ExpressionEvaluatorManager.evaluate("timeZone", timeZone_, java.lang.Object.class, this, pageContext);
		if (parseLocale_ != null)
		{
			Object obj = ExpressionEvaluatorManager.evaluate("parseLocale", parseLocale_, java.lang.Object.class, this, pageContext);
			if (obj != null)
				if (obj instanceof Locale)
				{
					parseLocale = (Locale)obj;
				} else
				{
					String localeStr = (String)obj;
					if (!"".equals(localeStr))
						parseLocale = SetLocaleSupport.parseLocale(localeStr);
				}
		}
	}
}
