// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UpdateTagSupport.java

package org.apache.taglibs.standard.tag.common.sql;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.jsp.*;
import javax.servlet.jsp.jstl.sql.SQLExecutionTag;
import javax.servlet.jsp.tagext.*;
import javax.sql.DataSource;
import org.apache.taglibs.standard.resources.Resources;
import org.apache.taglibs.standard.tag.common.core.Util;

// Referenced classes of package org.apache.taglibs.standard.tag.common.sql:
//			TransactionTagSupport, DataSourceUtil

public abstract class UpdateTagSupport extends BodyTagSupport
	implements TryCatchFinally, SQLExecutionTag
{

	private String var;
	private int scope;
	protected Object rawDataSource;
	protected boolean dataSourceSpecified;
	protected String sql;
	private Connection conn;
	private List parameters;
	private boolean isPartOfTransaction;

	public UpdateTagSupport()
	{
		init();
	}

	private void init()
	{
		rawDataSource = null;
		sql = null;
		conn = null;
		parameters = null;
		isPartOfTransaction = dataSourceSpecified = false;
		scope = 1;
		var = null;
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setScope(String scopeName)
	{
		scope = Util.getScope(scopeName);
	}

	public int doStartTag()
		throws JspException
	{
		try
		{
			conn = getConnection();
		}
		catch (SQLException e)
		{
			throw new JspException(sql + ": " + e.getMessage(), e);
		}
		return 2;
	}

	public int doEndTag()
		throws JspException
	{
		String sqlStatement = null;
		if (sql != null)
			sqlStatement = sql;
		else
		if (bodyContent != null)
			sqlStatement = bodyContent.getString();
		if (sqlStatement == null || sqlStatement.trim().length() == 0)
			throw new JspTagException(Resources.getMessage("SQL_NO_STATEMENT"));
		int result = 0;
		try
		{
			PreparedStatement ps = conn.prepareStatement(sqlStatement);
			setParameters(ps, parameters);
			result = ps.executeUpdate();
			ps.close();
		}
		catch (Throwable e)
		{
			throw new JspException(sqlStatement + ": " + e.getMessage(), e);
		}
		if (var != null)
			pageContext.setAttribute(var, new Integer(result), scope);
		return 6;
	}

	public void doCatch(Throwable t)
		throws Throwable
	{
		throw t;
	}

	public void doFinally()
	{
		if (conn != null && !isPartOfTransaction)
			try
			{
				conn.close();
			}
			catch (SQLException e) { }
		parameters = null;
		conn = null;
	}

	public void addSQLParameter(Object o)
	{
		if (parameters == null)
			parameters = new ArrayList();
		parameters.add(o);
	}

	private Connection getConnection()
		throws JspException, SQLException
	{
		Connection conn = null;
		isPartOfTransaction = false;
		TransactionTagSupport parent = (TransactionTagSupport)findAncestorWithClass(this, org.apache.taglibs.standard.tag.common.sql.TransactionTagSupport.class);
		if (parent != null)
		{
			if (dataSourceSpecified)
				throw new JspTagException(Resources.getMessage("ERROR_NESTED_DATASOURCE"));
			conn = parent.getSharedConnection();
			isPartOfTransaction = true;
		} else
		{
			if (rawDataSource == null && dataSourceSpecified)
				throw new JspException(Resources.getMessage("SQL_DATASOURCE_NULL"));
			DataSource dataSource = DataSourceUtil.getDataSource(rawDataSource, pageContext);
			try
			{
				conn = dataSource.getConnection();
			}
			catch (Exception ex)
			{
				throw new JspException(Resources.getMessage("DATASOURCE_INVALID", ex.toString()));
			}
		}
		return conn;
	}

	private void setParameters(PreparedStatement ps, List parameters)
		throws SQLException
	{
		if (parameters != null)
		{
			for (int i = 0; i < parameters.size(); i++)
				ps.setObject(i + 1, parameters.get(i));

		}
	}
}
