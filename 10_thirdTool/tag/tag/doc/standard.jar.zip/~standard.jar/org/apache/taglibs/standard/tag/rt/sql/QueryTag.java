// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   QueryTag.java

package org.apache.taglibs.standard.tag.rt.sql;

import org.apache.taglibs.standard.tag.common.sql.QueryTagSupport;

public class QueryTag extends QueryTagSupport
{

	public QueryTag()
	{
	}

	public void setDataSource(Object dataSource)
	{
		rawDataSource = dataSource;
		dataSourceSpecified = true;
	}

	public void setStartRow(int startRow)
	{
		this.startRow = startRow;
	}

	public void setMaxRows(int maxRows)
	{
		this.maxRows = maxRows;
		maxRowsSpecified = true;
	}

	public void setSql(String sql)
	{
		this.sql = sql;
	}
}
