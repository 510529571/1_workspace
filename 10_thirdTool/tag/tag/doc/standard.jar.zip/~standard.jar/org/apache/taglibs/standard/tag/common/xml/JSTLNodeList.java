// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   XPathUtil.java

package org.apache.taglibs.standard.tag.common.xml;

import java.util.Vector;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

class JSTLNodeList extends Vector
	implements NodeList
{

	Vector nodeVector;

	public JSTLNodeList(Vector nodeVector)
	{
		this.nodeVector = nodeVector;
	}

	public JSTLNodeList(NodeList nl)
	{
		nodeVector = new Vector();
		for (int i = 0; i < nl.getLength(); i++)
		{
			Node currNode = nl.item(i);
			nodeVector.add(i, nl.item(i));
		}

	}

	public JSTLNodeList(Node n)
	{
		nodeVector = new Vector();
		nodeVector.addElement(n);
	}

	public Node item(int index)
	{
		return (Node)nodeVector.elementAt(index);
	}

	public Object elementAt(int index)
	{
		return nodeVector.elementAt(index);
	}

	public Object get(int index)
	{
		return nodeVector.get(index);
	}

	public int getLength()
	{
		return nodeVector.size();
	}

	public int size()
	{
		return nodeVector.size();
	}
}
