// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   PageContextImpl.java

package org.apache.taglibs.standard.lang.jstl.test;

import java.util.*;
import javax.servlet.*;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.el.ExpressionEvaluator;
import javax.servlet.jsp.el.VariableResolver;

public class PageContextImpl extends PageContext
{

	Map mPage;
	Map mRequest;
	Map mSession;
	Map mApp;

	public PageContextImpl()
	{
		mPage = Collections.synchronizedMap(new HashMap());
		mRequest = Collections.synchronizedMap(new HashMap());
		mSession = Collections.synchronizedMap(new HashMap());
		mApp = Collections.synchronizedMap(new HashMap());
	}

	public void initialize(Servlet servlet1, ServletRequest servletrequest, ServletResponse servletresponse, String s, boolean flag, int i, boolean flag1)
	{
	}

	public void release()
	{
	}

	public void setAttribute(String name, Object attribute)
	{
		mPage.put(name, attribute);
	}

	public void setAttribute(String name, Object attribute, int scope)
	{
		switch (scope)
		{
		case 1: // '\001'
			mPage.put(name, attribute);
			break;

		case 2: // '\002'
			mRequest.put(name, attribute);
			break;

		case 3: // '\003'
			mSession.put(name, attribute);
			break;

		case 4: // '\004'
			mApp.put(name, attribute);
			break;

		default:
			throw new IllegalArgumentException("Bad scope " + scope);
		}
	}

	public Object getAttribute(String name)
	{
		return mPage.get(name);
	}

	public Object getAttribute(String name, int scope)
	{
		switch (scope)
		{
		case 1: // '\001'
			return mPage.get(name);

		case 2: // '\002'
			return mRequest.get(name);

		case 3: // '\003'
			return mSession.get(name);

		case 4: // '\004'
			return mApp.get(name);
		}
		throw new IllegalArgumentException("Bad scope " + scope);
	}

	public Object findAttribute(String name)
	{
		if (mPage.containsKey(name))
			return mPage.get(name);
		if (mRequest.containsKey(name))
			return mRequest.get(name);
		if (mSession.containsKey(name))
			return mSession.get(name);
		if (mApp.containsKey(name))
			return mApp.get(name);
		else
			return null;
	}

	public void removeAttribute(String name)
	{
		if (mPage.containsKey(name))
			mPage.remove(name);
		else
		if (mRequest.containsKey(name))
			mRequest.remove(name);
		else
		if (mSession.containsKey(name))
			mSession.remove(name);
		else
		if (mApp.containsKey(name))
			mApp.remove(name);
	}

	public void removeAttribute(String name, int scope)
	{
		switch (scope)
		{
		case 1: // '\001'
			mPage.remove(name);
			break;

		case 2: // '\002'
			mRequest.remove(name);
			break;

		case 3: // '\003'
			mSession.remove(name);
			break;

		case 4: // '\004'
			mApp.remove(name);
			break;

		default:
			throw new IllegalArgumentException("Bad scope " + scope);
		}
	}

	public int getAttributesScope(String name)
	{
		if (mPage.containsKey(name))
			return 1;
		if (mRequest.containsKey(name))
			return 2;
		if (mSession.containsKey(name))
			return 3;
		return !mApp.containsKey(name) ? 0 : 4;
	}

	public Enumeration getAttributeNamesInScope(int scope)
	{
		return null;
	}

	public JspWriter getOut()
	{
		return null;
	}

	public HttpSession getSession()
	{
		return null;
	}

	public Object getPage()
	{
		return null;
	}

	public ServletRequest getRequest()
	{
		return null;
	}

	public ServletResponse getResponse()
	{
		return null;
	}

	public Exception getException()
	{
		return null;
	}

	public ServletConfig getServletConfig()
	{
		return null;
	}

	public ServletContext getServletContext()
	{
		return null;
	}

	public void forward(String s)
	{
	}

	public void include(String s)
	{
	}

	public void handlePageException(Exception exception)
	{
	}

	public void handlePageException(Throwable throwable)
	{
	}

	public void include(String s, boolean flag)
	{
	}

	public ExpressionEvaluator getExpressionEvaluator()
	{
		return null;
	}

	public VariableResolver getVariableResolver()
	{
		return null;
	}
}
