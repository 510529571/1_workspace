// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   WhenTag.java

package org.apache.taglibs.standard.tag.rt.core;

import org.apache.taglibs.standard.tag.common.core.WhenTagSupport;

public class WhenTag extends WhenTagSupport
{

	private boolean test;

	public WhenTag()
	{
		init();
	}

	public void release()
	{
		super.release();
		init();
	}

	protected boolean condition()
	{
		return test;
	}

	public void setTest(boolean test)
	{
		this.test = test;
	}

	private void init()
	{
		test = false;
	}
}
