// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SetTag.java

package org.apache.taglibs.standard.tag.rt.core;

import org.apache.taglibs.standard.tag.common.core.SetSupport;

public class SetTag extends SetSupport
{

	public SetTag()
	{
	}

	public void setValue(Object value)
	{
		this.value = value;
		valueSpecified = true;
	}

	public void setTarget(Object target)
	{
		this.target = target;
	}

	public void setProperty(String property)
	{
		this.property = property;
	}
}
