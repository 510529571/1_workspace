// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JSTLVariableResolver.java

package org.apache.taglibs.standard.lang.jstl;

import javax.servlet.jsp.PageContext;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			VariableResolver, ELException, ImplicitObjects

public class JSTLVariableResolver
	implements VariableResolver
{

	public JSTLVariableResolver()
	{
	}

	public Object resolveVariable(String pName, Object pContext)
		throws ELException
	{
		PageContext ctx = (PageContext)pContext;
		if ("pageContext".equals(pName))
			return ctx;
		if ("pageScope".equals(pName))
			return ImplicitObjects.getImplicitObjects(ctx).getPageScopeMap();
		if ("requestScope".equals(pName))
			return ImplicitObjects.getImplicitObjects(ctx).getRequestScopeMap();
		if ("sessionScope".equals(pName))
			return ImplicitObjects.getImplicitObjects(ctx).getSessionScopeMap();
		if ("applicationScope".equals(pName))
			return ImplicitObjects.getImplicitObjects(ctx).getApplicationScopeMap();
		if ("param".equals(pName))
			return ImplicitObjects.getImplicitObjects(ctx).getParamMap();
		if ("paramValues".equals(pName))
			return ImplicitObjects.getImplicitObjects(ctx).getParamsMap();
		if ("header".equals(pName))
			return ImplicitObjects.getImplicitObjects(ctx).getHeaderMap();
		if ("headerValues".equals(pName))
			return ImplicitObjects.getImplicitObjects(ctx).getHeadersMap();
		if ("initParam".equals(pName))
			return ImplicitObjects.getImplicitObjects(ctx).getInitParamMap();
		if ("cookie".equals(pName))
			return ImplicitObjects.getImplicitObjects(ctx).getCookieMap();
		else
			return ctx.findAttribute(pName);
	}
}
