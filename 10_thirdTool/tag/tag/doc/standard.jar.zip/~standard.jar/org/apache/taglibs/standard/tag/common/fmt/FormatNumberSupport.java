// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FormatNumberSupport.java

package org.apache.taglibs.standard.tag.common.fmt;

import java.io.IOException;
import java.lang.reflect.Method;
import java.text.*;
import java.util.Locale;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import org.apache.taglibs.standard.resources.Resources;
import org.apache.taglibs.standard.tag.common.core.Util;

// Referenced classes of package org.apache.taglibs.standard.tag.common.fmt:
//			SetLocaleSupport

public abstract class FormatNumberSupport extends BodyTagSupport
{

	private static final Class GET_INSTANCE_PARAM_TYPES[];
	private static final String NUMBER = "number";
	private static final String CURRENCY = "currency";
	private static final String PERCENT = "percent";
	protected Object value;
	protected boolean valueSpecified;
	protected String type;
	protected String pattern;
	protected String currencyCode;
	protected String currencySymbol;
	protected boolean isGroupingUsed;
	protected boolean groupingUsedSpecified;
	protected int maxIntegerDigits;
	protected boolean maxIntegerDigitsSpecified;
	protected int minIntegerDigits;
	protected boolean minIntegerDigitsSpecified;
	protected int maxFractionDigits;
	protected boolean maxFractionDigitsSpecified;
	protected int minFractionDigits;
	protected boolean minFractionDigitsSpecified;
	private String var;
	private int scope;
	private static Class currencyClass;

	public FormatNumberSupport()
	{
		init();
	}

	private void init()
	{
		value = type = null;
		valueSpecified = false;
		pattern = var = currencyCode = currencySymbol = null;
		groupingUsedSpecified = false;
		maxIntegerDigitsSpecified = minIntegerDigitsSpecified = false;
		maxFractionDigitsSpecified = minFractionDigitsSpecified = false;
		scope = 1;
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
	}

	public int doEndTag()
		throws JspException
	{
		String formatted = null;
		Object input = null;
		if (valueSpecified)
			input = value;
		else
		if (bodyContent != null && bodyContent.getString() != null)
			input = bodyContent.getString().trim();
		if (input == null || input.equals(""))
		{
			if (var != null)
				pageContext.removeAttribute(var, scope);
			return 6;
		}
		if (input instanceof String)
			try
			{
				if (((String)input).indexOf('.') != -1)
					input = Double.valueOf((String)input);
				else
					input = Long.valueOf((String)input);
			}
			catch (NumberFormatException nfe)
			{
				throw new JspException(Resources.getMessage("FORMAT_NUMBER_PARSE_ERROR", input), nfe);
			}
		Locale loc = SetLocaleSupport.getFormattingLocale(pageContext, this, true, NumberFormat.getAvailableLocales());
		if (loc != null)
		{
			NumberFormat formatter = null;
			if (pattern != null && !pattern.equals(""))
			{
				DecimalFormatSymbols symbols = new DecimalFormatSymbols(loc);
				formatter = new DecimalFormat(pattern, symbols);
			} else
			{
				formatter = createFormatter(loc);
			}
			if (pattern != null && !pattern.equals("") || "currency".equalsIgnoreCase(type))
				try
				{
					setCurrency(formatter);
				}
				catch (Exception e)
				{
					throw new JspException(Resources.getMessage("FORMAT_NUMBER_CURRENCY_ERROR"), e);
				}
			configureFormatter(formatter);
			formatted = formatter.format(input);
		} else
		{
			formatted = input.toString();
		}
		if (var != null)
			pageContext.setAttribute(var, formatted, scope);
		else
			try
			{
				pageContext.getOut().print(formatted);
			}
			catch (IOException ioe)
			{
				throw new JspTagException(ioe.toString(), ioe);
			}
		return 6;
	}

	public void release()
	{
		init();
	}

	private NumberFormat createFormatter(Locale loc)
		throws JspException
	{
		NumberFormat formatter = null;
		if (type == null || "number".equalsIgnoreCase(type))
			formatter = NumberFormat.getNumberInstance(loc);
		else
		if ("currency".equalsIgnoreCase(type))
			formatter = NumberFormat.getCurrencyInstance(loc);
		else
		if ("percent".equalsIgnoreCase(type))
			formatter = NumberFormat.getPercentInstance(loc);
		else
			throw new JspException(Resources.getMessage("FORMAT_NUMBER_INVALID_TYPE", type));
		return formatter;
	}

	private void configureFormatter(NumberFormat formatter)
	{
		if (groupingUsedSpecified)
			formatter.setGroupingUsed(isGroupingUsed);
		if (maxIntegerDigitsSpecified)
			formatter.setMaximumIntegerDigits(maxIntegerDigits);
		if (minIntegerDigitsSpecified)
			formatter.setMinimumIntegerDigits(minIntegerDigits);
		if (maxFractionDigitsSpecified)
			formatter.setMaximumFractionDigits(maxFractionDigits);
		if (minFractionDigitsSpecified)
			formatter.setMinimumFractionDigits(minFractionDigits);
	}

	private void setCurrency(NumberFormat formatter)
		throws Exception
	{
		String code = null;
		String symbol = null;
		if (currencyCode == null && currencySymbol == null)
			return;
		if (currencyCode != null && currencySymbol != null)
		{
			if (currencyClass != null)
				code = currencyCode;
			else
				symbol = currencySymbol;
		} else
		if (currencyCode == null)
			symbol = currencySymbol;
		else
		if (currencyClass != null)
			code = currencyCode;
		else
			symbol = currencyCode;
		if (code != null)
		{
			Object methodArgs[] = new Object[1];
			Method m = currencyClass.getMethod("getInstance", GET_INSTANCE_PARAM_TYPES);
			methodArgs[0] = code;
			Object currency = m.invoke(null, methodArgs);
			Class paramTypes[] = new Class[1];
			paramTypes[0] = currencyClass;
			Class numberFormatClass = Class.forName("java.text.NumberFormat");
			m = numberFormatClass.getMethod("setCurrency", paramTypes);
			methodArgs[0] = currency;
			m.invoke(formatter, methodArgs);
		} else
		{
			DecimalFormat df = (DecimalFormat)formatter;
			DecimalFormatSymbols dfs = df.getDecimalFormatSymbols();
			dfs.setCurrencySymbol(symbol);
			df.setDecimalFormatSymbols(dfs);
		}
	}

	static Class class$(String x0)
	{
		return Class.forName(x0);
		ClassNotFoundException x1;
		x1;
		throw new NoClassDefFoundError(x1.getMessage());
	}

	static 
	{
		GET_INSTANCE_PARAM_TYPES = (new Class[] {
			java.lang.String.class
		});
		try
		{
			currencyClass = Class.forName("java.util.Currency");
		}
		catch (Exception cnfe) { }
	}
}
