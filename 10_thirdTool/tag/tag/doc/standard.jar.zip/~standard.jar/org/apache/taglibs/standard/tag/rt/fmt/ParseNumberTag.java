// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParseNumberTag.java

package org.apache.taglibs.standard.tag.rt.fmt;

import java.util.Locale;
import javax.servlet.jsp.JspTagException;
import org.apache.taglibs.standard.tag.common.fmt.ParseNumberSupport;
import org.apache.taglibs.standard.tag.common.fmt.SetLocaleSupport;

public class ParseNumberTag extends ParseNumberSupport
{

	public ParseNumberTag()
	{
	}

	public void setValue(String value)
		throws JspTagException
	{
		this.value = value;
		valueSpecified = true;
	}

	public void setType(String type)
		throws JspTagException
	{
		this.type = type;
	}

	public void setPattern(String pattern)
		throws JspTagException
	{
		this.pattern = pattern;
	}

	public void setParseLocale(Object loc)
		throws JspTagException
	{
		if (loc != null)
			if (loc instanceof Locale)
				parseLocale = (Locale)loc;
			else
			if (!"".equals((String)loc))
				parseLocale = SetLocaleSupport.parseLocale((String)loc);
	}

	public void setIntegerOnly(boolean isIntegerOnly)
		throws JspTagException
	{
		this.isIntegerOnly = isIntegerOnly;
		integerOnlySpecified = true;
	}
}
