// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UrlSupport.java

package org.apache.taglibs.standard.tag.common.core;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.BodyTagSupport;
import org.apache.taglibs.standard.resources.Resources;

// Referenced classes of package org.apache.taglibs.standard.tag.common.core:
//			ParamParent, Util, ParamSupport, ImportSupport

public abstract class UrlSupport extends BodyTagSupport
	implements ParamParent
{

	protected String value;
	protected String context;
	private String var;
	private int scope;
	private ParamSupport.ParamManager params;

	public UrlSupport()
	{
		init();
	}

	private void init()
	{
		value = var = null;
		params = null;
		context = null;
		scope = 1;
	}

	public void setVar(String var)
	{
		this.var = var;
	}

	public void setScope(String scope)
	{
		this.scope = Util.getScope(scope);
	}

	public void addParameter(String name, String value)
	{
		params.addParameter(name, value);
	}

	public int doStartTag()
		throws JspException
	{
		params = new ParamSupport.ParamManager();
		return 2;
	}

	public int doEndTag()
		throws JspException
	{
		String baseUrl = resolveUrl(value, context, pageContext);
		String result = params.aggregateParams(baseUrl);
		if (!ImportSupport.isAbsoluteUrl(result))
		{
			HttpServletResponse response = (HttpServletResponse)pageContext.getResponse();
			result = response.encodeURL(result);
		}
		if (var != null)
			pageContext.setAttribute(var, result, scope);
		else
			try
			{
				pageContext.getOut().print(result);
			}
			catch (IOException ex)
			{
				throw new JspTagException(ex.toString(), ex);
			}
		return 6;
	}

	public void release()
	{
		init();
	}

	public static String resolveUrl(String url, String context, PageContext pageContext)
		throws JspException
	{
		if (ImportSupport.isAbsoluteUrl(url))
			return url;
		HttpServletRequest request = (HttpServletRequest)pageContext.getRequest();
		if (context == null)
			if (url.startsWith("/"))
				return request.getContextPath() + url;
			else
				return url;
		if (!context.startsWith("/") || !url.startsWith("/"))
			throw new JspTagException(Resources.getMessage("IMPORT_BAD_RELATIVE"));
		if (context.equals("/"))
			return url;
		else
			return context + url;
	}
}
