// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ForEachTag.java

package org.apache.taglibs.standard.tag.common.xml;

import java.util.List;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.jstl.core.LoopTagSupport;
import org.apache.taglibs.standard.resources.Resources;
import org.w3c.dom.Node;

// Referenced classes of package org.apache.taglibs.standard.tag.common.xml:
//			XPathUtil

public class ForEachTag extends LoopTagSupport
{

	private String select;
	private List nodes;
	private int nodesIndex;
	private Node current;

	public ForEachTag()
	{
	}

	protected void prepare()
		throws JspTagException
	{
		nodesIndex = 0;
		XPathUtil xu = new XPathUtil(pageContext);
		nodes = xu.selectNodes(XPathUtil.getContext(this), select);
	}

	protected boolean hasNext()
		throws JspTagException
	{
		return nodesIndex < nodes.size();
	}

	protected Object next()
		throws JspTagException
	{
		Object o = nodes.get(nodesIndex++);
		if (!(o instanceof Node))
		{
			throw new JspTagException(Resources.getMessage("FOREACH_NOT_NODESET"));
		} else
		{
			current = (Node)o;
			return current;
		}
	}

	public void release()
	{
		init();
		super.release();
	}

	public void setSelect(String select)
	{
		this.select = select;
	}

	public void setBegin(int begin)
		throws JspTagException
	{
		beginSpecified = true;
		this.begin = begin;
		validateBegin();
	}

	public void setEnd(int end)
		throws JspTagException
	{
		endSpecified = true;
		this.end = end;
		validateEnd();
	}

	public void setStep(int step)
		throws JspTagException
	{
		stepSpecified = true;
		this.step = step;
		validateStep();
	}

	public Node getContext()
		throws JspTagException
	{
		return current;
	}

	private void init()
	{
		select = null;
		nodes = null;
		nodesIndex = 0;
		current = null;
	}
}
