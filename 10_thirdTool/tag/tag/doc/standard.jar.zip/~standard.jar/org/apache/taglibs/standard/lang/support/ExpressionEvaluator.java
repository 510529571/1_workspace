// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ExpressionEvaluator.java

package org.apache.taglibs.standard.lang.support;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;

public interface ExpressionEvaluator
{

	public abstract String validate(String s, String s1);

	public abstract Object evaluate(String s, String s1, Class class1, Tag tag, PageContext pagecontext)
		throws JspException;
}
