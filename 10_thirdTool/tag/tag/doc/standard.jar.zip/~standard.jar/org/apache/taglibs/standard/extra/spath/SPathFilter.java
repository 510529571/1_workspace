// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SPathFilter.java

package org.apache.taglibs.standard.extra.spath;

import java.io.IOException;
import java.io.PrintStream;
import java.util.List;
import java.util.Stack;
import org.apache.xalan.serialize.Serializer;
import org.apache.xalan.serialize.SerializerFactory;
import org.apache.xalan.templates.OutputProperties;
import org.xml.sax.*;
import org.xml.sax.helpers.XMLFilterImpl;
import org.xml.sax.helpers.XMLReaderFactory;

// Referenced classes of package org.apache.taglibs.standard.extra.spath:
//			SPathParser, Step, Predicate, AttributePredicate, 
//			ParseException, Path

public class SPathFilter extends XMLFilterImpl
{

	protected List steps;
	private int depth;
	private Stack acceptedDepths;
	private int excludedDepth;
	private static final boolean DEBUG = false;

	public static void main(String args[])
		throws ParseException, IOException, SAXException
	{
		System.setProperty("org.xml.sax.driver", "org.apache.xerces.parsers.SAXParser");
		String expr = args[0];
		SPathParser s = new SPathParser(expr);
		Path p = s.expression();
		org.xml.sax.XMLReader r = XMLReaderFactory.createXMLReader();
		XMLFilter f1 = new SPathFilter(p);
		XMLFilter f2 = new XMLFilterImpl();
		f1.setParent(r);
		f2.setParent(f1);
		Serializer sz = SerializerFactory.getSerializer(OutputProperties.getDefaultMethodProperties("xml"));
		sz.setOutputStream(System.out);
		f2.setContentHandler(sz.asContentHandler());
		f2.parse(new InputSource(System.in));
		System.out.println();
	}

	public SPathFilter(Path path)
	{
		init();
		steps = path.getSteps();
	}

	private void init()
	{
		depth = 0;
		excludedDepth = -1;
		acceptedDepths = new Stack();
	}

	public void startElement(String uri, String localName, String qName, Attributes a)
		throws SAXException
	{
		depth++;
		if (isAccepted())
		{
			getContentHandler().startElement(uri, localName, qName, a);
			return;
		}
		if (isExcluded())
			return;
		Step currentStep = (Step)steps.get(acceptedDepths.size());
		if (nodeMatchesStep(currentStep, uri, localName, qName, a))
		{
			acceptedDepths.push(new Integer(depth - 1));
			if (isAccepted())
				getContentHandler().startElement(uri, localName, qName, a);
		} else
		if (!currentStep.isDepthUnlimited())
			excludedDepth = depth - 1;
	}

	public void endElement(String uri, String localName, String qName)
		throws SAXException
	{
		depth--;
		if (isExcluded())
		{
			if (excludedDepth == depth)
				excludedDepth = -1;
			return;
		}
		if (isAccepted())
			getContentHandler().endElement(uri, localName, qName);
		if (acceptedDepths.size() > 0 && ((Integer)acceptedDepths.peek()).intValue() == depth)
			acceptedDepths.pop();
	}

	public void ignorableWhitespace(char ch[], int start, int length)
		throws SAXException
	{
		if (isAccepted())
			getContentHandler().ignorableWhitespace(ch, start, length);
	}

	public void characters(char ch[], int start, int length)
		throws SAXException
	{
		if (isAccepted())
			getContentHandler().characters(ch, start, length);
	}

	public void startPrefixMapping(String prefix, String uri)
		throws SAXException
	{
		if (isAccepted())
			getContentHandler().startPrefixMapping(prefix, uri);
	}

	public void endPrefixMapping(String prefix)
		throws SAXException
	{
		if (isAccepted())
			getContentHandler().endPrefixMapping(prefix);
	}

	public void processingInstruction(String target, String data)
		throws SAXException
	{
		if (isAccepted())
			getContentHandler().processingInstruction(target, data);
	}

	public void skippedEntity(String name)
		throws SAXException
	{
		if (isAccepted())
			getContentHandler().skippedEntity(name);
	}

	public void startDocument()
	{
		init();
	}

	public static boolean nodeMatchesStep(Step s, String uri, String localName, String qName, Attributes a)
	{
		if (!s.isMatchingName(uri, localName))
			return false;
		List l = s.getPredicates();
		for (int i = 0; l != null && i < l.size(); i++)
		{
			Predicate p = (Predicate)l.get(i);
			if (!(p instanceof AttributePredicate))
				throw new UnsupportedOperationException("only attribute predicates are supported by filter");
			if (!((AttributePredicate)p).isMatchingAttribute(a))
				return false;
		}

		return true;
	}

	private boolean isAccepted()
	{
		return acceptedDepths.size() >= steps.size();
	}

	private boolean isExcluded()
	{
		return excludedDepth != -1;
	}
}
