// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FormatNumberTag.java

package org.apache.taglibs.standard.tag.rt.fmt;

import javax.servlet.jsp.JspTagException;
import org.apache.taglibs.standard.tag.common.fmt.FormatNumberSupport;

public class FormatNumberTag extends FormatNumberSupport
{

	public FormatNumberTag()
	{
	}

	public void setValue(Object value)
		throws JspTagException
	{
		this.value = value;
		valueSpecified = true;
	}

	public void setType(String type)
		throws JspTagException
	{
		this.type = type;
	}

	public void setPattern(String pattern)
		throws JspTagException
	{
		this.pattern = pattern;
	}

	public void setCurrencyCode(String currencyCode)
		throws JspTagException
	{
		this.currencyCode = currencyCode;
	}

	public void setCurrencySymbol(String currencySymbol)
		throws JspTagException
	{
		this.currencySymbol = currencySymbol;
	}

	public void setGroupingUsed(boolean isGroupingUsed)
		throws JspTagException
	{
		this.isGroupingUsed = isGroupingUsed;
		groupingUsedSpecified = true;
	}

	public void setMaxIntegerDigits(int maxDigits)
		throws JspTagException
	{
		maxIntegerDigits = maxDigits;
		maxIntegerDigitsSpecified = true;
	}

	public void setMinIntegerDigits(int minDigits)
		throws JspTagException
	{
		minIntegerDigits = minDigits;
		minIntegerDigitsSpecified = true;
	}

	public void setMaxFractionDigits(int maxDigits)
		throws JspTagException
	{
		maxFractionDigits = maxDigits;
		maxFractionDigitsSpecified = true;
	}

	public void setMinFractionDigits(int minDigits)
		throws JspTagException
	{
		minFractionDigits = minDigits;
		minFractionDigitsSpecified = true;
	}
}
