// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   GreaterThanOperator.java

package org.apache.taglibs.standard.lang.jstl;


// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			RelationalOperator, ELException, Logger

public class GreaterThanOperator extends RelationalOperator
{

	public static final GreaterThanOperator SINGLETON = new GreaterThanOperator();

	public GreaterThanOperator()
	{
	}

	public String getOperatorSymbol()
	{
		return ">";
	}

	public Object apply(Object pLeft, Object pRight, Object pContext, Logger pLogger)
		throws ELException
	{
		if (pLeft == pRight)
			return Boolean.FALSE;
		if (pLeft == null || pRight == null)
			return Boolean.FALSE;
		else
			return super.apply(pLeft, pRight, pContext, pLogger);
	}

	public boolean apply(double pLeft, double pRight, Logger pLogger)
	{
		return pLeft > pRight;
	}

	public boolean apply(long pLeft, long pRight, Logger pLogger)
	{
		return pLeft > pRight;
	}

	public boolean apply(String pLeft, String pRight, Logger pLogger)
	{
		return pLeft.compareTo(pRight) > 0;
	}

}
