// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   EmptyOperator.java

package org.apache.taglibs.standard.lang.jstl;

import java.lang.reflect.Array;
import java.util.List;
import java.util.Map;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			UnaryOperator, ELException, PrimitiveObjects, Logger

public class EmptyOperator extends UnaryOperator
{

	public static final EmptyOperator SINGLETON = new EmptyOperator();

	public EmptyOperator()
	{
	}

	public String getOperatorSymbol()
	{
		return "empty";
	}

	public Object apply(Object pValue, Object pContext, Logger pLogger)
		throws ELException
	{
		if (pValue == null)
			return PrimitiveObjects.getBoolean(true);
		if ("".equals(pValue))
			return PrimitiveObjects.getBoolean(true);
		if (pValue.getClass().isArray() && Array.getLength(pValue) == 0)
			return PrimitiveObjects.getBoolean(true);
		if ((pValue instanceof List) && ((List)pValue).isEmpty())
			return PrimitiveObjects.getBoolean(true);
		if ((pValue instanceof Map) && ((Map)pValue).isEmpty())
			return PrimitiveObjects.getBoolean(true);
		else
			return PrimitiveObjects.getBoolean(false);
	}

}
