// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ExprTag.java

package org.apache.taglibs.standard.tag.el.xml;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.tag.common.xml.ExprSupport;
import org.apache.taglibs.standard.tag.el.core.ExpressionUtil;

public class ExprTag extends ExprSupport
{

	private String escapeXml_;

	public ExprTag()
	{
		init();
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setEscapeXml(String escapeXml_)
	{
		this.escapeXml_ = escapeXml_;
	}

	private void init()
	{
		escapeXml_ = null;
	}

	private void evaluateExpressions()
		throws JspException
	{
		if (escapeXml_ != null)
		{
			Boolean b = (Boolean)ExpressionUtil.evalNotNull("out", "escapeXml", escapeXml_, java.lang.Boolean.class, this, pageContext);
			if (b == null)
				escapeXml = false;
			else
				escapeXml = b.booleanValue();
		}
	}
}
