// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UpdateTag.java

package org.apache.taglibs.standard.tag.rt.sql;

import org.apache.taglibs.standard.tag.common.sql.UpdateTagSupport;

public class UpdateTag extends UpdateTagSupport
{

	public UpdateTag()
	{
	}

	public void setDataSource(Object dataSource)
	{
		rawDataSource = dataSource;
		dataSourceSpecified = true;
	}

	public void setSql(String sql)
	{
		this.sql = sql;
	}
}
