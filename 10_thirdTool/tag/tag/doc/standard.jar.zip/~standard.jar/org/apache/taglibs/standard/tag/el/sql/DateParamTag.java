// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   DateParamTag.java

package org.apache.taglibs.standard.tag.el.sql;

import java.util.Date;
import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.tag.common.sql.DateParamTagSupport;

public class DateParamTag extends DateParamTagSupport
{

	private String valueEL;
	private String typeEL;

	public DateParamTag()
	{
	}

	public void setValue(String valueEL)
	{
		this.valueEL = valueEL;
	}

	public void setType(String typeEL)
	{
		this.typeEL = typeEL;
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	private void evaluateExpressions()
		throws JspException
	{
		if (valueEL != null)
			value = (Date)ExpressionEvaluatorManager.evaluate("value", valueEL, java.util.Date.class, this, pageContext);
		if (typeEL != null)
			type = (String)ExpressionEvaluatorManager.evaluate("type", typeEL, java.lang.String.class, this, pageContext);
	}
}
