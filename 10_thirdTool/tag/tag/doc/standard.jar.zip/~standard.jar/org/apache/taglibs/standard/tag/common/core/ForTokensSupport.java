// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ForTokensSupport.java

package org.apache.taglibs.standard.tag.common.core;

import java.util.StringTokenizer;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.jstl.core.LoopTagSupport;

public abstract class ForTokensSupport extends LoopTagSupport
{

	protected String items;
	protected String delims;
	protected StringTokenizer st;

	public ForTokensSupport()
	{
	}

	protected void prepare()
		throws JspTagException
	{
		st = new StringTokenizer(items, delims);
	}

	protected boolean hasNext()
		throws JspTagException
	{
		return st.hasMoreElements();
	}

	protected Object next()
		throws JspTagException
	{
		return st.nextElement();
	}

	public void release()
	{
		super.release();
		items = delims = null;
		st = null;
	}
}
