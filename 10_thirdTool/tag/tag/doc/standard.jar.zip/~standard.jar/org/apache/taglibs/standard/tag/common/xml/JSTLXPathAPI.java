// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   JSTLXPathAPI.java

package org.apache.taglibs.standard.tag.common.xml;

import java.io.PrintStream;
import java.util.Vector;
import javax.servlet.jsp.JspTagException;
import javax.xml.transform.TransformerException;
import org.apache.taglibs.standard.resources.Resources;
import org.apache.xml.utils.PrefixResolver;
import org.apache.xpath.*;
import org.apache.xpath.objects.XObject;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.traversal.NodeIterator;

public class JSTLXPathAPI extends XPathAPI
{

	public JSTLXPathAPI()
	{
	}

	public static Node selectSingleNode(Node contextNode, String str, PrefixResolver prefixResolver)
		throws JspTagException
	{
		NodeIterator nl = selectNodeIterator(contextNode, str, prefixResolver);
		return nl.nextNode();
	}

	public static Node selectSingleNode(Node contextNode, String str, PrefixResolver prefixResolver, XPathContext xpathSupport)
		throws JspTagException
	{
		NodeIterator nl = selectNodeIterator(contextNode, str, prefixResolver, xpathSupport);
		return nl.nextNode();
	}

	public static NodeIterator selectNodeIterator(Node contextNode, String str, PrefixResolver prefixResolver)
		throws JspTagException
	{
		XObject list = eval(contextNode, str, prefixResolver, null);
		return getNodeIterator(list);
	}

	public static NodeIterator selectNodeIterator(Node contextNode, String str, PrefixResolver prefixResolver, XPathContext xpathSupport)
		throws JspTagException
	{
		XObject list = eval(contextNode, str, prefixResolver, xpathSupport);
		return getNodeIterator(list);
	}

	private static NodeList selectNodeList(Node contextNode, String str, PrefixResolver prefixResolver)
		throws JspTagException
	{
		XObject list = eval(contextNode, str, prefixResolver, null);
		return getNodeList(list);
	}

	public static NodeList selectNodeList(Node contextNode, String str, PrefixResolver prefixResolver, XPathContext xpathSupport)
		throws JspTagException
	{
		XObject list = eval(contextNode, str, prefixResolver, xpathSupport);
		return getNodeList(list);
	}

	private static NodeIterator getNodeIterator(XObject list)
		throws JspTagException
	{
		return list.nodeset();
		TransformerException ex;
		ex;
		throw new JspTagException(Resources.getMessage("XPATH_ERROR_XOBJECT", ex.toString()), ex);
	}

	static NodeList getNodeList(XObject list)
		throws JspTagException
	{
		return list.nodelist();
		TransformerException ex;
		ex;
		throw new JspTagException(Resources.getMessage("XPATH_ERROR_XOBJECT", ex.toString()), ex);
	}

	public static XObject eval(Node contextNode, String str, PrefixResolver prefixResolver, XPathContext xpathSupport)
		throws JspTagException
	{
		if (xpathSupport == null)
			return eval(contextNode, str, prefixResolver);
		XObject xobj;
		XPath xpath = new XPath(str, null, prefixResolver, 0, null);
		int ctxtNode = xpathSupport.getDTMHandleFromNode(contextNode);
		xobj = xpath.execute(xpathSupport, ctxtNode, prefixResolver);
		return xobj;
		TransformerException ex;
		ex;
		throw new JspTagException(Resources.getMessage("XPATH_ERROR_EVALUATING_EXPR", str, ex.toString()), ex);
		ex;
		throw new JspTagException(Resources.getMessage("XPATH_ILLEGAL_ARG_EVALUATING_EXPR", str, ex.toString()), ex);
	}

	public static XObject eval(Node contextNode, String str, PrefixResolver prefixResolver, XPathContext xpathSupport, Vector varQNames)
		throws JspTagException
	{
		XPath xpath;
		int ctxtNode;
		xpath = new XPath(str, null, prefixResolver, 0, null);
		xpath.fixupVariables(varQNames, varQNames.size());
		ctxtNode = xpathSupport.getDTMHandleFromNode(contextNode);
		return xpath.execute(xpathSupport, ctxtNode, prefixResolver);
		TransformerException ex;
		ex;
		throw new JspTagException(Resources.getMessage("XPATH_ERROR_EVALUATING_EXPR", str, ex.toString()), ex);
		ex;
		throw new JspTagException(Resources.getMessage("XPATH_ILLEGAL_ARG_EVALUATING_EXPR", str, ex.toString()), ex);
	}

	private static void p(String s)
	{
		System.out.println("[JSTLXPathAPI] " + s);
	}
}
