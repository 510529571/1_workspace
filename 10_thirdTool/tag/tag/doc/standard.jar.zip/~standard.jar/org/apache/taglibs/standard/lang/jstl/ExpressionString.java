// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ExpressionString.java

package org.apache.taglibs.standard.lang.jstl;

import java.util.Map;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			Expression, ELException, VariableResolver, Logger

public class ExpressionString
{

	Object mElements[];

	public Object[] getElements()
	{
		return mElements;
	}

	public void setElements(Object pElements[])
	{
		mElements = pElements;
	}

	public ExpressionString(Object pElements[])
	{
		mElements = pElements;
	}

	public String evaluate(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger)
		throws ELException
	{
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < mElements.length; i++)
		{
			Object elem = mElements[i];
			if (elem instanceof String)
			{
				buf.append((String)elem);
				continue;
			}
			if (!(elem instanceof Expression))
				continue;
			Object val = ((Expression)elem).evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
			if (val != null)
				buf.append(val.toString());
		}

		return buf.toString();
	}

	public String getExpressionString()
	{
		StringBuffer buf = new StringBuffer();
		for (int i = 0; i < mElements.length; i++)
		{
			Object elem = mElements[i];
			if (elem instanceof String)
			{
				buf.append((String)elem);
				continue;
			}
			if (elem instanceof Expression)
			{
				buf.append("${");
				buf.append(((Expression)elem).getExpressionString());
				buf.append("}");
			}
		}

		return buf.toString();
	}
}
