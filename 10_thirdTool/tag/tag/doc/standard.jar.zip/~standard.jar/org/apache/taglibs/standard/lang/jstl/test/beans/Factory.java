// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   Factory.java

package org.apache.taglibs.standard.lang.jstl.test.beans;


// Referenced classes of package org.apache.taglibs.standard.lang.jstl.test.beans:
//			PublicBean1, PrivateBean1a, PublicBean1b, PublicBean2a, 
//			PrivateBean2b, PrivateBean2c, PrivateBean2d, PublicInterface2

public class Factory
{

	public Factory()
	{
	}

	public static PublicBean1 createBean1()
	{
		return new PublicBean1();
	}

	public static PublicBean1 createBean2()
	{
		return new PrivateBean1a();
	}

	public static PublicBean1 createBean3()
	{
		return new PublicBean1b();
	}

	public static PublicInterface2 createBean4()
	{
		return new PublicBean2a();
	}

	public static PublicInterface2 createBean5()
	{
		return new PrivateBean2b();
	}

	public static PublicInterface2 createBean6()
	{
		return new PrivateBean2c();
	}

	public static PublicInterface2 createBean7()
	{
		return new PrivateBean2d();
	}
}
