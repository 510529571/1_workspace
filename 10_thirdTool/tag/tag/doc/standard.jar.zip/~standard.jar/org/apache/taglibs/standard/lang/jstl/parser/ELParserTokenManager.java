// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ELParserTokenManager.java

package org.apache.taglibs.standard.lang.jstl.parser;

import java.io.IOException;
import java.io.PrintStream;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl.parser:
//			TokenMgrError, ELParserConstants, SimpleCharStream, Token

public class ELParserTokenManager
	implements ELParserConstants
{

	public PrintStream debugStream;
	static final long jjbitVec0[] = {
		-2L, -1L, -1L, -1L
	};
	static final long jjbitVec2[] = {
		0L, 0L, -1L, -1L
	};
	static final long jjbitVec3[] = {
		0x1ff00000fffffffeL, -16384L, 0xffffffffL, 0x600000000000000L
	};
	static final long jjbitVec4[] = {
		0L, 0L, 0L, 0xff7fffffff7fffffL
	};
	static final long jjbitVec5[] = {
		0L, -1L, -1L, -1L
	};
	static final long jjbitVec6[] = {
		-1L, -1L, 65535L, 0L
	};
	static final long jjbitVec7[] = {
		-1L, -1L, 0L, 0L
	};
	static final long jjbitVec8[] = {
		0x3fffffffffffL, 0L, 0L, 0L
	};
	static final int jjnextStates[] = {
		8, 9, 10, 15, 16, 28, 29, 31, 32, 33, 
		20, 21, 23, 24, 25, 20, 21, 23, 28, 29, 
		31, 3, 4, 13, 14, 17, 18, 24, 25, 32, 
		33
	};
	public static final String jjstrLiteralImages[] = {
		"", null, "${", null, null, null, null, null, null, null, 
		null, null, "true", "false", "null", "}", ".", ">", "gt", "<", 
		"lt", "==", "eq", "<=", "le", ">=", "ge", "!=", "ne", "(", 
		")", ",", ":", "[", "]", "+", "-", "*", "/", "div", 
		"%", "mod", "not", "!", "and", "&&", "or", "||", "empty", null, 
		null, null, null, null
	};
	public static final String lexStateNames[] = {
		"DEFAULT", "IN_EXPRESSION"
	};
	public static final int jjnewLexState[] = {
		-1, -1, 1, -1, -1, -1, -1, -1, -1, -1, 
		-1, -1, -1, -1, -1, 0, -1, -1, -1, -1, 
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
		-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
		-1, -1, -1, -1
	};
	static final long jjtoToken[] = {
		0x23fffffffffd87L
	};
	static final long jjtoSkip[] = {
		120L
	};
	private SimpleCharStream input_stream;
	private final int jjrounds[];
	private final int jjstateSet[];
	protected char curChar;
	int curLexState;
	int defaultLexState;
	int jjnewStateCnt;
	int jjround;
	int jjmatchedPos;
	int jjmatchedKind;

	public void setDebugStream(PrintStream ds)
	{
		debugStream = ds;
	}

	private final int jjStopStringLiteralDfa_0(int pos, long active0)
	{
		switch (pos)
		{
		case 0: // '\0'
			if ((active0 & 4L) != 0L)
			{
				jjmatchedKind = 1;
				return 2;
			} else
			{
				return -1;
			}
		}
		return -1;
	}

	private final int jjStartNfa_0(int pos, long active0)
	{
		return jjMoveNfa_0(jjStopStringLiteralDfa_0(pos, active0), pos + 1);
	}

	private final int jjStopAtPos(int pos, int kind)
	{
		jjmatchedKind = kind;
		jjmatchedPos = pos;
		return pos + 1;
	}

	private final int jjStartNfaWithStates_0(int pos, int kind, int state)
	{
		jjmatchedKind = kind;
		jjmatchedPos = pos;
		try
		{
			curChar = input_stream.readChar();
		}
		catch (IOException e)
		{
			return pos + 1;
		}
		return jjMoveNfa_0(state, pos + 1);
	}

	private final int jjMoveStringLiteralDfa0_0()
	{
		switch (curChar)
		{
		case 36: // '$'
			return jjMoveStringLiteralDfa1_0(4L);
		}
		return jjMoveNfa_0(1, 0);
	}

	private final int jjMoveStringLiteralDfa1_0(long active0)
	{
		try
		{
			curChar = input_stream.readChar();
		}
		catch (IOException e)
		{
			jjStopStringLiteralDfa_0(0, active0);
			return 1;
		}
		switch (curChar)
		{
		case 123: // '{'
			if ((active0 & 4L) != 0L)
				return jjStopAtPos(1, 2);
			break;
		}
		return jjStartNfa_0(0, active0);
	}

	private final void jjCheckNAdd(int state)
	{
		if (jjrounds[state] != jjround)
		{
			jjstateSet[jjnewStateCnt++] = state;
			jjrounds[state] = jjround;
		}
	}

	private final void jjAddStates(int start, int end)
	{
		do
			jjstateSet[jjnewStateCnt++] = jjnextStates[start];
		while (start++ != end);
	}

	private final void jjCheckNAddTwoStates(int state1, int state2)
	{
		jjCheckNAdd(state1);
		jjCheckNAdd(state2);
	}

	private final void jjCheckNAddStates(int start, int end)
	{
		do
			jjCheckNAdd(jjnextStates[start]);
		while (start++ != end);
	}

	private final void jjCheckNAddStates(int start)
	{
		jjCheckNAdd(jjnextStates[start]);
		jjCheckNAdd(jjnextStates[start + 1]);
	}

	private final int jjMoveNfa_0(int startState, int curPos)
	{
		int startsAt = 0;
		jjnewStateCnt = 3;
		int i = 1;
		jjstateSet[0] = startState;
		int kind = 0x7fffffff;
		do
		{
			if (++jjround == 0x7fffffff)
				ReInitRounds();
			if (curChar < '@')
			{
				long l = 1L << curChar;
				do
					switch (jjstateSet[--i])
					{
					case 1: // '\001'
						if ((0xffffffefffffffffL & l) != 0L)
						{
							if (kind > 1)
								kind = 1;
							jjCheckNAdd(0);
						} else
						if (curChar == '$')
						{
							if (kind > 1)
								kind = 1;
							jjCheckNAdd(2);
						}
						break;

					case 0: // '\0'
						if ((0xffffffefffffffffL & l) != 0L)
						{
							if (kind > 1)
								kind = 1;
							jjCheckNAdd(0);
						}
						break;

					case 2: // '\002'
						if ((0xffffffefffffffffL & l) != 0L)
						{
							if (kind > 1)
								kind = 1;
							jjCheckNAdd(2);
						}
						break;
					}
				while (i != startsAt);
			} else
			if (curChar < '\200')
			{
				long l = 1L << (curChar & 0x3f);
				do
					switch (jjstateSet[--i])
					{
					case 0: // '\0'
					case 1: // '\001'
						if (kind > 1)
							kind = 1;
						jjCheckNAdd(0);
						break;

					case 2: // '\002'
						if ((0xf7ffffffffffffffL & l) != 0L)
						{
							if (kind > 1)
								kind = 1;
							jjstateSet[jjnewStateCnt++] = 2;
						}
						break;
					}
				while (i != startsAt);
			} else
			{
				int hiByte = curChar >> 8;
				int i1 = hiByte >> 6;
				long l1 = 1L << (hiByte & 0x3f);
				int i2 = (curChar & 0xff) >> 6;
				long l2 = 1L << (curChar & 0x3f);
				do
					switch (jjstateSet[--i])
					{
					case 0: // '\0'
					case 1: // '\001'
						if (jjCanMove_0(hiByte, i1, i2, l1, l2))
						{
							if (kind > 1)
								kind = 1;
							jjCheckNAdd(0);
						}
						break;

					case 2: // '\002'
						if (jjCanMove_0(hiByte, i1, i2, l1, l2))
						{
							if (kind > 1)
								kind = 1;
							jjstateSet[jjnewStateCnt++] = 2;
						}
						break;
					}
				while (i != startsAt);
			}
			if (kind != 0x7fffffff)
			{
				jjmatchedKind = kind;
				jjmatchedPos = curPos;
				kind = 0x7fffffff;
			}
			curPos++;
			if ((i = jjnewStateCnt) == (startsAt = 3 - (jjnewStateCnt = startsAt)))
				return curPos;
			try
			{
				curChar = input_stream.readChar();
			}
			catch (IOException e)
			{
				return curPos;
			}
		} while (true);
	}

	private final int jjStopStringLiteralDfa_1(int pos, long active0)
	{
		switch (pos)
		{
		case 0: // '\0'
			if ((active0 & 0x1568015547000L) != 0L)
			{
				jjmatchedKind = 49;
				return 6;
			}
			return (active0 & 0x10000L) == 0L ? -1 : 1;

		case 1: // '\001'
			if ((active0 & 0x400015540000L) != 0L)
				return 6;
			if ((active0 & 0x1168000007000L) != 0L)
			{
				jjmatchedKind = 49;
				jjmatchedPos = 1;
				return 6;
			} else
			{
				return -1;
			}

		case 2: // '\002'
			if ((active0 & 0x168000000000L) != 0L)
				return 6;
			if ((active0 & 0x1000000007000L) != 0L)
			{
				jjmatchedKind = 49;
				jjmatchedPos = 2;
				return 6;
			} else
			{
				return -1;
			}

		case 3: // '\003'
			if ((active0 & 20480L) != 0L)
				return 6;
			if ((active0 & 0x1000000002000L) != 0L)
			{
				jjmatchedKind = 49;
				jjmatchedPos = 3;
				return 6;
			} else
			{
				return -1;
			}
		}
		return -1;
	}

	private final int jjStartNfa_1(int pos, long active0)
	{
		return jjMoveNfa_1(jjStopStringLiteralDfa_1(pos, active0), pos + 1);
	}

	private final int jjStartNfaWithStates_1(int pos, int kind, int state)
	{
		jjmatchedKind = kind;
		jjmatchedPos = pos;
		try
		{
			curChar = input_stream.readChar();
		}
		catch (IOException e)
		{
			return pos + 1;
		}
		return jjMoveNfa_1(state, pos + 1);
	}

	private final int jjMoveStringLiteralDfa0_1()
	{
		switch (curChar)
		{
		case 33: // '!'
			jjmatchedKind = 43;
			return jjMoveStringLiteralDfa1_1(0x8000000L);

		case 37: // '%'
			return jjStopAtPos(0, 40);

		case 38: // '&'
			return jjMoveStringLiteralDfa1_1(0x200000000000L);

		case 40: // '('
			return jjStopAtPos(0, 29);

		case 41: // ')'
			return jjStopAtPos(0, 30);

		case 42: // '*'
			return jjStopAtPos(0, 37);

		case 43: // '+'
			return jjStopAtPos(0, 35);

		case 44: // ','
			return jjStopAtPos(0, 31);

		case 45: // '-'
			return jjStopAtPos(0, 36);

		case 46: // '.'
			return jjStartNfaWithStates_1(0, 16, 1);

		case 47: // '/'
			return jjStopAtPos(0, 38);

		case 58: // ':'
			return jjStopAtPos(0, 32);

		case 60: // '<'
			jjmatchedKind = 19;
			return jjMoveStringLiteralDfa1_1(0x800000L);

		case 61: // '='
			return jjMoveStringLiteralDfa1_1(0x200000L);

		case 62: // '>'
			jjmatchedKind = 17;
			return jjMoveStringLiteralDfa1_1(0x2000000L);

		case 91: // '['
			return jjStopAtPos(0, 33);

		case 93: // ']'
			return jjStopAtPos(0, 34);

		case 97: // 'a'
			return jjMoveStringLiteralDfa1_1(0x100000000000L);

		case 100: // 'd'
			return jjMoveStringLiteralDfa1_1(0x8000000000L);

		case 101: // 'e'
			return jjMoveStringLiteralDfa1_1(0x1000000400000L);

		case 102: // 'f'
			return jjMoveStringLiteralDfa1_1(8192L);

		case 103: // 'g'
			return jjMoveStringLiteralDfa1_1(0x4040000L);

		case 108: // 'l'
			return jjMoveStringLiteralDfa1_1(0x1100000L);

		case 109: // 'm'
			return jjMoveStringLiteralDfa1_1(0x20000000000L);

		case 110: // 'n'
			return jjMoveStringLiteralDfa1_1(0x40010004000L);

		case 111: // 'o'
			return jjMoveStringLiteralDfa1_1(0x400000000000L);

		case 116: // 't'
			return jjMoveStringLiteralDfa1_1(4096L);

		case 124: // '|'
			return jjMoveStringLiteralDfa1_1(0x800000000000L);

		case 125: // '}'
			return jjStopAtPos(0, 15);

		case 34: // '"'
		case 35: // '#'
		case 36: // '$'
		case 39: // '\''
		case 48: // '0'
		case 49: // '1'
		case 50: // '2'
		case 51: // '3'
		case 52: // '4'
		case 53: // '5'
		case 54: // '6'
		case 55: // '7'
		case 56: // '8'
		case 57: // '9'
		case 59: // ';'
		case 63: // '?'
		case 64: // '@'
		case 65: // 'A'
		case 66: // 'B'
		case 67: // 'C'
		case 68: // 'D'
		case 69: // 'E'
		case 70: // 'F'
		case 71: // 'G'
		case 72: // 'H'
		case 73: // 'I'
		case 74: // 'J'
		case 75: // 'K'
		case 76: // 'L'
		case 77: // 'M'
		case 78: // 'N'
		case 79: // 'O'
		case 80: // 'P'
		case 81: // 'Q'
		case 82: // 'R'
		case 83: // 'S'
		case 84: // 'T'
		case 85: // 'U'
		case 86: // 'V'
		case 87: // 'W'
		case 88: // 'X'
		case 89: // 'Y'
		case 90: // 'Z'
		case 92: // '\\'
		case 94: // '^'
		case 95: // '_'
		case 96: // '`'
		case 98: // 'b'
		case 99: // 'c'
		case 104: // 'h'
		case 105: // 'i'
		case 106: // 'j'
		case 107: // 'k'
		case 112: // 'p'
		case 113: // 'q'
		case 114: // 'r'
		case 115: // 's'
		case 117: // 'u'
		case 118: // 'v'
		case 119: // 'w'
		case 120: // 'x'
		case 121: // 'y'
		case 122: // 'z'
		case 123: // '{'
		default:
			return jjMoveNfa_1(0, 0);
		}
	}

	private final int jjMoveStringLiteralDfa1_1(long active0)
	{
		try
		{
			curChar = input_stream.readChar();
		}
		catch (IOException e)
		{
			jjStopStringLiteralDfa_1(0, active0);
			return 1;
		}
		switch (curChar)
		{
		default:
			break;

		case 38: // '&'
			if ((active0 & 0x200000000000L) != 0L)
				return jjStopAtPos(1, 45);
			break;

		case 61: // '='
			if ((active0 & 0x200000L) != 0L)
				return jjStopAtPos(1, 21);
			if ((active0 & 0x800000L) != 0L)
				return jjStopAtPos(1, 23);
			if ((active0 & 0x2000000L) != 0L)
				return jjStopAtPos(1, 25);
			if ((active0 & 0x8000000L) != 0L)
				return jjStopAtPos(1, 27);
			break;

		case 97: // 'a'
			return jjMoveStringLiteralDfa2_1(active0, 8192L);

		case 101: // 'e'
			if ((active0 & 0x1000000L) != 0L)
				return jjStartNfaWithStates_1(1, 24, 6);
			if ((active0 & 0x4000000L) != 0L)
				return jjStartNfaWithStates_1(1, 26, 6);
			if ((active0 & 0x10000000L) != 0L)
				return jjStartNfaWithStates_1(1, 28, 6);
			break;

		case 105: // 'i'
			return jjMoveStringLiteralDfa2_1(active0, 0x8000000000L);

		case 109: // 'm'
			return jjMoveStringLiteralDfa2_1(active0, 0x1000000000000L);

		case 110: // 'n'
			return jjMoveStringLiteralDfa2_1(active0, 0x100000000000L);

		case 111: // 'o'
			return jjMoveStringLiteralDfa2_1(active0, 0x60000000000L);

		case 113: // 'q'
			if ((active0 & 0x400000L) != 0L)
				return jjStartNfaWithStates_1(1, 22, 6);
			break;

		case 114: // 'r'
			if ((active0 & 0x400000000000L) != 0L)
				return jjStartNfaWithStates_1(1, 46, 6);
			else
				return jjMoveStringLiteralDfa2_1(active0, 4096L);

		case 116: // 't'
			if ((active0 & 0x40000L) != 0L)
				return jjStartNfaWithStates_1(1, 18, 6);
			if ((active0 & 0x100000L) != 0L)
				return jjStartNfaWithStates_1(1, 20, 6);
			break;

		case 117: // 'u'
			return jjMoveStringLiteralDfa2_1(active0, 16384L);

		case 124: // '|'
			if ((active0 & 0x800000000000L) != 0L)
				return jjStopAtPos(1, 47);
			break;
		}
		return jjStartNfa_1(0, active0);
	}

	private final int jjMoveStringLiteralDfa2_1(long old0, long active0)
	{
		if ((active0 &= old0) == 0L)
			return jjStartNfa_1(0, old0);
		try
		{
			curChar = input_stream.readChar();
		}
		catch (IOException e)
		{
			jjStopStringLiteralDfa_1(1, active0);
			return 2;
		}
		switch (curChar)
		{
		case 101: // 'e'
		case 102: // 'f'
		case 103: // 'g'
		case 104: // 'h'
		case 105: // 'i'
		case 106: // 'j'
		case 107: // 'k'
		case 109: // 'm'
		case 110: // 'n'
		case 111: // 'o'
		case 113: // 'q'
		case 114: // 'r'
		case 115: // 's'
		default:
			break;

		case 100: // 'd'
			if ((active0 & 0x20000000000L) != 0L)
				return jjStartNfaWithStates_1(2, 41, 6);
			if ((active0 & 0x100000000000L) != 0L)
				return jjStartNfaWithStates_1(2, 44, 6);
			break;

		case 108: // 'l'
			return jjMoveStringLiteralDfa3_1(active0, 24576L);

		case 112: // 'p'
			return jjMoveStringLiteralDfa3_1(active0, 0x1000000000000L);

		case 116: // 't'
			if ((active0 & 0x40000000000L) != 0L)
				return jjStartNfaWithStates_1(2, 42, 6);
			break;

		case 117: // 'u'
			return jjMoveStringLiteralDfa3_1(active0, 4096L);

		case 118: // 'v'
			if ((active0 & 0x8000000000L) != 0L)
				return jjStartNfaWithStates_1(2, 39, 6);
			break;
		}
		return jjStartNfa_1(1, active0);
	}

	private final int jjMoveStringLiteralDfa3_1(long old0, long active0)
	{
		if ((active0 &= old0) == 0L)
			return jjStartNfa_1(1, old0);
		try
		{
			curChar = input_stream.readChar();
		}
		catch (IOException e)
		{
			jjStopStringLiteralDfa_1(2, active0);
			return 3;
		}
		switch (curChar)
		{
		default:
			break;

		case 101: // 'e'
			if ((active0 & 4096L) != 0L)
				return jjStartNfaWithStates_1(3, 12, 6);
			break;

		case 108: // 'l'
			if ((active0 & 16384L) != 0L)
				return jjStartNfaWithStates_1(3, 14, 6);
			break;

		case 115: // 's'
			return jjMoveStringLiteralDfa4_1(active0, 8192L);

		case 116: // 't'
			return jjMoveStringLiteralDfa4_1(active0, 0x1000000000000L);
		}
		return jjStartNfa_1(2, active0);
	}

	private final int jjMoveStringLiteralDfa4_1(long old0, long active0)
	{
		if ((active0 &= old0) == 0L)
			return jjStartNfa_1(2, old0);
		try
		{
			curChar = input_stream.readChar();
		}
		catch (IOException e)
		{
			jjStopStringLiteralDfa_1(3, active0);
			return 4;
		}
		switch (curChar)
		{
		default:
			break;

		case 101: // 'e'
			if ((active0 & 8192L) != 0L)
				return jjStartNfaWithStates_1(4, 13, 6);
			break;

		case 121: // 'y'
			if ((active0 & 0x1000000000000L) != 0L)
				return jjStartNfaWithStates_1(4, 48, 6);
			break;
		}
		return jjStartNfa_1(3, active0);
	}

	private final int jjMoveNfa_1(int startState, int curPos)
	{
		int startsAt = 0;
		jjnewStateCnt = 35;
		int i = 1;
		jjstateSet[0] = startState;
		int kind = 0x7fffffff;
		do
		{
			if (++jjround == 0x7fffffff)
				ReInitRounds();
			if (curChar < '@')
			{
				long l = 1L << curChar;
				do
					switch (jjstateSet[--i])
					{
					case 0: // '\0'
						if ((0x3ff000000000000L & l) != 0L)
						{
							if (kind > 7)
								kind = 7;
							jjCheckNAddStates(0, 4);
						} else
						if ((0x1800000000L & l) != 0L)
						{
							if (kind > 49)
								kind = 49;
							jjCheckNAdd(6);
						} else
						if (curChar == '\'')
							jjCheckNAddStates(5, 9);
						else
						if (curChar == '"')
							jjCheckNAddStates(10, 14);
						else
						if (curChar == '.')
							jjCheckNAdd(1);
						break;

					case 1: // '\001'
						if ((0x3ff000000000000L & l) != 0L)
						{
							if (kind > 8)
								kind = 8;
							jjCheckNAddTwoStates(1, 2);
						}
						break;

					case 3: // '\003'
						if ((0x280000000000L & l) != 0L)
							jjCheckNAdd(4);
						break;

					case 4: // '\004'
						if ((0x3ff000000000000L & l) != 0L)
						{
							if (kind > 8)
								kind = 8;
							jjCheckNAdd(4);
						}
						break;

					case 5: // '\005'
						if ((0x1800000000L & l) != 0L)
						{
							if (kind > 49)
								kind = 49;
							jjCheckNAdd(6);
						}
						break;

					case 6: // '\006'
						if ((0x3ff001000000000L & l) != 0L)
						{
							if (kind > 49)
								kind = 49;
							jjCheckNAdd(6);
						}
						break;

					case 7: // '\007'
						if ((0x3ff000000000000L & l) != 0L)
						{
							if (kind > 7)
								kind = 7;
							jjCheckNAddStates(0, 4);
						}
						break;

					case 8: // '\b'
						if ((0x3ff000000000000L & l) != 0L)
						{
							if (kind > 7)
								kind = 7;
							jjCheckNAdd(8);
						}
						break;

					case 9: // '\t'
						if ((0x3ff000000000000L & l) != 0L)
							jjCheckNAddTwoStates(9, 10);
						break;

					case 10: // '\n'
						if (curChar == '.')
						{
							if (kind > 8)
								kind = 8;
							jjCheckNAddTwoStates(11, 12);
						}
						break;

					case 11: // '\013'
						if ((0x3ff000000000000L & l) != 0L)
						{
							if (kind > 8)
								kind = 8;
							jjCheckNAddTwoStates(11, 12);
						}
						break;

					case 13: // '\r'
						if ((0x280000000000L & l) != 0L)
							jjCheckNAdd(14);
						break;

					case 14: // '\016'
						if ((0x3ff000000000000L & l) != 0L)
						{
							if (kind > 8)
								kind = 8;
							jjCheckNAdd(14);
						}
						break;

					case 15: // '\017'
						if ((0x3ff000000000000L & l) != 0L)
							jjCheckNAddTwoStates(15, 16);
						break;

					case 17: // '\021'
						if ((0x280000000000L & l) != 0L)
							jjCheckNAdd(18);
						break;

					case 18: // '\022'
						if ((0x3ff000000000000L & l) != 0L)
						{
							if (kind > 8)
								kind = 8;
							jjCheckNAdd(18);
						}
						break;

					case 19: // '\023'
						if (curChar == '"')
							jjCheckNAddStates(10, 14);
						break;

					case 20: // '\024'
						if ((0xfffffffbffffffffL & l) != 0L)
							jjCheckNAddStates(15, 17);
						break;

					case 22: // '\026'
						if (curChar == '"')
							jjCheckNAddStates(15, 17);
						break;

					case 23: // '\027'
						if (curChar == '"' && kind > 10)
							kind = 10;
						break;

					case 24: // '\030'
						if ((0xfffffffbffffffffL & l) != 0L)
							jjCheckNAddTwoStates(24, 25);
						break;

					case 26: // '\032'
						if ((0xfffffffbffffffffL & l) != 0L && kind > 11)
							kind = 11;
						break;

					case 27: // '\033'
						if (curChar == '\'')
							jjCheckNAddStates(5, 9);
						break;

					case 28: // '\034'
						if ((0xffffff7fffffffffL & l) != 0L)
							jjCheckNAddStates(18, 20);
						break;

					case 30: // '\036'
						if (curChar == '\'')
							jjCheckNAddStates(18, 20);
						break;

					case 31: // '\037'
						if (curChar == '\'' && kind > 10)
							kind = 10;
						break;

					case 32: // ' '
						if ((0xffffff7fffffffffL & l) != 0L)
							jjCheckNAddTwoStates(32, 33);
						break;

					case 34: // '"'
						if ((0xffffff7fffffffffL & l) != 0L && kind > 11)
							kind = 11;
						break;
					}
				while (i != startsAt);
			} else
			if (curChar < '\200')
			{
				long l = 1L << (curChar & 0x3f);
				do
					switch (jjstateSet[--i])
					{
					case 0: // '\0'
					case 6: // '\006'
						if ((0x7fffffe87fffffeL & l) != 0L)
						{
							if (kind > 49)
								kind = 49;
							jjCheckNAdd(6);
						}
						break;

					case 2: // '\002'
						if ((0x2000000020L & l) != 0L)
							jjAddStates(21, 22);
						break;

					case 12: // '\f'
						if ((0x2000000020L & l) != 0L)
							jjAddStates(23, 24);
						break;

					case 16: // '\020'
						if ((0x2000000020L & l) != 0L)
							jjAddStates(25, 26);
						break;

					case 20: // '\024'
						if ((0xffffffffefffffffL & l) != 0L)
							jjCheckNAddStates(15, 17);
						break;

					case 21: // '\025'
						if (curChar == '\\')
							jjstateSet[jjnewStateCnt++] = 22;
						break;

					case 22: // '\026'
						if (curChar == '\\')
							jjCheckNAddStates(15, 17);
						break;

					case 24: // '\030'
						if ((0xffffffffefffffffL & l) != 0L)
							jjAddStates(27, 28);
						break;

					case 25: // '\031'
						if (curChar == '\\')
							jjstateSet[jjnewStateCnt++] = 26;
						break;

					case 26: // '\032'
					case 34: // '"'
						if ((0xffffffffefffffffL & l) != 0L && kind > 11)
							kind = 11;
						break;

					case 28: // '\034'
						if ((0xffffffffefffffffL & l) != 0L)
							jjCheckNAddStates(18, 20);
						break;

					case 29: // '\035'
						if (curChar == '\\')
							jjstateSet[jjnewStateCnt++] = 30;
						break;

					case 30: // '\036'
						if (curChar == '\\')
							jjCheckNAddStates(18, 20);
						break;

					case 32: // ' '
						if ((0xffffffffefffffffL & l) != 0L)
							jjAddStates(29, 30);
						break;

					case 33: // '!'
						if (curChar == '\\')
							jjstateSet[jjnewStateCnt++] = 34;
						break;
					}
				while (i != startsAt);
			} else
			{
				int hiByte = curChar >> 8;
				int i1 = hiByte >> 6;
				long l1 = 1L << (hiByte & 0x3f);
				int i2 = (curChar & 0xff) >> 6;
				long l2 = 1L << (curChar & 0x3f);
				do
					switch (jjstateSet[--i])
					{
					case 0: // '\0'
					case 6: // '\006'
						if (jjCanMove_1(hiByte, i1, i2, l1, l2))
						{
							if (kind > 49)
								kind = 49;
							jjCheckNAdd(6);
						}
						break;

					case 20: // '\024'
						if (jjCanMove_0(hiByte, i1, i2, l1, l2))
							jjAddStates(15, 17);
						break;

					case 24: // '\030'
						if (jjCanMove_0(hiByte, i1, i2, l1, l2))
							jjAddStates(27, 28);
						break;

					case 26: // '\032'
					case 34: // '"'
						if (jjCanMove_0(hiByte, i1, i2, l1, l2) && kind > 11)
							kind = 11;
						break;

					case 28: // '\034'
						if (jjCanMove_0(hiByte, i1, i2, l1, l2))
							jjAddStates(18, 20);
						break;

					case 32: // ' '
						if (jjCanMove_0(hiByte, i1, i2, l1, l2))
							jjAddStates(29, 30);
						break;
					}
				while (i != startsAt);
			}
			if (kind != 0x7fffffff)
			{
				jjmatchedKind = kind;
				jjmatchedPos = curPos;
				kind = 0x7fffffff;
			}
			curPos++;
			if ((i = jjnewStateCnt) == (startsAt = 35 - (jjnewStateCnt = startsAt)))
				return curPos;
			try
			{
				curChar = input_stream.readChar();
			}
			catch (IOException e)
			{
				return curPos;
			}
		} while (true);
	}

	private static final boolean jjCanMove_0(int hiByte, int i1, int i2, long l1, long l2)
	{
		switch (hiByte)
		{
		case 0: // '\0'
			return (jjbitVec2[i2] & l2) != 0L;
		}
		return (jjbitVec0[i1] & l1) != 0L;
	}

	private static final boolean jjCanMove_1(int hiByte, int i1, int i2, long l1, long l2)
	{
		switch (hiByte)
		{
		case 0: // '\0'
			return (jjbitVec4[i2] & l2) != 0L;

		case 48: // '0'
			return (jjbitVec5[i2] & l2) != 0L;

		case 49: // '1'
			return (jjbitVec6[i2] & l2) != 0L;

		case 51: // '3'
			return (jjbitVec7[i2] & l2) != 0L;

		case 61: // '='
			return (jjbitVec8[i2] & l2) != 0L;
		}
		return (jjbitVec3[i1] & l1) != 0L;
	}

	public ELParserTokenManager(SimpleCharStream stream)
	{
		debugStream = System.out;
		jjrounds = new int[35];
		jjstateSet = new int[70];
		curLexState = 0;
		defaultLexState = 0;
		input_stream = stream;
	}

	public ELParserTokenManager(SimpleCharStream stream, int lexState)
	{
		this(stream);
		SwitchTo(lexState);
	}

	public void ReInit(SimpleCharStream stream)
	{
		jjmatchedPos = jjnewStateCnt = 0;
		curLexState = defaultLexState;
		input_stream = stream;
		ReInitRounds();
	}

	private final void ReInitRounds()
	{
		jjround = 0x80000001;
		for (int i = 35; i-- > 0;)
			jjrounds[i] = 0x80000000;

	}

	public void ReInit(SimpleCharStream stream, int lexState)
	{
		ReInit(stream);
		SwitchTo(lexState);
	}

	public void SwitchTo(int lexState)
	{
		if (lexState >= 2 || lexState < 0)
		{
			throw new TokenMgrError("Error: Ignoring invalid lexical state : " + lexState + ". State unchanged.", 2);
		} else
		{
			curLexState = lexState;
			return;
		}
	}

	private final Token jjFillToken()
	{
		Token t = Token.newToken(jjmatchedKind);
		t.kind = jjmatchedKind;
		String im = jjstrLiteralImages[jjmatchedKind];
		t.image = im != null ? im : input_stream.GetImage();
		t.beginLine = input_stream.getBeginLine();
		t.beginColumn = input_stream.getBeginColumn();
		t.endLine = input_stream.getEndLine();
		t.endColumn = input_stream.getEndColumn();
		return t;
	}

	public final Token getNextToken()
	{
		Token specialToken = null;
		int curPos = 0;
		do
		{
			try
			{
				curChar = input_stream.BeginToken();
			}
			catch (IOException e)
			{
				jjmatchedKind = 0;
				Token matchedToken = jjFillToken();
				return matchedToken;
			}
			switch (curLexState)
			{
			case 0: // '\0'
				jjmatchedKind = 0x7fffffff;
				jjmatchedPos = 0;
				curPos = jjMoveStringLiteralDfa0_0();
				break;

			case 1: // '\001'
				try
				{
					input_stream.backup(0);
					for (; curChar <= ' ' && (0x100002600L & 1L << curChar) != 0L; curChar = input_stream.BeginToken());
				}
				catch (IOException e1)
				{
					continue;
				}
				jjmatchedKind = 0x7fffffff;
				jjmatchedPos = 0;
				curPos = jjMoveStringLiteralDfa0_1();
				if (jjmatchedPos == 0 && jjmatchedKind > 53)
					jjmatchedKind = 53;
				break;
			}
			if (jjmatchedKind == 0x7fffffff)
				break;
			if (jjmatchedPos + 1 < curPos)
				input_stream.backup(curPos - jjmatchedPos - 1);
			if ((jjtoToken[jjmatchedKind >> 6] & 1L << (jjmatchedKind & 0x3f)) != 0L)
			{
				Token matchedToken = jjFillToken();
				if (jjnewLexState[jjmatchedKind] != -1)
					curLexState = jjnewLexState[jjmatchedKind];
				return matchedToken;
			}
			if (jjnewLexState[jjmatchedKind] != -1)
				curLexState = jjnewLexState[jjmatchedKind];
		} while (true);
		int error_line = input_stream.getEndLine();
		int error_column = input_stream.getEndColumn();
		String error_after = null;
		boolean EOFSeen = false;
		try
		{
			input_stream.readChar();
			input_stream.backup(1);
		}
		catch (IOException e1)
		{
			EOFSeen = true;
			error_after = curPos > 1 ? input_stream.GetImage() : "";
			if (curChar == '\n' || curChar == '\r')
			{
				error_line++;
				error_column = 0;
			} else
			{
				error_column++;
			}
		}
		if (!EOFSeen)
		{
			input_stream.backup(1);
			error_after = curPos > 1 ? input_stream.GetImage() : "";
		}
		throw new TokenMgrError(EOFSeen, curLexState, error_line, error_column, error_after, curChar, 0);
	}

}
