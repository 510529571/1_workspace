// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   UnaryOperatorExpression.java

package org.apache.taglibs.standard.lang.jstl;

import java.util.List;
import java.util.Map;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			Expression, UnaryOperator, ELException, VariableResolver, 
//			Logger

public class UnaryOperatorExpression extends Expression
{

	UnaryOperator mOperator;
	List mOperators;
	Expression mExpression;

	public UnaryOperator getOperator()
	{
		return mOperator;
	}

	public void setOperator(UnaryOperator pOperator)
	{
		mOperator = pOperator;
	}

	public List getOperators()
	{
		return mOperators;
	}

	public void setOperators(List pOperators)
	{
		mOperators = pOperators;
	}

	public Expression getExpression()
	{
		return mExpression;
	}

	public void setExpression(Expression pExpression)
	{
		mExpression = pExpression;
	}

	public UnaryOperatorExpression(UnaryOperator pOperator, List pOperators, Expression pExpression)
	{
		mOperator = pOperator;
		mOperators = pOperators;
		mExpression = pExpression;
	}

	public String getExpressionString()
	{
		StringBuffer buf = new StringBuffer();
		buf.append("(");
		if (mOperator != null)
		{
			buf.append(mOperator.getOperatorSymbol());
			buf.append(" ");
		} else
		{
			for (int i = 0; i < mOperators.size(); i++)
			{
				UnaryOperator operator = (UnaryOperator)mOperators.get(i);
				buf.append(operator.getOperatorSymbol());
				buf.append(" ");
			}

		}
		buf.append(mExpression.getExpressionString());
		buf.append(")");
		return buf.toString();
	}

	public Object evaluate(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger)
		throws ELException
	{
		Object value = mExpression.evaluate(pContext, pResolver, functions, defaultPrefix, pLogger);
		if (mOperator != null)
		{
			value = mOperator.apply(value, pContext, pLogger);
		} else
		{
			for (int i = mOperators.size() - 1; i >= 0; i--)
			{
				UnaryOperator operator = (UnaryOperator)mOperators.get(i);
				value = operator.apply(value, pContext, pLogger);
			}

		}
		return value;
	}
}
