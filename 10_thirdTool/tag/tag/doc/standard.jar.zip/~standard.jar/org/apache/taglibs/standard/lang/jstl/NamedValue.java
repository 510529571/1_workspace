// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   NamedValue.java

package org.apache.taglibs.standard.lang.jstl;

import java.util.Map;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			Expression, ELException, StringLiteral, VariableResolver, 
//			Logger

public class NamedValue extends Expression
{

	String mName;

	public String getName()
	{
		return mName;
	}

	public NamedValue(String pName)
	{
		mName = pName;
	}

	public String getExpressionString()
	{
		return StringLiteral.toIdentifierToken(mName);
	}

	public Object evaluate(Object pContext, VariableResolver pResolver, Map functions, String defaultPrefix, Logger pLogger)
		throws ELException
	{
		if (pResolver == null)
			return null;
		else
			return pResolver.resolveVariable(mName, pContext);
	}
}
