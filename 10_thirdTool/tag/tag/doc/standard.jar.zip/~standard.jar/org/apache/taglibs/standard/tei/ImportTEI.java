// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ImportTEI.java

package org.apache.taglibs.standard.tei;

import javax.servlet.jsp.tagext.TagData;
import javax.servlet.jsp.tagext.TagExtraInfo;

// Referenced classes of package org.apache.taglibs.standard.tei:
//			Util

public class ImportTEI extends TagExtraInfo
{

	private static final String VAR = "var";
	private static final String VAR_READER = "varReader";

	public ImportTEI()
	{
	}

	public boolean isValid(TagData us)
	{
		return !Util.isSpecified(us, "var") || !Util.isSpecified(us, "varReader");
	}
}
