// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ForEachSupport.java

package org.apache.taglibs.standard.tag.common.core;

import java.util.*;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.jstl.core.LoopTagSupport;
import org.apache.taglibs.standard.resources.Resources;

public abstract class ForEachSupport extends LoopTagSupport
{
	protected class SimpleForEachIterator
		implements ForEachIterator
	{

		private Iterator i;

		public boolean hasNext()
		{
			return i.hasNext();
		}

		public Object next()
		{
			return i.next();
		}

		public SimpleForEachIterator(Iterator i)
		{
			this.i = i;
		}
	}

	protected static interface ForEachIterator
	{

		public abstract boolean hasNext()
			throws JspTagException;

		public abstract Object next()
			throws JspTagException;
	}


	protected ForEachIterator items;
	protected Object rawItems;

	public ForEachSupport()
	{
	}

	protected boolean hasNext()
		throws JspTagException
	{
		return items.hasNext();
	}

	protected Object next()
		throws JspTagException
	{
		return items.next();
	}

	protected void prepare()
		throws JspTagException
	{
		if (rawItems != null)
			items = supportedTypeForEachIterator(rawItems);
		else
			items = beginEndForEachIterator();
	}

	public void release()
	{
		super.release();
		items = null;
		rawItems = null;
	}

	protected ForEachIterator supportedTypeForEachIterator(Object o)
		throws JspTagException
	{
		ForEachIterator items;
		if (o instanceof Object[])
			items = toForEachIterator((Object[])o);
		else
		if (o instanceof boolean[])
			items = toForEachIterator((boolean[])o);
		else
		if (o instanceof byte[])
			items = toForEachIterator((byte[])o);
		else
		if (o instanceof char[])
			items = toForEachIterator((char[])o);
		else
		if (o instanceof short[])
			items = toForEachIterator((short[])o);
		else
		if (o instanceof int[])
			items = toForEachIterator((int[])o);
		else
		if (o instanceof long[])
			items = toForEachIterator((long[])o);
		else
		if (o instanceof float[])
			items = toForEachIterator((float[])o);
		else
		if (o instanceof double[])
			items = toForEachIterator((double[])o);
		else
		if (o instanceof Collection)
			items = toForEachIterator((Collection)o);
		else
		if (o instanceof Iterator)
			items = toForEachIterator((Iterator)o);
		else
		if (o instanceof Enumeration)
			items = toForEachIterator((Enumeration)o);
		else
		if (o instanceof Map)
			items = toForEachIterator((Map)o);
		else
		if (o instanceof String)
			items = toForEachIterator((String)o);
		else
			items = toForEachIterator(o);
		return items;
	}

	private ForEachIterator beginEndForEachIterator()
	{
		Integer ia[] = new Integer[end + 1];
		for (int i = 0; i <= end; i++)
			ia[i] = new Integer(i);

		return new SimpleForEachIterator(Arrays.asList(ia).iterator());
	}

	protected ForEachIterator toForEachIterator(Object o)
		throws JspTagException
	{
		throw new JspTagException(Resources.getMessage("FOREACH_BAD_ITEMS"));
	}

	protected ForEachIterator toForEachIterator(Object a[])
	{
		return new SimpleForEachIterator(Arrays.asList(a).iterator());
	}

	protected ForEachIterator toForEachIterator(boolean a[])
	{
		Boolean wrapped[] = new Boolean[a.length];
		for (int i = 0; i < a.length; i++)
			wrapped[i] = new Boolean(a[i]);

		return new SimpleForEachIterator(Arrays.asList(wrapped).iterator());
	}

	protected ForEachIterator toForEachIterator(byte a[])
	{
		Byte wrapped[] = new Byte[a.length];
		for (int i = 0; i < a.length; i++)
			wrapped[i] = new Byte(a[i]);

		return new SimpleForEachIterator(Arrays.asList(wrapped).iterator());
	}

	protected ForEachIterator toForEachIterator(char a[])
	{
		Character wrapped[] = new Character[a.length];
		for (int i = 0; i < a.length; i++)
			wrapped[i] = new Character(a[i]);

		return new SimpleForEachIterator(Arrays.asList(wrapped).iterator());
	}

	protected ForEachIterator toForEachIterator(short a[])
	{
		Short wrapped[] = new Short[a.length];
		for (int i = 0; i < a.length; i++)
			wrapped[i] = new Short(a[i]);

		return new SimpleForEachIterator(Arrays.asList(wrapped).iterator());
	}

	protected ForEachIterator toForEachIterator(int a[])
	{
		Integer wrapped[] = new Integer[a.length];
		for (int i = 0; i < a.length; i++)
			wrapped[i] = new Integer(a[i]);

		return new SimpleForEachIterator(Arrays.asList(wrapped).iterator());
	}

	protected ForEachIterator toForEachIterator(long a[])
	{
		Long wrapped[] = new Long[a.length];
		for (int i = 0; i < a.length; i++)
			wrapped[i] = new Long(a[i]);

		return new SimpleForEachIterator(Arrays.asList(wrapped).iterator());
	}

	protected ForEachIterator toForEachIterator(float a[])
	{
		Float wrapped[] = new Float[a.length];
		for (int i = 0; i < a.length; i++)
			wrapped[i] = new Float(a[i]);

		return new SimpleForEachIterator(Arrays.asList(wrapped).iterator());
	}

	protected ForEachIterator toForEachIterator(double a[])
	{
		Double wrapped[] = new Double[a.length];
		for (int i = 0; i < a.length; i++)
			wrapped[i] = new Double(a[i]);

		return new SimpleForEachIterator(Arrays.asList(wrapped).iterator());
	}

	protected ForEachIterator toForEachIterator(Collection c)
	{
		return new SimpleForEachIterator(c.iterator());
	}

	protected ForEachIterator toForEachIterator(Iterator i)
	{
		return new SimpleForEachIterator(i);
	}

	protected ForEachIterator toForEachIterator(Enumeration e)
	{
		class 1EnumerationAdapter
			implements ForEachIterator
		{

			private Enumeration e;

			public boolean hasNext()
			{
				return e.hasMoreElements();
			}

			public Object next()
			{
				return e.nextElement();
			}

			public 1EnumerationAdapter(Enumeration e)
			{
				this.e = e;
			}
		}

		return new 1EnumerationAdapter(e);
	}

	protected ForEachIterator toForEachIterator(Map m)
	{
		return new SimpleForEachIterator(m.entrySet().iterator());
	}

	protected ForEachIterator toForEachIterator(String s)
	{
		StringTokenizer st = new StringTokenizer(s, ",");
		return toForEachIterator(((Enumeration) (st)));
	}
}
