// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParamSupport.java

package org.apache.taglibs.standard.tag.common.core;

import java.util.LinkedList;
import java.util.List;
import javax.servlet.ServletResponse;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;
import org.apache.taglibs.standard.resources.Resources;

// Referenced classes of package org.apache.taglibs.standard.tag.common.core:
//			ParamParent, Util

public abstract class ParamSupport extends BodyTagSupport
{
	public static class ParamManager
	{

		private List names;
		private List values;
		private boolean done;

		public void addParameter(String name, String value)
		{
			if (done)
				throw new IllegalStateException();
			if (name != null)
			{
				names.add(name);
				if (value != null)
					values.add(value);
				else
					values.add("");
			}
		}

		public String aggregateParams(String url)
		{
			if (done)
				throw new IllegalStateException();
			done = true;
			StringBuffer newParams = new StringBuffer();
			for (int i = 0; i < names.size(); i++)
			{
				newParams.append(names.get(i) + "=" + values.get(i));
				if (i < names.size() - 1)
					newParams.append("&");
			}

			if (newParams.length() > 0)
			{
				int questionMark = url.indexOf('?');
				if (questionMark == -1)
				{
					return url + "?" + newParams;
				} else
				{
					StringBuffer workingUrl = new StringBuffer(url);
					workingUrl.insert(questionMark + 1, newParams + "&");
					return workingUrl.toString();
				}
			} else
			{
				return url;
			}
		}

		public ParamManager()
		{
			names = new LinkedList();
			values = new LinkedList();
			done = false;
		}
	}


	protected String name;
	protected String value;
	protected boolean encode;

	public ParamSupport()
	{
		encode = true;
		init();
	}

	private void init()
	{
		name = value = null;
	}

	public int doEndTag()
		throws JspException
	{
		javax.servlet.jsp.tagext.Tag t = findAncestorWithClass(this, org.apache.taglibs.standard.tag.common.core.ParamParent.class);
		if (t == null)
			throw new JspTagException(Resources.getMessage("PARAM_OUTSIDE_PARENT"));
		if (name == null || name.equals(""))
			return 6;
		ParamParent parent = (ParamParent)t;
		String value = this.value;
		if (value == null)
			if (bodyContent == null || bodyContent.getString() == null)
				value = "";
			else
				value = bodyContent.getString().trim();
		if (encode)
		{
			String enc = pageContext.getResponse().getCharacterEncoding();
			parent.addParameter(Util.URLEncode(name, enc), Util.URLEncode(value, enc));
		} else
		{
			parent.addParameter(name, value);
		}
		return 6;
	}

	public void release()
	{
		init();
	}
}
