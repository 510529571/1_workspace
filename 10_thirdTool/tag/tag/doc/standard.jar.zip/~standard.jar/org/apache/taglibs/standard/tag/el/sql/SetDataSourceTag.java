// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   SetDataSourceTag.java

package org.apache.taglibs.standard.tag.el.sql;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.tag.common.sql.SetDataSourceTagSupport;

public class SetDataSourceTag extends SetDataSourceTagSupport
{

	private String dataSourceEL;
	private String driverClassNameEL;
	private String jdbcURLEL;
	private String userNameEL;
	private String passwordEL;

	public SetDataSourceTag()
	{
	}

	public void setDataSource(String dataSourceEL)
	{
		this.dataSourceEL = dataSourceEL;
		dataSourceSpecified = true;
	}

	public void setDriver(String driverClassNameEL)
	{
		this.driverClassNameEL = driverClassNameEL;
	}

	public void setUrl(String jdbcURLEL)
	{
		this.jdbcURLEL = jdbcURLEL;
	}

	public void setUser(String userNameEL)
	{
		this.userNameEL = userNameEL;
	}

	public void setPassword(String passwordEL)
	{
		this.passwordEL = passwordEL;
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	private void evaluateExpressions()
		throws JspException
	{
		if (dataSourceEL != null)
			dataSource = ExpressionEvaluatorManager.evaluate("dataSource", dataSourceEL, java.lang.Object.class, this, pageContext);
		if (driverClassNameEL != null)
			driverClassName = (String)ExpressionEvaluatorManager.evaluate("driver", driverClassNameEL, java.lang.String.class, this, pageContext);
		if (jdbcURLEL != null)
			jdbcURL = (String)ExpressionEvaluatorManager.evaluate("url", jdbcURLEL, java.lang.String.class, this, pageContext);
		if (userNameEL != null)
			userName = (String)ExpressionEvaluatorManager.evaluate("user", userNameEL, java.lang.String.class, this, pageContext);
		if (passwordEL != null)
			password = (String)ExpressionEvaluatorManager.evaluate("password", passwordEL, java.lang.String.class, this, pageContext);
	}
}
