// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   TransactionTag.java

package org.apache.taglibs.standard.tag.rt.sql;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.tag.common.sql.TransactionTagSupport;

public class TransactionTag extends TransactionTagSupport
{

	private String isolationRT;

	public TransactionTag()
	{
	}

	public void setDataSource(Object dataSource)
	{
		rawDataSource = dataSource;
		dataSourceSpecified = true;
	}

	public void setIsolation(String isolation)
	{
		isolationRT = isolation;
	}

	public int doStartTag()
		throws JspException
	{
		if (isolationRT != null)
			super.setIsolation(isolationRT);
		return super.doStartTag();
	}
}
