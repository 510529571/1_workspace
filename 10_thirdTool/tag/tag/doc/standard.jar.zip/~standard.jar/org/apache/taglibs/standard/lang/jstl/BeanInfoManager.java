// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   BeanInfoManager.java

package org.apache.taglibs.standard.lang.jstl;

import java.beans.*;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.security.AccessControlException;
import java.util.HashMap;
import java.util.Map;

// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			BeanInfoIndexedProperty, BeanInfoProperty, ELException, Logger, 
//			Constants

public class BeanInfoManager
{

	Class mBeanClass;
	BeanInfo mBeanInfo;
	Map mPropertyByName;
	Map mIndexedPropertyByName;
	Map mEventSetByName;
	boolean mInitialized;
	static Map mBeanInfoManagerByClass = new HashMap();

	public Class getBeanClass()
	{
		return mBeanClass;
	}

	BeanInfoManager(Class pBeanClass)
	{
		mBeanClass = pBeanClass;
	}

	public static BeanInfoManager getBeanInfoManager(Class pClass)
	{
		BeanInfoManager ret = (BeanInfoManager)mBeanInfoManagerByClass.get(pClass);
		if (ret == null)
			ret = createBeanInfoManager(pClass);
		return ret;
	}

	static synchronized BeanInfoManager createBeanInfoManager(Class pClass)
	{
		BeanInfoManager ret = (BeanInfoManager)mBeanInfoManagerByClass.get(pClass);
		if (ret == null)
		{
			ret = new BeanInfoManager(pClass);
			mBeanInfoManagerByClass.put(pClass, ret);
		}
		return ret;
	}

	public static BeanInfoProperty getBeanInfoProperty(Class pClass, String pPropertyName, Logger pLogger)
		throws ELException
	{
		return getBeanInfoManager(pClass).getProperty(pPropertyName, pLogger);
	}

	public static BeanInfoIndexedProperty getBeanInfoIndexedProperty(Class pClass, String pIndexedPropertyName, Logger pLogger)
		throws ELException
	{
		return getBeanInfoManager(pClass).getIndexedProperty(pIndexedPropertyName, pLogger);
	}

	void checkInitialized(Logger pLogger)
		throws ELException
	{
		if (!mInitialized)
			synchronized (this)
			{
				if (!mInitialized)
				{
					initialize(pLogger);
					mInitialized = true;
				}
			}
	}

	void initialize(Logger pLogger)
		throws ELException
	{
		try
		{
			mBeanInfo = Introspector.getBeanInfo(mBeanClass);
			mPropertyByName = new HashMap();
			mIndexedPropertyByName = new HashMap();
			PropertyDescriptor pds[] = mBeanInfo.getPropertyDescriptors();
			for (int i = 0; pds != null && i < pds.length; i++)
			{
				PropertyDescriptor pd = pds[i];
				if (pd instanceof IndexedPropertyDescriptor)
				{
					IndexedPropertyDescriptor ipd = (IndexedPropertyDescriptor)pd;
					Method readMethod = getPublicMethod(ipd.getIndexedReadMethod());
					Method writeMethod = getPublicMethod(ipd.getIndexedWriteMethod());
					BeanInfoIndexedProperty property = new BeanInfoIndexedProperty(readMethod, writeMethod, ipd);
					mIndexedPropertyByName.put(ipd.getName(), property);
				}
				Method readMethod = getPublicMethod(pd.getReadMethod());
				Method writeMethod = getPublicMethod(pd.getWriteMethod());
				BeanInfoProperty property = new BeanInfoProperty(readMethod, writeMethod, pd);
				mPropertyByName.put(pd.getName(), property);
			}

			mEventSetByName = new HashMap();
			EventSetDescriptor esds[] = mBeanInfo.getEventSetDescriptors();
			for (int i = 0; esds != null && i < esds.length; i++)
			{
				EventSetDescriptor esd = esds[i];
				mEventSetByName.put(esd.getName(), esd);
			}

		}
		catch (IntrospectionException exc)
		{
			if (pLogger.isLoggingWarning())
				pLogger.logWarning(Constants.EXCEPTION_GETTING_BEANINFO, exc, mBeanClass.getName());
		}
	}

	BeanInfo getBeanInfo(Logger pLogger)
		throws ELException
	{
		checkInitialized(pLogger);
		return mBeanInfo;
	}

	public BeanInfoProperty getProperty(String pPropertyName, Logger pLogger)
		throws ELException
	{
		checkInitialized(pLogger);
		return (BeanInfoProperty)mPropertyByName.get(pPropertyName);
	}

	public BeanInfoIndexedProperty getIndexedProperty(String pIndexedPropertyName, Logger pLogger)
		throws ELException
	{
		checkInitialized(pLogger);
		return (BeanInfoIndexedProperty)mIndexedPropertyByName.get(pIndexedPropertyName);
	}

	public EventSetDescriptor getEventSet(String pEventSetName, Logger pLogger)
		throws ELException
	{
		checkInitialized(pLogger);
		return (EventSetDescriptor)mEventSetByName.get(pEventSetName);
	}

	static Method getPublicMethod(Method pMethod)
	{
		if (pMethod == null)
			return null;
		Class cl = pMethod.getDeclaringClass();
		if (Modifier.isPublic(cl.getModifiers()))
			return pMethod;
		Method ret = getPublicMethod(cl, pMethod);
		if (ret != null)
			return ret;
		else
			return pMethod;
	}

	static Method getPublicMethod(Class pClass, Method pMethod)
	{
		if (!Modifier.isPublic(pClass.getModifiers()))
			break MISSING_BLOCK_LABEL_56;
		Method m;
		try
		{
			m = pClass.getDeclaredMethod(pMethod.getName(), pMethod.getParameterTypes());
		}
		catch (AccessControlException ex)
		{
			m = pClass.getMethod(pMethod.getName(), pMethod.getParameterTypes());
		}
		if (Modifier.isPublic(m.getModifiers()))
			return m;
		break MISSING_BLOCK_LABEL_56;
		NoSuchMethodException exc;
		exc;
		Class interfaces[] = pClass.getInterfaces();
		if (interfaces != null)
		{
			for (int i = 0; i < interfaces.length; i++)
			{
				Method m = getPublicMethod(interfaces[i], pMethod);
				if (m != null)
					return m;
			}

		}
		Class superclass = pClass.getSuperclass();
		if (superclass != null)
		{
			Method m = getPublicMethod(superclass, pMethod);
			if (m != null)
				return m;
		}
		return null;
	}

}
