// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   FormatNumberTag.java

package org.apache.taglibs.standard.tag.el.fmt;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.lang.support.ExpressionEvaluatorManager;
import org.apache.taglibs.standard.tag.common.fmt.FormatNumberSupport;

public class FormatNumberTag extends FormatNumberSupport
{

	private String value_;
	private String type_;
	private String pattern_;
	private String currencyCode_;
	private String currencySymbol_;
	private String groupingUsed_;
	private String maxIntegerDigits_;
	private String minIntegerDigits_;
	private String maxFractionDigits_;
	private String minFractionDigits_;

	public FormatNumberTag()
	{
		init();
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setValue(String value_)
	{
		this.value_ = value_;
		valueSpecified = true;
	}

	public void setType(String type_)
	{
		this.type_ = type_;
	}

	public void setPattern(String pattern_)
	{
		this.pattern_ = pattern_;
	}

	public void setCurrencyCode(String currencyCode_)
	{
		this.currencyCode_ = currencyCode_;
	}

	public void setCurrencySymbol(String currencySymbol_)
	{
		this.currencySymbol_ = currencySymbol_;
	}

	public void setGroupingUsed(String groupingUsed_)
	{
		this.groupingUsed_ = groupingUsed_;
		groupingUsedSpecified = true;
	}

	public void setMaxIntegerDigits(String maxIntegerDigits_)
	{
		this.maxIntegerDigits_ = maxIntegerDigits_;
		maxIntegerDigitsSpecified = true;
	}

	public void setMinIntegerDigits(String minIntegerDigits_)
	{
		this.minIntegerDigits_ = minIntegerDigits_;
		minIntegerDigitsSpecified = true;
	}

	public void setMaxFractionDigits(String maxFractionDigits_)
	{
		this.maxFractionDigits_ = maxFractionDigits_;
		maxFractionDigitsSpecified = true;
	}

	public void setMinFractionDigits(String minFractionDigits_)
	{
		this.minFractionDigits_ = minFractionDigits_;
		minFractionDigitsSpecified = true;
	}

	private void init()
	{
		value_ = type_ = pattern_ = null;
		currencyCode_ = currencySymbol_ = null;
		groupingUsed_ = null;
		maxIntegerDigits_ = minIntegerDigits_ = null;
		maxFractionDigits_ = minFractionDigits_ = null;
	}

	private void evaluateExpressions()
		throws JspException
	{
		Object obj = null;
		if (value_ != null)
			value = ExpressionEvaluatorManager.evaluate("value", value_, java.lang.Object.class, this, pageContext);
		if (type_ != null)
			type = (String)ExpressionEvaluatorManager.evaluate("type", type_, java.lang.String.class, this, pageContext);
		if (pattern_ != null)
			pattern = (String)ExpressionEvaluatorManager.evaluate("pattern", pattern_, java.lang.String.class, this, pageContext);
		if (currencyCode_ != null)
			currencyCode = (String)ExpressionEvaluatorManager.evaluate("currencyCode", currencyCode_, java.lang.String.class, this, pageContext);
		if (currencySymbol_ != null)
			currencySymbol = (String)ExpressionEvaluatorManager.evaluate("currencySymbol", currencySymbol_, java.lang.String.class, this, pageContext);
		if (groupingUsed_ != null)
		{
			obj = ExpressionEvaluatorManager.evaluate("groupingUsed", groupingUsed_, java.lang.Boolean.class, this, pageContext);
			if (obj != null)
				isGroupingUsed = ((Boolean)obj).booleanValue();
		}
		if (maxIntegerDigits_ != null)
		{
			obj = ExpressionEvaluatorManager.evaluate("maxIntegerDigits", maxIntegerDigits_, java.lang.Integer.class, this, pageContext);
			if (obj != null)
				maxIntegerDigits = ((Integer)obj).intValue();
		}
		if (minIntegerDigits_ != null)
		{
			obj = ExpressionEvaluatorManager.evaluate("minIntegerDigits", minIntegerDigits_, java.lang.Integer.class, this, pageContext);
			if (obj != null)
				minIntegerDigits = ((Integer)obj).intValue();
		}
		if (maxFractionDigits_ != null)
		{
			obj = ExpressionEvaluatorManager.evaluate("maxFractionDigits", maxFractionDigits_, java.lang.Integer.class, this, pageContext);
			if (obj != null)
				maxFractionDigits = ((Integer)obj).intValue();
		}
		if (minFractionDigits_ != null)
		{
			obj = ExpressionEvaluatorManager.evaluate("minFractionDigits", minFractionDigits_, java.lang.Integer.class, this, pageContext);
			if (obj != null)
				minFractionDigits = ((Integer)obj).intValue();
		}
	}
}
