// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   ParamTag.java

package org.apache.taglibs.standard.tag.el.core;

import javax.servlet.jsp.JspException;
import org.apache.taglibs.standard.tag.common.core.ParamSupport;

// Referenced classes of package org.apache.taglibs.standard.tag.el.core:
//			ExpressionUtil

public class ParamTag extends ParamSupport
{

	private String name_;
	private String value_;

	public ParamTag()
	{
		init();
	}

	public int doStartTag()
		throws JspException
	{
		evaluateExpressions();
		return super.doStartTag();
	}

	public void release()
	{
		super.release();
		init();
	}

	public void setName(String name_)
	{
		this.name_ = name_;
	}

	public void setValue(String value_)
	{
		this.value_ = value_;
	}

	private void init()
	{
		name_ = value_ = null;
	}

	private void evaluateExpressions()
		throws JspException
	{
		name = (String)ExpressionUtil.evalNotNull("import", "name", name_, java.lang.String.class, this, pageContext);
		value = (String)ExpressionUtil.evalNotNull("import", "value", value_, java.lang.String.class, this, pageContext);
	}
}
