// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   MinusOperator.java

package org.apache.taglibs.standard.lang.jstl;


// Referenced classes of package org.apache.taglibs.standard.lang.jstl:
//			ArithmeticOperator, Logger

public class MinusOperator extends ArithmeticOperator
{

	public static final MinusOperator SINGLETON = new MinusOperator();

	public MinusOperator()
	{
	}

	public String getOperatorSymbol()
	{
		return "-";
	}

	public double apply(double pLeft, double pRight, Logger pLogger)
	{
		return pLeft - pRight;
	}

	public long apply(long pLeft, long pRight, Logger pLogger)
	{
		return pLeft - pRight;
	}

}
