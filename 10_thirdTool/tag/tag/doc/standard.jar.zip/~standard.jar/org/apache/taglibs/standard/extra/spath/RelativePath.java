// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   RelativePath.java

package org.apache.taglibs.standard.extra.spath;

import java.util.List;
import java.util.Vector;

// Referenced classes of package org.apache.taglibs.standard.extra.spath:
//			Path, Step

public class RelativePath extends Path
{

	private RelativePath next;
	private Step step;

	public RelativePath(Step step, RelativePath next)
	{
		if (step == null)
		{
			throw new IllegalArgumentException("non-null step required");
		} else
		{
			this.step = step;
			this.next = next;
			return;
		}
	}

	public List getSteps()
	{
		List l;
		if (next != null)
			l = next.getSteps();
		else
			l = new Vector();
		l.add(0, step);
		return l;
	}
}
