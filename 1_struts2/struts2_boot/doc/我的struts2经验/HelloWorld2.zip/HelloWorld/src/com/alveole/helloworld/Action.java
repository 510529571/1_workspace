package com.alveole.helloworld;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;

public class Action extends ActionSupport {
	private String view;

	public String getView() {
		return view;
	}

	public void setView(String view) {
		this.view = view;
	}

	/**
	 * Struts action implementation for node Initialization on session
	 * @return a link to follow
	 */
	public String init() {
	    return "success";
	}

	/**
	 * Struts action implementation for node Hello World action
	 * @return a link to follow
	 */
	public String hello() {
	    return getView();
	}

	/**
	 * Struts action implementation for node Close session
	 * @return a link to follow
	 */
	public String close() {
		ServletActionContext.getRequest().getSession().invalidate();
	    return "success";
	}

}
